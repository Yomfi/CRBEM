/**
 * CRBEM Theological Seminary - Institutional Master Footer
 * Redesigned to premium standards:
 * - Deep navy background (#0D1524)
 * - Prominent brand signature: Logo, small descriptor, large bold "CRBEM" signature
 * - Below it: "Christ Redemption Bible Evangelical Mission Theological Seminary"
 * - Additional columns: Programmes, Seminary, Contact
 * - Clean bottom bar with copyright and essential links
 * - Larger type (no tiny unreadable text), generous vertical spacing
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { CrbemLogo } from './CrbemLogo';
import { MapPin, Phone, Mail, Clock, ArrowUpRight } from 'lucide-react';

export const AppFooter: React.FC = () => {
  const { navigateTo } = useApp();

  return (
    <footer className="bg-[#0D1524] text-slate-300 border-t border-slate-800 pt-20 pb-14">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Footer Columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12 lg:gap-14 pb-16 border-b border-slate-800">
          {/* Column 1: Brand Signature & Institutional Identity */}
          <div className="lg:col-span-5 space-y-6">
            <CrbemLogo variant="light" size="lg" />

            <div className="pt-2">
              {/* Prominent Brand Signature Wordmark */}
              <div className="font-display font-extrabold text-5xl sm:text-6xl text-white/90 tracking-tight select-none">
                CRBEM
              </div>
              <div className="text-[15px] font-medium text-slate-200 mt-2">
                Christ Redemption Bible Evangelical Mission Theological Seminary
              </div>
            </div>

            <p className="text-[15px] text-slate-400 font-sans leading-relaxed max-w-md">
              A premier theological institution dedicated to faithful biblical exegesis, historic evangelical doctrine, pastoral holiness, and global gospel service.
            </p>

            <div className="pt-2 flex items-center gap-3 text-sm text-slate-300">
              <span className="font-sans text-slate-400">Founded 1984</span>
              <span className="text-slate-600">·</span>
              <span className="text-[#FC8B0A] font-medium">Equipping Workmen Approved unto God</span>
            </div>
          </div>

          {/* Column 2: Academic Programmes */}
          <div className="lg:col-span-2 space-y-4">
            <h4 className="font-display text-base font-bold text-white tracking-normal">
              Programmes
            </h4>
            <ul className="space-y-3 text-[15px] text-slate-400">
              <li>
                <button
                  type="button"
                  onClick={() => navigateTo('programme-detail', 'prog-cth')}
                  className="hover:text-[#FC8B0A] transition-colors text-left cursor-pointer"
                >
                  Certificate (C.Th.)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => navigateTo('programme-detail', 'prog-dipth')}
                  className="hover:text-[#FC8B0A] transition-colors text-left cursor-pointer"
                >
                  Diploma (Dip.Th.)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => navigateTo('programme-detail', 'prog-bth')}
                  className="hover:text-[#FC8B0A] transition-colors text-left cursor-pointer"
                >
                  Bachelor (B.Th.)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => navigateTo('programme-detail', 'prog-pgdth')}
                  className="hover:text-[#FC8B0A] transition-colors text-left cursor-pointer"
                >
                  PG Diploma (PGD.Th.)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => navigateTo('programme-detail', 'prog-mth')}
                  className="hover:text-[#FC8B0A] transition-colors text-left cursor-pointer"
                >
                  Master of Theology (M.Th.)
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Seminary Institutional Links */}
          <div className="lg:col-span-2 space-y-4">
            <h4 className="font-display text-base font-bold text-white tracking-normal">
              Seminary
            </h4>
            <ul className="space-y-3 text-[15px] text-slate-400">
              <li>
                <button
                  type="button"
                  onClick={() => navigateTo('admissions')}
                  className="hover:text-[#FC8B0A] transition-colors text-left cursor-pointer"
                >
                  Admissions
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => navigateTo('library')}
                  className="hover:text-[#FC8B0A] transition-colors text-left cursor-pointer"
                >
                  Digital Library
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => navigateTo('news')}
                  className="hover:text-[#FC8B0A] transition-colors text-left cursor-pointer"
                >
                  Academic Bulletin
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => navigateTo('academic-home')}
                  className="hover:text-[#FC8B0A] transition-colors text-left cursor-pointer"
                >
                  Academic Home
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => navigateTo('student-portal')}
                  className="hover:text-[#FC8B0A] transition-colors text-left cursor-pointer"
                >
                  Student Portal
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => navigateTo('statement-of-faith')}
                  className="hover:text-[#FC8B0A] transition-colors text-left cursor-pointer"
                >
                  Statement of Faith
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => navigateTo('faculty')}
                  className="hover:text-[#FC8B0A] transition-colors text-left cursor-pointer"
                >
                  Faculty Senate
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: Contact & Campus Info */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="font-display text-base font-bold text-white tracking-normal">
              Contact
            </h4>
            <ul className="space-y-3 text-[15px] text-slate-400">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#FC8B0A] shrink-0 mt-1" />
                <span>KM 42, Lagos-Ibadan Expressway, Nigeria</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#FC8B0A] shrink-0" />
                <span>+234 803 000 CRBEM</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#FC8B0A] shrink-0" />
                <span>admissions@crbemseminary.edu.ng</span>
              </li>
              <li className="flex items-start gap-2.5">
                <Clock className="w-4 h-4 text-[#FC8B0A] shrink-0 mt-1" />
                <span>Mon – Fri: 8:00 AM – 5:00 PM (WAT)</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Clean Bottom Bar */}
        <div className="pt-10 flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-slate-400">
          <div>
            © {new Date().getFullYear()} Christ Redemption Bible Evangelical Mission Theological Seminary. All rights reserved.
          </div>
          <div className="flex flex-wrap items-center gap-6">
            <button
              type="button"
              onClick={() => navigateTo('statement-of-faith')}
              className="hover:text-[#FC8B0A] transition-colors cursor-pointer"
            >
              Statement of Faith
            </button>
            <button
              type="button"
              onClick={() => navigateTo('academic-home')}
              className="hover:text-[#FC8B0A] transition-colors cursor-pointer"
            >
              Academic Directorate
            </button>
            <button
              type="button"
              onClick={() => navigateTo('contact')}
              className="hover:text-[#FC8B0A] transition-colors cursor-pointer"
            >
              Registrar Helpline
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
