/**
 * CRBEM Theological Seminary - Master Navigation Header
 * Redesigned to strictly match Learnora:
 * - Clean 5-link primary public menu: Home, Programmes, Admissions, Library, Contact
 * - Right side: Sign In, Apply Now
 * - Clean Learnora typography (15px Inter font-medium), refined spacing, no crowded tabs
 */

import React, { useState } from 'react';
import { useApp, AppView } from '../../context/AppContext';
import { CrbemLogo } from './CrbemLogo';
import {
  Menu,
  X,
  BookOpen,
  GraduationCap,
  Library,
  UserCheck,
  Shield,
  Bell,
  ChevronDown,
  LogOut,
  Phone,
  FileText,
  Calendar,
  Building2
} from 'lucide-react';

export const AppHeader: React.FC = () => {
  const {
    currentView,
    navigateTo,
    currentRole,
    currentUser,
    logout,
    quickSwitchPersona,
    notifications,
    markNotificationRead
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [personaMenuOpen, setPersonaMenuOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);

  const unreadNotifs = notifications.filter((n) => !n.read).length;

  // Active section identification for primary 5 links
  const isHome = currentView === 'public-home' || currentView === 'about' || currentView === 'seminary-life';
  const isProgrammes = currentView === 'programmes' || currentView === 'programme-detail';
  const isAdmissions = currentView === 'admissions' || currentView === 'tuition-fees';
  const isLibrary = currentView === 'library';
  const isContact = currentView === 'contact';

  const isApplicantArea = currentView === 'applicant-portal' || currentView === 'auth-register';
  const isStudentArea = currentView.startsWith('student-') || currentView === 'course-detail';
  const isAdminArea = currentView === 'admin-portal';

  const handleNav = (view: AppView) => {
    navigateTo(view);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-[#E5E7EB] transition-all">
      {/* Top Academic Sub-Bar: Motto & Live Persona Selector */}
      <div className="bg-[#0D1524] text-slate-300 text-xs px-4 sm:px-8 py-2 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="font-sans text-slate-300 hidden md:inline text-[13px]">
            "Study to shew thyself approved unto God... rightly dividing the word of truth" — 2 Timothy 2:15
          </span>
          <span className="md:hidden font-sans text-slate-300 text-xs">
            CRBEM Theological Seminary
          </span>
        </div>

        {/* Live Persona Quick-Switcher & Status Indicator */}
        <div className="flex items-center gap-4">
          <div className="relative">
            <button
              type="button"
              onClick={() => setPersonaMenuOpen(!personaMenuOpen)}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-800/90 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs transition-colors cursor-pointer"
              title="Switch role view for demonstration"
            >
              <span className="text-[#FC8B0A] font-medium">Role:</span>
              <span className="font-medium text-white">{currentRole}</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {personaMenuOpen && (
              <div
                className="absolute right-0 mt-1 w-52 bg-white rounded-lg border border-[#E5E7EB] shadow-xl text-[#0D0D0E] z-50 py-1.5 animate-fade-in"
                onMouseLeave={() => setPersonaMenuOpen(false)}
              >
                <div className="px-3 py-1.5 border-b border-slate-100 text-xs text-[#667085] font-medium">
                  Test Personas (One-Click)
                </div>
                <button
                  type="button"
                  onClick={() => { quickSwitchPersona('Guest'); setPersonaMenuOpen(false); }}
                  className="w-full text-left px-3 py-1.5 text-xs hover:bg-[#F5F6F8] flex items-center justify-between"
                >
                  <span>Prospective Candidate (Guest)</span>
                  {currentRole === 'Guest' && <span className="w-1.5 h-1.5 rounded-full bg-[#FC8B0A]" />}
                </button>
                <button
                  type="button"
                  onClick={() => { quickSwitchPersona('Applicant'); setPersonaMenuOpen(false); }}
                  className="w-full text-left px-3 py-1.5 text-xs hover:bg-[#F5F6F8] flex items-center justify-between"
                >
                  <span>Pastor Babalola (Candidate)</span>
                  {currentRole === 'Applicant' && <span className="w-1.5 h-1.5 rounded-full bg-[#FC8B0A]" />}
                </button>
                <button
                  type="button"
                  onClick={() => { quickSwitchPersona('Student'); setPersonaMenuOpen(false); }}
                  className="w-full text-left px-3 py-1.5 text-xs hover:bg-[#F5F6F8] flex items-center justify-between"
                >
                  <span>Adeyemi Samuel (B.Th. Student)</span>
                  {currentRole === 'Student' && <span className="w-1.5 h-1.5 rounded-full bg-[#FC8B0A]" />}
                </button>
                <button
                  type="button"
                  onClick={() => { quickSwitchPersona('Registrar'); setPersonaMenuOpen(false); }}
                  className="w-full text-left px-3 py-1.5 text-xs hover:bg-[#F5F6F8] flex items-center justify-between"
                >
                  <span>Dr. Olawale (Registrar)</span>
                  {currentRole === 'Registrar' && <span className="w-1.5 h-1.5 rounded-full bg-[#FC8B0A]" />}
                </button>
              </div>
            )}
          </div>

          <div className="hidden lg:flex items-center gap-1.5 text-slate-400 hover:text-white transition-colors text-xs">
            <Phone className="w-3.5 h-3.5 text-[#FC8B0A]" />
            <span>+234 803 000 CRBEM</span>
          </div>
        </div>
      </div>

      {/* Main Bar */}
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-6">
        {/* Institutional Brand */}
        <button
          type="button"
          onClick={() => handleNav('public-home')}
          className="cursor-pointer text-left focus:outline-none shrink-0"
        >
          <CrbemLogo variant="dark" size="md" />
        </button>

        {/* Clean 5-Item Primary Public Navigation (Learnora proportions) */}
        <nav className="hidden lg:flex items-center gap-8">
          <button
            type="button"
            onClick={() => handleNav('public-home')}
            className={`text-[15px] font-medium transition-colors cursor-pointer relative py-1 ${
              isHome
                ? 'text-[#0D0D0E] font-semibold'
                : 'text-[#4E5161] hover:text-[#0D0D0E]'
            }`}
          >
            <span>Home</span>
            {isHome && <span className="absolute -bottom-1 left-0 right-0 h-0.5 bg-[#FC8B0A]" />}
          </button>

          <button
            type="button"
            onClick={() => handleNav('programmes')}
            className={`text-[15px] font-medium transition-colors cursor-pointer relative py-1 ${
              isProgrammes
                ? 'text-[#0D0D0E] font-semibold'
                : 'text-[#4E5161] hover:text-[#0D0D0E]'
            }`}
          >
            <span>Programmes</span>
            {isProgrammes && <span className="absolute -bottom-1 left-0 right-0 h-0.5 bg-[#FC8B0A]" />}
          </button>

          <button
            type="button"
            onClick={() => handleNav('admissions')}
            className={`text-[15px] font-medium transition-colors cursor-pointer relative py-1 ${
              isAdmissions
                ? 'text-[#0D0D0E] font-semibold'
                : 'text-[#4E5161] hover:text-[#0D0D0E]'
            }`}
          >
            <span>Admissions</span>
            {isAdmissions && <span className="absolute -bottom-1 left-0 right-0 h-0.5 bg-[#FC8B0A]" />}
          </button>

          <button
            type="button"
            onClick={() => handleNav('library')}
            className={`text-[15px] font-medium transition-colors cursor-pointer relative py-1 flex items-center gap-1.5 ${
              isLibrary
                ? 'text-[#0D0D0E] font-semibold'
                : 'text-[#4E5161] hover:text-[#0D0D0E]'
            }`}
          >
            <span>Library</span>
            {isLibrary && <span className="absolute -bottom-1 left-0 right-0 h-0.5 bg-[#FC8B0A]" />}
          </button>

          <button
            type="button"
            onClick={() => handleNav('contact')}
            className={`text-[15px] font-medium transition-colors cursor-pointer relative py-1 ${
              isContact
                ? 'text-[#0D0D0E] font-semibold'
                : 'text-[#4E5161] hover:text-[#0D0D0E]'
            }`}
          >
            <span>Contact</span>
            {isContact && <span className="absolute -bottom-1 left-0 right-0 h-0.5 bg-[#FC8B0A]" />}
          </button>
        </nav>

        {/* Action Controls & Portal Entries (Right side) */}
        <div className="flex items-center gap-3">
          {/* Notifications Dropdown (when user has notifications) */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setNotificationsOpen(!notificationsOpen)}
              className="p-2 text-slate-600 hover:text-[#0D0D0E] hover:bg-[#F5F6F8] rounded-full transition-colors relative cursor-pointer"
              aria-label="Academic Notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadNotifs > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#FC8B0A]" />
              )}
            </button>

            {notificationsOpen && (
              <div
                className="absolute right-0 mt-2 w-80 bg-white rounded-xl border border-[#E5E7EB] shadow-xl text-[#0D0D0E] z-50 p-3 animate-fade-in"
                onMouseLeave={() => setNotificationsOpen(false)}
              >
                <div className="flex items-center justify-between pb-2 border-b border-slate-100 mb-2">
                  <span className="text-xs font-semibold text-[#0D0D0E]">
                    Seminary Notifications ({unreadNotifs})
                  </span>
                  <span className="text-[11px] text-[#667085]">Academic Session 2026/27</span>
                </div>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {notifications.map((notif) => (
                    <div
                      key={notif.id}
                      onClick={() => markNotificationRead(notif.id)}
                      className={`p-2.5 rounded-lg text-xs cursor-pointer transition-colors ${
                        notif.read ? 'bg-[#F5F6F8] text-[#667085]' : 'bg-amber-50/60 border border-amber-100 text-[#0D0D0E]'
                      }`}
                    >
                      <div className="font-semibold">{notif.title}</div>
                      <div className="text-[11px] mt-0.5 text-slate-600">{notif.message}</div>
                      <div className="text-[10px] text-slate-400 mt-1">{notif.date}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right Side: Sign In & Apply Now (or Auth Portal Shortcut if logged in) */}
          {currentUser ? (
            <div className="flex items-center gap-2">
              {currentUser.role === 'Applicant' && (
                <button
                  type="button"
                  onClick={() => handleNav('applicant-portal')}
                  className={`px-4 py-2 text-[14px] font-medium rounded-full border transition-all cursor-pointer flex items-center gap-1.5 ${
                    isApplicantArea
                      ? 'bg-[#0D0D0E] text-white border-[#0D0D0E]'
                      : 'border-[#E5E7EB] text-[#0D0D0E] hover:border-[#FC8B0A]'
                  }`}
                >
                  <UserCheck className="w-3.5 h-3.5 text-[#FC8B0A]" />
                  <span>Applicant Portal</span>
                </button>
              )}

              {currentUser.role === 'Student' && (
                <button
                  type="button"
                  onClick={() => handleNav('student-portal')}
                  className={`px-4 py-2 text-[14px] font-medium rounded-full border transition-all cursor-pointer flex items-center gap-1.5 ${
                    isStudentArea
                      ? 'bg-[#0D0D0E] text-white border-[#0D0D0E]'
                      : 'border-[#E5E7EB] text-[#0D0D0E] hover:border-[#FC8B0A]'
                  }`}
                >
                  <GraduationCap className="w-3.5 h-3.5 text-[#FC8B0A]" />
                  <span>Student Portal</span>
                </button>
              )}

              {['Super Admin', 'Registrar', 'Admissions Officer', 'Lecturer', 'Librarian', 'Finance Officer'].includes(currentUser.role) && (
                <button
                  type="button"
                  onClick={() => handleNav('admin-portal')}
                  className={`px-4 py-2 text-[14px] font-medium rounded-full border transition-all cursor-pointer flex items-center gap-1.5 ${
                    isAdminArea
                      ? 'bg-[#0D0D0E] text-white border-[#0D0D0E]'
                      : 'border-[#E5E7EB] text-[#0D0D0E] hover:border-[#FC8B0A]'
                  }`}
                >
                  <Shield className="w-3.5 h-3.5 text-[#FC8B0A]" />
                  <span>Seminary Admin</span>
                </button>
              )}

              <button
                type="button"
                onClick={logout}
                className="p-2 text-slate-500 hover:text-rose-600 hover:bg-slate-100 rounded-full transition-colors cursor-pointer"
                title="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => handleNav('auth-login')}
                className="text-[15px] font-medium text-[#0D0D0E] hover:text-[#FC8B0A] transition-colors cursor-pointer px-3 py-2"
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => handleNav('auth-register')}
                className="px-5 py-2.5 text-[15px] font-medium text-white bg-[#0D0D0E] hover:bg-[#FC8B0A] rounded-full transition-all cursor-pointer shadow-xs"
              >
                Apply Now
              </button>
            </div>
          )}

          {/* Mobile Navigation Drawer Toggle */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-slate-700 hover:text-[#0D0D0E] hover:bg-slate-100 rounded-md transition-colors"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-x-0 top-20 bottom-0 bg-[#0D1524]/50 z-50">
          <div className="bg-white border-b border-[#E5E7EB] shadow-2xl p-5 max-h-[85vh] overflow-y-auto animate-slide-in">
            <div className="space-y-1 mb-6">
              <button
                type="button"
                onClick={() => handleNav('public-home')}
                className="w-full text-left px-3 py-2.5 text-base font-medium rounded-md hover:bg-[#F5F6F8] flex items-center justify-between"
              >
                <span>Home</span>
                <Building2 className="w-4 h-4 text-slate-400" />
              </button>
              <button
                type="button"
                onClick={() => handleNav('programmes')}
                className="w-full text-left px-3 py-2.5 text-base font-medium rounded-md hover:bg-[#F5F6F8] flex items-center justify-between"
              >
                <span>Programmes</span>
                <BookOpen className="w-4 h-4 text-slate-400" />
              </button>
              <button
                type="button"
                onClick={() => handleNav('admissions')}
                className="w-full text-left px-3 py-2.5 text-base font-medium rounded-md hover:bg-[#F5F6F8] flex items-center justify-between"
              >
                <span>Admissions</span>
                <FileText className="w-4 h-4 text-slate-400" />
              </button>
              <button
                type="button"
                onClick={() => handleNav('library')}
                className="w-full text-left px-3 py-2.5 text-base font-medium rounded-md hover:bg-[#F5F6F8] flex items-center justify-between"
              >
                <span>Digital Library</span>
                <Library className="w-4 h-4 text-slate-400" />
              </button>
              <button
                type="button"
                onClick={() => handleNav('contact')}
                className="w-full text-left px-3 py-2.5 text-base font-medium rounded-md hover:bg-[#F5F6F8] flex items-center justify-between"
              >
                <span>Contact</span>
                <Phone className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            {/* Additional Secondary Institutional Links */}
            <div className="pt-4 border-t border-[#E5E7EB] space-y-1 mb-6 text-sm">
              <div className="text-[12px] font-medium text-[#667085] px-3 py-1">
                Institutional Portals
              </div>
              <button
                type="button"
                onClick={() => handleNav('academic-home')}
                className="w-full text-left px-3 py-2 text-slate-700 hover:bg-[#F5F6F8] rounded-md flex items-center justify-between"
              >
                <span>Academic Home Portal</span>
                <GraduationCap className="w-4 h-4 text-slate-400" />
              </button>
              <button
                type="button"
                onClick={() => handleNav('news')}
                className="w-full text-left px-3 py-2 text-slate-700 hover:bg-[#F5F6F8] rounded-md flex items-center justify-between"
              >
                <span>Academic Bulletin</span>
                <Calendar className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            <div className="pt-4 border-t border-[#E5E7EB] flex flex-col gap-2.5">
              {!currentUser ? (
                <>
                  <button
                    type="button"
                    onClick={() => handleNav('auth-login')}
                    className="w-full py-3 text-center text-sm font-medium border border-[#E5E7EB] rounded-full text-[#0D0D0E] hover:bg-[#F5F6F8]"
                  >
                    Sign In to Portal
                  </button>
                  <button
                    type="button"
                    onClick={() => handleNav('auth-register')}
                    className="w-full py-3 text-center text-sm font-medium bg-[#0D0D0E] text-white rounded-full hover:bg-[#FC8B0A]"
                  >
                    Apply Now for 2026/2027
                  </button>
                </>
              ) : (
                <button
                  type="button"
                  onClick={logout}
                  className="w-full py-3 text-center text-sm font-medium text-rose-600 bg-rose-50 rounded-full"
                >
                  Sign Out
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
