/**
 * CRBEM Theological Seminary - Academic Status & Metadata Indicators
 * Adheres strictly to Zero-Pill Discipline: unboxed clean text or quiet typographic markers
 */

import React from 'react';
import { ApplicationStatus } from '../../types';

interface StatusBadgeProps {
  status: ApplicationStatus | 'Registered' | 'Pending Fees' | 'Active' | 'Returned' | 'Overdue' | 'Submitted' | 'Graded' | 'Normal' | 'High' | 'Urgent';
  showDot?: boolean;
  className?: string;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({
  status,
  showDot = true,
  className = ''
}) => {
  // Map statuses to restrained institutional colors (no garish candy capsules)
  let dotColor = 'bg-slate-400';
  let textColor = 'text-slate-700';

  switch (status) {
    case 'Matriculated':
    case 'Registered':
    case 'Active':
    case 'Graded':
      dotColor = 'bg-emerald-600';
      textColor = 'text-emerald-800';
      break;
    case 'Offer Issued':
      dotColor = 'bg-[#FC8B0A]';
      textColor = 'text-[#FC8B0A]';
      break;
    case 'In Review':
    case 'Interview Scheduled':
    case 'Decision Pending':
    case 'Submitted':
      dotColor = 'bg-blue-600';
      textColor = 'text-blue-800';
      break;
    case 'Declined':
    case 'Overdue':
    case 'Urgent':
      dotColor = 'bg-rose-600';
      textColor = 'text-rose-800';
      break;
    case 'On Hold':
    case 'Pending Fees':
    case 'High':
      dotColor = 'bg-amber-600';
      textColor = 'text-amber-800';
      break;
    case 'Returned':
    case 'Normal':
    default:
      dotColor = 'bg-slate-500';
      textColor = 'text-slate-700';
      break;
  }

  return (
    <span className={`inline-flex items-center gap-1.5 text-xs font-medium tracking-tight ${textColor} ${className}`}>
      {showDot && (
        <span
          className={`w-1.5 h-1.5 rounded-full ${dotColor}`}
          aria-hidden="true"
        />
      )}
      <span>{status}</span>
    </span>
  );
};
