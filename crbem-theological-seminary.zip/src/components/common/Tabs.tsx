/**
 * CRBEM Theological Seminary - Accessible Tabs & Segmented Controls
 * Clean segmented control container with subtle hover states
 */

import React from 'react';

export interface TabItem<T extends string = string> {
  id: T;
  label: string;
  count?: number;
  icon?: React.ReactNode;
}

interface TabsProps<T extends string> {
  tabs: TabItem<T>[];
  activeTab: T;
  onChange: (id: T) => void;
  variant?: 'segmented' | 'underline';
  className?: string;
}

export function Tabs<T extends string>({
  tabs,
  activeTab,
  onChange,
  variant = 'segmented',
  className = ''
}: TabsProps<T>) {
  if (variant === 'underline') {
    return (
      <div className={`border-b border-[#E5E7EB] flex items-center gap-6 overflow-x-auto ${className}`}>
        {tabs.map((tab) => {
          const isActive = tab.id === activeTab;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => onChange(tab.id)}
              className={`pb-3 text-sm font-medium transition-all relative flex items-center gap-2 whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'text-[#0D0D0E] font-semibold'
                  : 'text-[#667085] hover:text-[#0D0D0E]'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
              {typeof tab.count === 'number' && (
                <span className="text-xs text-[#667085] bg-slate-100 px-1.5 py-0.2 rounded-xs font-mono">
                  {tab.count}
                </span>
              )}
              {isActive && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#FC8B0A]" />
              )}
            </button>
          );
        })}
      </div>
    );
  }

  return (
    <div className={`inline-flex items-center gap-1 p-1 bg-[#F5F6F8] rounded-lg border border-[#E5E7EB] ${className}`}>
      {tabs.map((tab) => {
        const isActive = tab.id === activeTab;
        return (
          <button
            key={tab.id}
            type="button"
            onClick={() => onChange(tab.id)}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              isActive
                ? 'bg-white text-[#0D0D0E] shadow-xs font-semibold'
                : 'text-[#667085] hover:text-[#0D0D0E]'
            }`}
          >
            {tab.icon}
            <span>{tab.label}</span>
            {typeof tab.count === 'number' && (
              <span className={`text-[11px] ${isActive ? 'text-[#FC8B0A]' : 'text-[#667085]'}`}>
                ({tab.count})
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}
