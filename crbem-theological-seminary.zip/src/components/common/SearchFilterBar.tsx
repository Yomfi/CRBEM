/**
 * CRBEM Theological Seminary - Search & Filter Control Bar
 */

import React from 'react';
import { Search, X } from 'lucide-react';

interface SearchFilterBarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  placeholder?: string;
  categories?: string[];
  selectedCategory?: string;
  onCategoryChange?: (category: string) => void;
  className?: string;
}

export const SearchFilterBar: React.FC<SearchFilterBarProps> = ({
  searchQuery,
  onSearchChange,
  placeholder = 'Search by keyword, author, or reference...',
  categories,
  selectedCategory,
  onCategoryChange,
  className = ''
}) => {
  return (
    <div className={`flex flex-col sm:flex-row items-stretch sm:items-center gap-3 ${className}`}>
      {/* Search Input Box */}
      <div className="relative flex-1">
        <Search className="w-4 h-4 text-[#667085] absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder={placeholder}
          className="w-full pl-10 pr-9 py-2.5 bg-white border border-[#E5E7EB] rounded-lg text-sm text-[#0D0D0E] placeholder:text-slate-400 focus:border-[#FC8B0A] focus:ring-1 focus:ring-[#FC8B0A] outline-none transition-all"
        />
        {searchQuery && (
          <button
            type="button"
            onClick={() => onSearchChange('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Category Dropdown if provided */}
      {categories && onCategoryChange && (
        <div className="sm:w-60">
          <select
            value={selectedCategory}
            onChange={(e) => onCategoryChange(e.target.value)}
            className="w-full py-2.5 px-3 bg-white border border-[#E5E7EB] rounded-lg text-sm text-[#0D0D0E] focus:border-[#FC8B0A] focus:ring-1 focus:ring-[#FC8B0A] outline-none transition-all cursor-pointer"
          >
            {categories.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>
      )}
    </div>
  );
};
