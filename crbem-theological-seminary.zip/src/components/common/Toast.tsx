/**
 * CRBEM Theological Seminary - Non-intrusive Toast Notifications
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { CheckCircle2, Info, AlertTriangle, AlertCircle, X } from 'lucide-react';

export const ToastContainer: React.FC = () => {
  const { toasts, removeToast } = useApp();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none">
      {toasts.map((toast) => {
        let Icon = Info;
        let borderColor = 'border-slate-300';
        let iconColor = 'text-blue-600';

        if (toast.type === 'success') {
          Icon = CheckCircle2;
          borderColor = 'border-emerald-300';
          iconColor = 'text-emerald-600';
        } else if (toast.type === 'warning') {
          Icon = AlertTriangle;
          borderColor = 'border-[#FC8B0A]/50';
          iconColor = 'text-[#FC8B0A]';
        } else if (toast.type === 'error') {
          Icon = AlertCircle;
          borderColor = 'border-rose-300';
          iconColor = 'text-rose-600';
        }

        return (
          <div
            key={toast.id}
            role="status"
            className={`pointer-events-auto bg-white border ${borderColor} rounded-lg shadow-lg p-3.5 flex items-start gap-3 transition-all animate-slide-in`}
          >
            <Icon className={`w-4 h-4 mt-0.5 shrink-0 ${iconColor}`} />
            <div className="flex-1 min-w-0">
              <h4 className="text-xs font-semibold text-[#0D0D0E] leading-snug">
                {toast.title}
              </h4>
              {toast.description && (
                <p className="text-[11px] text-[#667085] mt-0.5 leading-normal">
                  {toast.description}
                </p>
              )}
            </div>
            <button
              type="button"
              onClick={() => removeToast(toast.id)}
              className="text-slate-400 hover:text-slate-600 p-0.5 rounded-sm transition-colors"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
