/**
 * CRBEM Theological Seminary - Academic Empty State
 */

import React from 'react';
import { BookOpen } from 'lucide-react';

interface EmptyStateProps {
  title: string;
  description: string;
  actionText?: string;
  onAction?: () => void;
  icon?: React.ReactNode;
  className?: string;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  title,
  description,
  actionText,
  onAction,
  icon,
  className = ''
}) => {
  return (
    <div className={`p-10 border border-dashed border-[#E5E7EB] rounded-xl bg-[#F5F6F8]/50 text-center flex flex-col items-center justify-center ${className}`}>
      <div className="w-12 h-12 rounded-lg bg-white border border-[#E5E7EB] flex items-center justify-center text-[#667085] mb-3 shadow-xs">
        {icon || <BookOpen className="w-6 h-6 text-[#FC8B0A]" />}
      </div>
      <h3 className="font-display text-base font-semibold text-[#0D0D0E] mb-1">
        {title}
      </h3>
      <p className="text-xs text-[#667085] max-w-sm mb-4 leading-relaxed font-sans">
        {description}
      </p>
      {actionText && onAction && (
        <button
          type="button"
          onClick={onAction}
          className="px-4 py-2 bg-[#0D0D0E] hover:bg-[#0D1524] text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
        >
          {actionText}
        </button>
      )}
    </div>
  );
};
