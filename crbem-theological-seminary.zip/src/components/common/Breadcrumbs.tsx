/**
 * CRBEM Theological Seminary - Academic Breadcrumbs
 * Clean typographic path with navigation support
 */

import React from 'react';
import { ChevronRight } from 'lucide-react';
import { useApp, AppView } from '../../context/AppContext';

export interface BreadcrumbItem {
  label: string;
  view?: AppView;
  paramId?: string;
}

interface BreadcrumbsProps {
  items: BreadcrumbItem[];
  className?: string;
}

export const Breadcrumbs: React.FC<BreadcrumbsProps> = ({ items, className = '' }) => {
  const { navigateTo } = useApp();

  return (
    <nav aria-label="Breadcrumb" className={`flex items-center text-xs text-[#667085] ${className}`}>
      <ol className="flex items-center space-x-1.5 flex-wrap">
        {items.map((item, idx) => {
          const isLast = idx === items.length - 1;

          return (
            <li key={idx} className="flex items-center space-x-1.5">
              {idx > 0 && <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />}
              {isLast || !item.view ? (
                <span className={`font-medium ${isLast ? 'text-[#0D0D0E]' : 'text-[#667085]'}`}>
                  {item.label}
                </span>
              ) : (
                <button
                  type="button"
                  onClick={() => item.view && navigateTo(item.view, item.paramId)}
                  className="hover:text-[#FC8B0A] transition-colors cursor-pointer underline-offset-2 hover:underline"
                >
                  {item.label}
                </button>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
};
