/**
 * CRBEM Theological Seminary - Official Emblem & Crest
 * Authentic academic seal with open Bible, cross, and golden torch
 */

import React from 'react';

interface CrbemLogoProps {
  variant?: 'light' | 'dark' | 'symbol-only';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export const CrbemLogo: React.FC<CrbemLogoProps> = ({
  variant = 'dark',
  size = 'md',
  className = ''
}) => {
  const isLight = variant === 'light'; // Light text on dark bg

  const iconSizes = {
    sm: 'w-7 h-7',
    md: 'w-9 h-9',
    lg: 'w-12 h-12'
  };

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Institutional Crest SVG */}
      <div
        className={`${iconSizes[size]} shrink-0 relative flex items-center justify-center rounded-lg bg-[#0D1524] border border-[#FC8B0A]/40 shadow-xs`}
        title="Christ Redemption Bible Evangelical Mission Theological Seminary"
      >
        <svg
          viewBox="0 0 40 40"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full p-1.5"
        >
          {/* Shield Base */}
          <path
            d="M20 4L32 8.5V19C32 26.5 26.8 33.2 20 35.5C13.2 33.2 8 26.5 8 19V8.5L20 4Z"
            fill="#0D1524"
            stroke="#FC8B0A"
            strokeWidth="1.75"
            strokeLinejoin="round"
          />
          {/* Open Bible Pages */}
          <path
            d="M14 24C17 22.5 19.5 23 20 23.5C20.5 23 23 22.5 26 24V14C23 12.5 20.5 13 20 13.5C19.5 13 17 12.5 14 14V24Z"
            fill="#FFFFFF"
            fillOpacity="0.12"
            stroke="#FFFFFF"
            strokeWidth="1.2"
            strokeLinejoin="round"
          />
          {/* Center Cross */}
          <path
            d="M20 11V26M16.5 16H23.5"
            stroke="#FC8B0A"
            strokeWidth="1.75"
            strokeLinecap="round"
          />
          {/* Small Star / Divine Light */}
          <circle cx="20" cy="8" r="1.25" fill="#FC8B0A" />
        </svg>
      </div>

      {variant !== 'symbol-only' && (
        <div className="flex flex-col text-left leading-none">
          <div className="flex items-center gap-1.5">
            <span
              className={`font-display tracking-tight font-extrabold ${
                size === 'sm' ? 'text-base' : size === 'lg' ? 'text-xl' : 'text-lg'
              } ${isLight ? 'text-white' : 'text-[#0D0D0E]'}`}
            >
              CRBEM
            </span>
            <span className="text-xs font-sans font-semibold text-[#FC8B0A] tracking-normal">
              Seminary
            </span>
          </div>
          <span
            className={`text-xs font-sans tracking-normal mt-0.5 ${
              isLight ? 'text-slate-300' : 'text-[#667085]'
            }`}
          >
            Theological Seminary
          </span>
        </div>
      )}
    </div>
  );
};
