/**
 * CRBEM Theological Seminary - Academic Bulletin & News
 * Institutional publications, convocation updates, and theological research colloquia
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Breadcrumbs } from '../common/Breadcrumbs';
import { Calendar, Bell, ArrowRight, Tag, BookOpen, Share2 } from 'lucide-react';

export const AcademicBulletinView: React.FC = () => {
  const { announcements, navigateTo, addToast } = useApp();

  const bulletins = [
    {
      id: 'b-1',
      title: 'CRBEM Seminary Celebrates 40 Years of Theological Rigor and Missionary Expansion',
      date: 'October 04, 2026',
      category: 'Seminary Milestone',
      excerpt: 'Four decades after its founding in 1984, the Seminary releases its special commemorative monograph chronicling graduates serving across 24 nations in pastoral leadership, bible translation, and pioneer evangelism.',
      author: 'Office of the Rector'
    },
    {
      id: 'b-2',
      title: 'Faculty Monograph: "The Grammatical-Historical Integrity of Pauline Epistles"',
      date: 'September 28, 2026',
      category: 'Faculty Research',
      excerpt: 'Published by Ven. Prof. Jeremiah K. Alabi and Pastor Grace Adebayo, this scholarly study in Koine Greek syntax addresses modern revisionist hermeneutics and reinforces apostolic orthodoxy.',
      author: 'Department of Biblical Studies'
    },
    {
      id: 'b-3',
      title: 'Annual Expository Hermeneutics Lectures & Spiritual Emphasis Week Announced',
      date: 'September 15, 2026',
      category: 'Spiritual Life',
      excerpt: 'All enrolled undergraduate and postgraduate scholars will gather for five days of intensive morning expositions from the book of Titus under the theme "Holding Fast the Faithful Word".',
      author: 'Chapel Directorate'
    }
  ];

  return (
    <div className="py-10 bg-[#F5F6F8]">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <Breadcrumbs
          items={[
            { label: 'Seminary Home', view: 'public-home' },
            { label: 'Academic Bulletin & Gazette' }
          ]}
        />

        <div className="bg-[#0D1524] text-white rounded-xl p-8 border border-slate-800 shadow-sm space-y-2">
          <div className="text-[12px] font-medium text-[#FC8B0A]">
            Institutional Publications & Notices
          </div>
          <h1 className="font-display text-3xl font-bold text-white tracking-tight">
            The Academic Bulletin & Gazette
          </h1>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            Scholarly dispatches, theological colloquia announcements, convocation updates, and administrative directives from the Seminary Senate.
          </p>
        </div>

        {/* Official Announcements Column & Articles */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-8 space-y-6">
            <h2 className="font-display text-xl font-bold text-[#0D0D0E]">
              Feature Bulletins & Research Dispatches
            </h2>

            <div className="space-y-5">
              {bulletins.map((item) => (
                <article
                  key={item.id}
                  className="bg-white rounded-xl border border-[#E5E7EB] p-7 shadow-xs space-y-3 hover:border-slate-400 transition-colors"
                >
                  <div className="flex items-center justify-between text-xs text-[#667085]">
                    <span className="text-[#FC8B0A] font-semibold">{item.category}</span>
                    <span className="font-mono">{item.date}</span>
                  </div>

                  <h3 className="font-display text-lg font-bold text-[#0D0D0E] leading-snug">
                    {item.title}
                  </h3>

                  <p className="text-xs text-slate-700 leading-relaxed font-sans">
                    {item.excerpt}
                  </p>

                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="text-slate-500 font-medium">By {item.author}</span>
                    <button
                      type="button"
                      onClick={() => addToast('Article Record', 'Full paper text archived in Seminary Repository.', 'info')}
                      className="text-[#0D0D0E] font-semibold hover:text-[#FC8B0A] flex items-center gap-1 cursor-pointer"
                    >
                      <span>Read Publication &rarr;</span>
                    </button>
                  </div>
                </article>
              ))}
            </div>
          </div>

          <div className="lg:col-span-4 space-y-6">
            <div className="bg-white rounded-xl border border-[#E5E7EB] p-6 shadow-xs space-y-4">
              <div className="flex items-center gap-2 pb-3 border-b border-[#E5E7EB]">
                <Bell className="w-4 h-4 text-[#FC8B0A]" />
                <h3 className="font-display text-sm font-bold text-[#0D0D0E]">
                  Registrar Directives
                </h3>
              </div>

              <div className="space-y-3 text-xs">
                {announcements.map((ann) => (
                  <div key={ann.id} className="p-3 bg-[#F5F6F8] rounded-lg space-y-1">
                    <div className="font-mono text-[10px] text-slate-500">{ann.date}</div>
                    <div className="font-semibold text-[#0D0D0E]">{ann.title}</div>
                    <p className="text-[#667085] line-clamp-2">{ann.content}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
