/**
 * CRBEM Theological Seminary - Eductix-Style Image + Accordion Section
 * Large photograph on left + Large heading with single-expand accordion on right:
 * - Photograph: /src/assets/images/crbem_seminary_study_1791299511109.jpg
 * - Heading: "Formed for Ministry. Grounded in Scripture."
 * - Items:
 *     1. Biblical Scholarship: "Deep study of Scripture, theology and the biblical languages."
 *     2. Spiritual Formation: "Prayer, Christian character and disciplined life with Christ."
 *     3. Pastoral Preparation: "Preaching, shepherding, leadership and practical ministry."
 *     4. Global Mission: "Evangelism, discipleship and gospel service across cultures."
 * - Smooth height and opacity animation, only one expanded at a time.
 * - Mobile: image first, accordion beneath.
 */

import React, { useState, useEffect, useRef } from 'react';
import { ChevronDown, ArrowRight } from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface AccordionItem {
  id: string;
  number: string;
  title: string;
  description: string;
}

export const SeminaryAccordionSection: React.FC = () => {
  const { navigateTo } = useApp();
  const [activeId, setActiveId] = useState<string>('scholarship');
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.15 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const accordionItems: AccordionItem[] = [
    {
      id: 'scholarship',
      number: '01',
      title: 'Biblical Scholarship',
      description: 'Deep study of Scripture, theology and the biblical languages.'
    },
    {
      id: 'formation',
      number: '02',
      title: 'Spiritual Formation',
      description: 'Prayer, Christian character and disciplined life with Christ.'
    },
    {
      id: 'preparation',
      number: '03',
      title: 'Pastoral Preparation',
      description: 'Preaching, shepherding, leadership and practical ministry.'
    },
    {
      id: 'mission',
      number: '04',
      title: 'Global Mission',
      description: 'Evangelism, discipleship and gospel service across cultures.'
    }
  ];

  const toggleAccordion = (id: string) => {
    setActiveId((prev) => (prev === id ? '' : id));
  };

  return (
    <section
      ref={sectionRef}
      className="py-24 sm:py-28 lg:py-32 bg-[#F5F6F8] border-b border-[#E5E7EB]"
      id="ministry-formation"
    >
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Genuine Seminary Study Photograph (Mobile: first) */}
          <div
            className={`lg:col-span-6 order-1 transition-all duration-750 ease-out transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
              isVisible ? 'opacity-100 translate-y-0 scale-100' : 'opacity-0 translate-y-6 scale-[0.98]'
            }`}
          >
            <div className="relative rounded-2xl overflow-hidden border border-[#E5E7EB] shadow-md bg-white">
              <img
                src="/src/assets/images/crbem_seminary_study_1791299511109.jpg"
                alt="Theology students in academic classroom studying biblical exegesis"
                referrerPolicy="no-referrer"
                className="w-full h-[380px] sm:h-[460px] lg:h-[540px] object-cover object-center"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0D1524]/60 via-transparent to-transparent pointer-events-none" />
              <div className="absolute bottom-6 left-6 right-6 p-4 rounded-xl bg-white/90 backdrop-blur-md border border-white/50 text-[#0D0D0E] shadow-sm">
                <div className="text-xs font-semibold text-[#FC8B0A] mb-0.5">
                  Academic Lecture & Practicum
                </div>
                <div className="text-sm font-medium text-[#0D0D0E]">
                  Supervised exegetical seminars anchored in original texts
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Heading + Smooth Accordion */}
          <div
            className={`lg:col-span-6 order-2 space-y-8 transition-all duration-750 ease-out delay-150 transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
          >
            <div>
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-[#E5E7EB] text-[#0D0D0E] text-[15px] font-medium leading-[1.6] mb-4 shadow-xs">
                <span className="w-2 h-2 rounded-full bg-[#FC8B0A]" />
                <span>Distinctive Pedagogical Model</span>
              </div>
              <h2 className="learnora-section-h2 text-[#0D0D0E] mb-4">
                Formed for Ministry. Grounded in Scripture.
              </h2>
              <p className="learnora-body-lg text-[#667085]">
                Our academic framework combines classical theological disciplines with hands-on pastoral formation for lifetime kingdom fruitfulness.
              </p>
            </div>

            {/* Accordion Container */}
            <div className="space-y-3 pt-2">
              {accordionItems.map((item) => {
                const isOpen = activeId === item.id;
                return (
                  <div
                    key={item.id}
                    className={`rounded-xl border transition-all duration-300 overflow-hidden ${
                      isOpen
                        ? 'bg-white border-[#FC8B0A] shadow-sm'
                        : 'bg-white/80 border-[#E5E7EB] hover:border-slate-300'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => toggleAccordion(item.id)}
                      className="w-full px-6 py-5 text-left flex items-center justify-between gap-4 cursor-pointer focus:outline-none"
                      aria-expanded={isOpen}
                    >
                      <div className="flex items-center gap-4">
                        <span
                          className={`text-sm font-display font-bold ${
                            isOpen ? 'text-[#FC8B0A]' : 'text-slate-400'
                          }`}
                        >
                          {item.number}
                        </span>
                        <span
                          className={`text-lg font-display font-bold transition-colors ${
                            isOpen ? 'text-[#0D0D0E]' : 'text-[#0D0D0E]/80 hover:text-[#0D0D0E]'
                          }`}
                        >
                          {item.title}
                        </span>
                      </div>
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center transition-transform duration-300 ${
                          isOpen ? 'bg-[#FC8B0A] text-white rotate-180' : 'bg-[#F5F6F8] text-[#0D0D0E]'
                        }`}
                      >
                        <ChevronDown className="w-4 h-4" />
                      </div>
                    </button>

                    {/* Smooth Height Container */}
                    <div
                      className={`grid transition-all duration-300 ease-in-out ${
                        isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'
                      }`}
                    >
                      <div className="overflow-hidden">
                        <div className="px-6 pb-6 pt-1 text-[16px] text-[#4E5161] leading-[1.6] border-t border-slate-100/80">
                          {item.description}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={() => navigateTo('admissions')}
                className="learnora-btn px-7 py-3.5 bg-[#0D0D0E] hover:bg-[#0D1524] text-white rounded-full transition-all inline-flex items-center gap-2.5 cursor-pointer shadow-xs"
              >
                <span>Discover Admission Pathway</span>
                <ArrowRight className="w-4 h-4 text-[#FC8B0A]" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
