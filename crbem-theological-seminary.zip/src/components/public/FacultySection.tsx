/**
 * CRBEM Theological Seminary - Leadership & Faculty Roster
 * Academic pedigree, research specializations, institutional offices
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { Mail, BookOpen, MapPin, Award } from 'lucide-react';

export const FacultySection: React.FC = () => {
  const { faculty } = useApp();

  return (
    <section className="py-20 bg-[#F5F6F8] border-b border-[#E5E7EB]">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mb-14">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-[#E5E7EB] text-[#0D0D0E] text-[15px] font-medium leading-[1.6] mb-4 shadow-xs">
            <span className="w-2 h-2 rounded-full bg-[#FC8B0A]" />
            <span>Academic Senate & Faculty</span>
          </div>
          <h2 className="learnora-section-h2 text-[#0D0D0E] mb-4">
            Distinguished Theological Faculty
          </h2>
          <p className="learnora-body-lg text-[#667085]">
            Our professors are published scholars, ordained churchmen, and veteran pastoral leaders who mentor students both in the lecture hall and the prayer closet.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
          {faculty.map((member) => (
            <div
              key={member.id}
              className="bg-white rounded-xl border border-[#E5E7EB] p-7 flex flex-col justify-between hover:border-slate-400 transition-all shadow-xs"
            >
              <div>
                <div className="flex items-start justify-between pb-4 border-b border-slate-100 mb-4">
                  <div>
                    <span className="text-[12px] font-medium text-[#FC8B0A]">
                      {member.designation}
                    </span>
                    <h3 className="font-display text-base font-bold text-[#0D0D0E] mt-1 leading-snug">
                      {member.fullName}
                    </h3>
                  </div>
                </div>

                <div className="space-y-2 mb-5">
                  <div className="text-xs font-medium text-slate-700">
                    {member.title}
                  </div>
                  <div className="text-[11px] text-[#667085] font-display italic">
                    {member.qualification}
                  </div>
                  <div className="text-xs text-[#0D0D0E] pt-2">
                    <span className="font-medium text-slate-500">Specialization:</span>{' '}
                    <span>{member.specialization}</span>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-[#667085]">
                <div className="flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5 text-[#FC8B0A]" />
                  <span>{member.assignedCourses.join(', ')}</span>
                </div>
                <a
                  href={`mailto:${member.email}`}
                  className="text-slate-600 hover:text-[#FC8B0A] transition-colors"
                  title="Contact Lecturer"
                >
                  <Mail className="w-4 h-4" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
