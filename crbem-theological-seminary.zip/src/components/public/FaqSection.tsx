/**
 * CRBEM Theological Seminary - FAQ Section
 * Modeled after Eductix FAQ screenshot:
 * - Left column:
 *     Heading: "Frequently Asked Questions"
 *     Short sentence: "Helpful answers for prospective students and applicants."
 *     CTA: "Contact Admissions"
 * - Right column:
 *     Asymmetric 2 × 2 interactive cards with smooth expanded transitions
 * - Subtle 700ms entrance animation with scroll observer respecting prefers-reduced-motion
 */

import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { ChevronDown, ArrowRight } from 'lucide-react';

interface FaqItem {
  id: string;
  num: string;
  question: string;
  answer: string;
}

export const FaqSection: React.FC = () => {
  const { navigateTo } = useApp();
  const [openId, setOpenId] = useState<string>('who-can-apply');
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.15 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const faqs: FaqItem[] = [
    {
      id: 'who-can-apply',
      num: '01',
      question: 'Who can apply to CRBEM?',
      answer:
        'Born-again Christian believers with active church membership and verifiable pastoral recommendations discerning a call to pastoral, evangelistic, or theological service.'
    },
    {
      id: 'programmes-available',
      num: '02',
      question: 'What programmes are available?',
      answer:
        'Five accredited degree tracks: Certificate (C.Th.), Diploma (Dip.Th.), Bachelor of Theology (B.Th.), Postgraduate Diploma, and Master of Theology (M.Th.).'
    },
    {
      id: 'part-time',
      num: '03',
      question: 'Can I study part-time?',
      answer:
        'Yes. In addition to our full-time residential track, we offer Executive Part-Time and Modular Distance cohorts tailored for bi-vocational workers and active pastors.'
    },
    {
      id: 'admission-process',
      num: '04',
      question: 'How does the admission process work?',
      answer:
        'Submit an online application, upload credentials and pastoral recommendation, complete the spiritual entrance assessment, and receive your admissions decision.'
    }
  ];

  const toggleFaq = (id: string) => {
    setOpenId((prev) => (prev === id ? '' : id));
  };

  return (
    <section
      ref={sectionRef}
      className="py-24 sm:py-28 lg:py-32 bg-white border-b border-[#E5E7EB]"
      id="faq"
    >
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          {/* Left Column: Title, Short sentence & Contact Admissions CTA - 700ms */}
          <div
            className={`lg:col-span-5 space-y-6 transition-all duration-700 ease-out transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#F5F6F8] border border-[#E5E7EB] text-[#0D0D0E] text-[15px] font-medium leading-[1.6] mb-2 shadow-xs">
              <span className="w-2 h-2 rounded-full bg-[#FC8B0A]" />
              <span>Questions & Answers</span>
            </div>

            <h2 className="learnora-section-h2 text-[#0D0D0E]">
              Frequently Asked Questions
            </h2>

            <p className="learnora-body-lg text-[#667085]">
              Helpful answers for prospective students and applicants discerning their theological study.
            </p>

            <div className="pt-4">
              <button
                type="button"
                onClick={() => navigateTo('contact')}
                className="learnora-btn px-7 py-3.5 bg-[#0D0D0E] hover:bg-[#0D1524] text-white rounded-full transition-all inline-flex items-center gap-2.5 cursor-pointer shadow-xs"
              >
                <span>Contact Admissions</span>
                <ArrowRight className="w-4 h-4 text-[#FC8B0A]" />
              </button>
            </div>
          </div>

          {/* Right Column: Asymmetric 2 × 2 Interactive Cards with 700ms stagger */}
          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-6">
            {faqs.map((faq, idx) => {
              const isOpen = openId === faq.id;
              const delayClass =
                idx === 0
                  ? 'delay-100'
                  : idx === 1
                  ? 'delay-200'
                  : idx === 2
                  ? 'delay-300'
                  : 'delay-400';

              return (
                <div
                  key={faq.id}
                  onClick={() => toggleFaq(faq.id)}
                  className={`rounded-2xl border p-7 sm:p-8 transition-all duration-700 ease-out flex flex-col justify-between cursor-pointer transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${delayClass} ${
                    isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                  } ${
                    isOpen
                      ? 'bg-[#0D1524] text-white border-[#0D1524] shadow-md ring-1 ring-[#0D1524]'
                      : 'bg-[#F5F6F8]/70 hover:bg-white text-[#0D0D0E] border-[#E5E7EB] hover:border-[#FC8B0A] shadow-xs'
                  }`}
                >
                  <div>
                    {/* Top Header with Number & Status Icon */}
                    <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-5">
                      <span
                        className={`text-sm font-display font-bold ${
                          isOpen ? 'text-[#FC8B0A]' : 'text-[#667085]'
                        }`}
                      >
                        {faq.num}
                      </span>
                      <div
                        className={`w-7 h-7 rounded-full flex items-center justify-center transition-transform duration-300 ${
                          isOpen
                            ? 'bg-[#FC8B0A] text-white rotate-180'
                            : 'bg-white text-[#0D0D0E] border border-[#E5E7EB]'
                        }`}
                      >
                        <ChevronDown className="w-4 h-4" />
                      </div>
                    </div>

                    {/* Question Heading */}
                    <h3
                      className={`text-lg font-display font-bold mb-3 leading-[1.3] ${
                        isOpen ? 'text-white' : 'text-[#0D0D0E]'
                      }`}
                    >
                      {faq.question}
                    </h3>

                    {/* Smooth Expanded Answer */}
                    <div
                      className={`grid transition-all duration-300 ease-in-out ${
                        isOpen ? 'grid-rows-[1fr] opacity-100 mt-2' : 'grid-rows-[0fr] opacity-0'
                      }`}
                    >
                      <div className="overflow-hidden">
                        <p
                          className={`text-[15px] leading-[1.6] ${
                            isOpen ? 'text-slate-200' : 'text-[#4E5161]'
                          }`}
                        >
                          {faq.answer}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Bottom hint when closed */}
                  {!isOpen && (
                    <div className="pt-4 mt-4 border-t border-slate-200/60 flex items-center justify-between text-xs text-[#667085] font-medium">
                      <span>Click to read answer</span>
                      <ArrowRight className="w-3.5 h-3.5 text-[#FC8B0A]" />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
