/**
 * CRBEM Theological Seminary - Academic Home Portal
 * Central academic launchpad uniting candidate status, institutional calendar,
 * registrar directives, and programme tracks.
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  GraduationCap,
  Calendar,
  BookOpen,
  ArrowRight,
  ShieldCheck,
  Bell,
  Clock,
  Compass,
  FileText,
  UserCheck,
  CheckCircle2,
  ChevronRight,
  Award
} from 'lucide-react';

export const AcademicHomeView: React.FC = () => {
  const {
    currentRole,
    currentUser,
    programmes,
    announcements,
    navigateTo,
    quickSwitchPersona
  } = useApp();

  return (
    <div className="py-10 bg-[#F5F6F8]">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        {/* 1. Dynamic Candidate / Student / Staff Live Status Banner */}
        <div className="bg-[#0D1524] text-white rounded-xl p-6 sm:p-7 border border-slate-800 shadow-md">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#FC8B0A] animate-pulse" />
                <span className="text-[13px] font-medium text-[#FC8B0A]">
                  Seminary Academic Portal Status
                </span>
                <span className="text-slate-600">/</span>
                <span className="text-xs text-slate-400">
                  Current Session: 2026/2027 (First Semester)
                </span>
              </div>

              <h2 className="font-display text-xl sm:text-2xl font-bold text-white tracking-tight">
                {currentUser ? (
                  <>Welcome, {currentUser.fullName}</>
                ) : (
                  <>Christ Redemption Bible Evangelical Mission Theological Seminary</>
                )}
              </h2>

              <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
                {currentUser ? (
                  currentUser.role === 'Applicant' ? (
                    'Your application dossier is active. You may track admission milestones, review formal decisions, and complete matriculation.'
                  ) : currentUser.role === 'Student' ? (
                    'First semester academic lectures commence October 19. Course registration portal is open.'
                  ) : (
                    'Administrative and faculty portal active. Manage course curricula, admission vetting, and library repositories.'
                  )
                ) : (
                  'Official academic platform for degree programmes, admissions, theological library, and ministerial accreditation.'
                )}
              </p>
            </div>

            {/* Quick Portal Switch Actions */}
            <div className="flex flex-wrap items-center gap-3 shrink-0">
              {currentUser ? (
                currentUser.role === 'Applicant' ? (
                  <button
                    type="button"
                    onClick={() => navigateTo('applicant-portal')}
                    className="px-5 py-2.5 bg-[#FC8B0A] hover:bg-[#E07702] text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 cursor-pointer shadow-xs"
                  >
                    <span>Enter Candidate Portal</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                ) : currentUser.role === 'Student' ? (
                  <button
                    type="button"
                    onClick={() => navigateTo('student-portal')}
                    className="px-5 py-2.5 bg-[#FC8B0A] hover:bg-[#E07702] text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 cursor-pointer shadow-xs"
                  >
                    <GraduationCap className="w-4 h-4" />
                    <span>My Student Dashboard</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => navigateTo('admin-portal')}
                    className="px-5 py-2.5 bg-[#FC8B0A] hover:bg-[#E07702] text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 cursor-pointer shadow-xs"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>Open Admin Console</span>
                  </button>
                )
              ) : (
                <>
                  <button
                    type="button"
                    onClick={() => navigateTo('auth-register')}
                    className="px-5 py-2.5 bg-[#FC8B0A] hover:bg-[#E07702] text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 cursor-pointer shadow-xs"
                  >
                    <span>Apply for Admission</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => navigateTo('auth-login')}
                    className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-medium rounded-lg transition-colors cursor-pointer border border-slate-700"
                  >
                    Portal Sign In
                  </button>
                </>
              )}
            </div>
          </div>
        </div>

        {/* 2. Seminary Introduction & Theological Tracks */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Main Column: Programme Catalogue & Academic Tracks */}
          <div className="lg:col-span-8 space-y-8">
            <div className="bg-white rounded-xl border border-[#E5E7EB] p-7 shadow-xs">
              <div className="flex items-center justify-between pb-4 border-b border-[#E5E7EB] mb-6">
                <div>
                  <h3 className="font-display text-xl font-bold text-[#0D0D0E]">
                    Academic Programmes Catalogue
                  </h3>
                  <p className="text-xs text-[#667085] mt-0.5">
                    Select a theological track to view curriculum schedule and matriculation prerequisites
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => navigateTo('programmes')}
                  className="text-xs font-semibold text-[#FC8B0A] hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <span>Full Catalog</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="space-y-4">
                {programmes.map((prog) => (
                  <div
                    key={prog.id}
                    className="p-4 rounded-lg border border-[#E5E7EB] hover:border-slate-400 bg-white hover:bg-slate-50/50 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 cursor-pointer"
                    onClick={() => navigateTo('programme-detail', prog.id)}
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-[#0D0D0E]">
                          {prog.code}
                        </span>
                        <span className="text-slate-300">·</span>
                        <h4 className="font-display text-sm font-bold text-[#0D0D0E]">
                          {prog.title}
                        </h4>
                      </div>
                      <p className="text-xs text-[#667085] line-clamp-1">
                        {prog.overview}
                      </p>
                    </div>

                    <div className="flex items-center gap-3 shrink-0 text-xs">
                      <span className="text-[#667085] font-sans">
                        {prog.duration}
                      </span>
                      <button
                        type="button"
                        className="px-3 py-1.5 bg-[#0D0D0E] text-white text-[11px] font-medium rounded-md hover:bg-slate-800 transition-colors"
                      >
                        Curriculum
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Formation Pillars Quick Summary */}
            <div className="bg-white rounded-xl border border-[#E5E7EB] p-7 shadow-xs">
              <h3 className="font-display text-lg font-bold text-[#0D0D0E] mb-4">
                Theological Formation Pillars
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                <div className="p-4 rounded-lg bg-[#F5F6F8] border border-[#E5E7EB]">
                  <div className="font-display text-sm font-bold text-[#0D0D0E] mb-1 flex items-center gap-1.5">
                    <span className="text-[#FC8B0A]">01.</span> Expository Rigor
                  </div>
                  <p className="text-[11px] text-[#667085] leading-relaxed">
                    Grammatical-historical exegesis with Greek and Hebrew original texts.
                  </p>
                </div>
                <div className="p-4 rounded-lg bg-[#F5F6F8] border border-[#E5E7EB]">
                  <div className="font-display text-sm font-bold text-[#0D0D0E] mb-1 flex items-center gap-1.5">
                    <span className="text-[#FC8B0A]">02.</span> Spiritual Formation
                  </div>
                  <p className="text-[11px] text-[#667085] leading-relaxed">
                    Personal piety, prayer communion, and supervised pastoral mentoring.
                  </p>
                </div>
                <div className="p-4 rounded-lg bg-[#F5F6F8] border border-[#E5E7EB]">
                  <div className="font-display text-sm font-bold text-[#0D0D0E] mb-1 flex items-center gap-1.5">
                    <span className="text-[#FC8B0A]">03.</span> Global Missions
                  </div>
                  <p className="text-[11px] text-[#667085] leading-relaxed">
                    Frontier evangelism, urban church planting, and apologetics.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Side Column: Office of the Registrar & Academic Notices */}
          <div className="lg:col-span-4 space-y-6">
            {/* Office of the Registrar Panel */}
            <div className="bg-[#0D0D0E] text-white rounded-xl p-6 border border-slate-800 shadow-sm space-y-4">
              <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
                <ShieldCheck className="w-5 h-5 text-[#FC8B0A]" />
                <h3 className="font-display text-base font-bold text-white">
                  Office of the Registrar
                </h3>
              </div>

              <div className="space-y-3 text-xs text-slate-300">
                <div className="flex items-start gap-2.5">
                  <Calendar className="w-4 h-4 text-[#FC8B0A] shrink-0 mt-0.5" />
                  <div>
                    <span className="text-white font-medium">Session Start:</span> October 19, 2026
                  </div>
                </div>
                <div className="flex items-start gap-2.5">
                  <Award className="w-4 h-4 text-[#FC8B0A] shrink-0 mt-0.5" />
                  <div>
                    <span className="text-white font-medium">Matriculation Ceremony:</span> October 24, 2026
                  </div>
                </div>
                <div className="flex items-start gap-2.5">
                  <Clock className="w-4 h-4 text-[#FC8B0A] shrink-0 mt-0.5" />
                  <div>
                    <span className="text-white font-medium">Course Add/Drop Deadline:</span> November 6, 2026
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-400">Desk Phone:</span>
                <span className="text-[#FC8B0A] font-mono">+234 803 456 7890</span>
              </div>
            </div>

            {/* Academic Notices Card */}
            <div className="bg-white rounded-xl border border-[#E5E7EB] p-6 shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
                <div className="flex items-center gap-2">
                  <Bell className="w-4 h-4 text-[#FC8B0A]" />
                  <h4 className="font-display text-sm font-bold text-[#0D0D0E]">
                    Official Academic Notices
                  </h4>
                </div>
                <button
                  type="button"
                  onClick={() => navigateTo('news')}
                  className="text-[11px] text-[#FC8B0A] hover:underline"
                >
                  All Notices
                </button>
              </div>

              <div className="space-y-3">
                {announcements.slice(0, 3).map((item) => (
                  <div key={item.id} className="p-3 rounded-lg bg-[#F5F6F8] text-xs">
                    <div className="flex items-center justify-between text-[10px] text-[#667085] mb-1">
                      <span className="font-medium text-[#0D0D0E]">{item.author}</span>
                      <span className="font-mono">{item.date}</span>
                    </div>
                    <div className="font-semibold text-[#0D0D0E] leading-snug line-clamp-2">
                      {item.title}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Links */}
            <div className="p-5 rounded-xl border border-[#E5E7EB] bg-white space-y-3">
              <h4 className="font-display text-xs font-bold text-[#0D0D0E] font-medium">
                Direct Portal Links
              </h4>
              <div className="space-y-2 text-xs">
                <button
                  type="button"
                  onClick={() => navigateTo('library')}
                  className="w-full text-left py-2 px-3 rounded-md bg-[#F5F6F8] hover:bg-slate-200/60 font-medium text-[#0D0D0E] flex items-center justify-between transition-colors"
                >
                  <span>Theological Library Catalogue</span>
                  <BookOpen className="w-3.5 h-3.5 text-[#FC8B0A]" />
                </button>
                <button
                  type="button"
                  onClick={() => navigateTo('admissions')}
                  className="w-full text-left py-2 px-3 rounded-md bg-[#F5F6F8] hover:bg-slate-200/60 font-medium text-[#0D0D0E] flex items-center justify-between transition-colors"
                >
                  <span>Tuition Schedule & Subsidies</span>
                  <FileText className="w-3.5 h-3.5 text-[#FC8B0A]" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
