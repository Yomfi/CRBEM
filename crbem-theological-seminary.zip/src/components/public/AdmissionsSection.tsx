/**
 * CRBEM Theological Seminary - Admissions Pathway & Requirements
 * Streamlined 4-step pathway with large step numbers, Learnora typography and scroll reveal:
 * - Heading: "Your Path to CRBEM"
 * - Supporting text: "A clear admissions process from application to matriculation."
 * - Steps:
 *     01 — Apply: Complete your candidate application online.
 *     02 — Submit Documents: Provide the required academic and ministry records.
 *     03 — Assessment: Complete the entrance assessment and interview.
 *     04 — Admission: Receive your decision and complete matriculation.
 */

import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { ArrowRight, CheckCircle2, FileText, Download } from 'lucide-react';

export const AdmissionsSection: React.FC = () => {
  const { navigateTo, currentView } = useApp();
  const [activeTab, setActiveTab] = useState<'pathway' | 'fees'>('pathway');
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    if (currentView === 'tuition-fees') {
      setActiveTab('fees');
    }
  }, [currentView]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.15 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const steps = [
    {
      num: '01',
      title: 'Apply',
      description: 'Complete your candidate application online.'
    },
    {
      num: '02',
      title: 'Submit Documents',
      description: 'Provide the required academic and ministry records.'
    },
    {
      num: '03',
      title: 'Assessment',
      description: 'Complete the entrance assessment and interview.'
    },
    {
      num: '04',
      title: 'Admission',
      description: 'Receive your decision and complete matriculation.'
    }
  ];

  return (
    <section
      ref={sectionRef}
      className="py-24 sm:py-28 lg:py-32 bg-[#F5F6F8] border-b border-[#E5E7EB]"
      id="admissions"
    >
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div
          className={`max-w-2xl mb-16 transition-all duration-700 ease-out transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-[#E5E7EB] text-[#0D0D0E] text-[15px] font-medium leading-[1.6] mb-4 shadow-xs">
            <span className="w-2 h-2 rounded-full bg-[#FC8B0A]" />
            <span>Admissions Directorate</span>
          </div>
          <h2 className="learnora-section-h2 text-[#0D0D0E] mb-4">
            Your Path to CRBEM
          </h2>
          <p className="learnora-body-lg text-[#667085]">
            A clear admissions process from application to matriculation.
          </p>
        </div>

        {/* 4-Step Pathway with Large Step Numbers & Sequential Reveal */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8 mb-16">
          {steps.map((step, index) => {
            const delayClass =
              index === 0
                ? 'delay-100'
                : index === 1
                ? 'delay-200'
                : index === 2
                ? 'delay-300'
                : 'delay-400';

            return (
              <div
                key={step.num}
                className={`bg-white rounded-2xl border border-[#E5E7EB] hover:border-[#FC8B0A] p-8 sm:p-9 transition-all duration-700 ease-out flex flex-col justify-between group hover:-translate-y-1 shadow-xs motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${delayClass} ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
              >
                <div>
                  {/* Large Step Number */}
                  <div className="font-display text-4xl sm:text-5xl font-extrabold text-[#FC8B0A] mb-6 leading-none">
                    {step.num}
                  </div>

                  {/* Step Title: Cabinet Grotesk 700 */}
                  <h3 className="learnora-card-title text-[#0D0D0E] mb-3 leading-[1.3]">
                    {step.title}
                  </h3>

                  {/* Concise Description: Inter 16px */}
                  <p className="text-[16px] text-[#4E5161] leading-[1.6]">
                    {step.description}
                  </p>
                </div>

                <div className="pt-6 mt-8 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-slate-400 group-hover:text-[#FC8B0A] transition-colors">
                  <span>Step {step.num} of 04</span>
                  <CheckCircle2 className="w-4 h-4 text-slate-300 group-hover:text-[#FC8B0A] transition-colors" />
                </div>
              </div>
            );
          })}
        </div>

        {/* Action Banner */}
        <div className="bg-white rounded-2xl border border-[#E5E7EB] p-8 sm:p-10 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xs">
          <div className="space-y-1 max-w-xl text-center md:text-left">
            <h4 className="font-display text-xl font-bold text-[#0D0D0E]">
              Ready to begin your admission application?
            </h4>
            <p className="text-[15px] text-[#667085]">
              Applications for the 2026/2027 Academic Session are currently open.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <button
              type="button"
              onClick={() => navigateTo('contact')}
              className="px-6 py-3 border border-[#E5E7EB] hover:border-slate-400 text-[#0D0D0E] text-[15px] font-medium rounded-full transition-all cursor-pointer"
            >
              Requirements & Fees
            </button>
            <button
              type="button"
              onClick={() => navigateTo('auth-register')}
              className="px-7 py-3 bg-[#FC8B0A] hover:bg-[#E07702] text-white text-[15px] font-semibold rounded-full transition-all cursor-pointer inline-flex items-center gap-2 shadow-xs"
            >
              <span>Apply Online</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
