/**
 * CRBEM Theological Seminary - Three Formation Pillars
 * Rebuilt to minimal copy rule and Learnora typography:
 * - Biblical Rigor: Study Scripture deeply through faithful exegesis and theological scholarship.
 * - Spiritual Formation: Grow in prayer, character and Christ-centred pastoral life.
 * - Global Mission: Prepare to preach, disciple and serve the Church across cultures.
 * - Larger headings (24px Cabinet Grotesk 700), 16px Inter body text, generous breathing room.
 * - Subtle stagger animation on entry, slight vertical lift (-translate-y-1) and orange border on hover.
 */

import React, { useEffect, useRef, useState } from 'react';
import { BookOpen, Flame, Globe2, ArrowRight } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const PillarsSection: React.FC = () => {
  const { navigateTo } = useApp();
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.15 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const cards = [
    {
      id: '01',
      title: 'Biblical Rigor',
      description: 'Study Scripture deeply through faithful exegesis and theological scholarship.',
      icon: BookOpen
    },
    {
      id: '02',
      title: 'Spiritual Formation',
      description: 'Grow in prayer, character and Christ-centred pastoral life.',
      icon: Flame
    },
    {
      id: '03',
      title: 'Global Mission',
      description: 'Prepare to preach, disciple and serve the Church across cultures.',
      icon: Globe2
    }
  ];

  return (
    <section
      ref={sectionRef}
      className="py-24 sm:py-28 lg:py-32 bg-white border-b border-[#E5E7EB]"
      id="formation"
    >
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div
          className={`max-w-2xl mx-auto text-center mb-16 transition-all duration-700 ease-out transform ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#F5F6F8] border border-[#E5E7EB] text-[#0D0D0E] text-[15px] font-medium leading-[1.6] mb-4">
            <span className="w-2 h-2 rounded-full bg-[#FC8B0A]" />
            <span>Theological Architecture</span>
          </div>
          <h2 className="learnora-section-h2 text-[#0D0D0E] mb-4">
            Our Core Pillars
          </h2>
          <p className="learnora-body-lg text-[#667085]">
            Forming shepherds with sharp minds, consecrated hearts and apostolic zeal.
          </p>
        </div>

        {/* 3 Formation Cards Grid with subtle stagger */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {cards.map((card, index) => {
            const Icon = card.icon;
            const delayClass =
              index === 0 ? 'delay-100' : index === 1 ? 'delay-200' : 'delay-300';

            return (
              <div
                key={card.id}
                className={`bg-[#F5F6F8]/60 hover:bg-white rounded-2xl border border-[#E5E7EB] hover:border-[#FC8B0A] p-8 sm:p-10 transition-all duration-700 ease-out flex flex-col justify-between group cursor-default hover:-translate-y-1 shadow-xs motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${delayClass} ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
              >
                <div>
                  {/* Top Bar with Number & Icon */}
                  <div className="flex items-center justify-between pb-6 border-b border-slate-200/60 mb-6">
                    <span className="font-display text-lg font-bold text-[#FC8B0A]">
                      {card.id}
                    </span>
                    <div className="w-10 h-10 rounded-xl bg-[#0D1524] text-white flex items-center justify-center transition-colors group-hover:bg-[#FC8B0A]">
                      <Icon className="w-5 h-5 text-white" />
                    </div>
                  </div>

                  {/* Card Title - Learnora Cabinet Grotesk 700 24px */}
                  <h3 className="learnora-card-title text-[#0D0D0E] mb-3 leading-[1.3]">
                    {card.title}
                  </h3>

                  {/* Concise 1-2 sentence body - Learnora 16px Inter */}
                  <p className="text-[16px] text-[#4E5161] leading-[1.6] font-normal">
                    {card.description}
                  </p>
                </div>

                <div className="pt-6 mt-8 border-t border-slate-200/50 flex items-center justify-between text-sm font-medium text-[#0D0D0E] group-hover:text-[#FC8B0A] transition-colors">
                  <span>Explore Curriculum</span>
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
