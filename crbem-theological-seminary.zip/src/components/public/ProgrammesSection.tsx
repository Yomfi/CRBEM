/**
 * CRBEM Theological Seminary - Academic Programmes Section
 * Simplified to Learnora card standards & concise copy rule:
 * - Degree title, qualification, duration, study mode, one concise sentence
 * - View Programme / Apply buttons
 * - Subtle 700ms entrance animation with scroll observer
 * - Adheres strictly to prefers-reduced-motion
 */

import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { ArrowRight, Clock } from 'lucide-react';

export const ProgrammesSection: React.FC = () => {
  const { programmes, navigateTo } = useApp();
  const [levelFilter, setLevelFilter] = useState<string>('All');
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.12 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const filterTabs = [
    { id: 'All', label: 'All Programmes' },
    { id: 'Undergraduate', label: 'Undergraduate & Diploma' },
    { id: 'Postgraduate', label: 'Postgraduate & Masters' },
    { id: 'Certificate', label: 'Foundational' }
  ];

  // Specific concise summaries mandated by specification
  const programmeSummaries: Record<string, { summary: string; duration: string; mode: string }> = {
    'prog-cth': {
      summary: 'A one-year foundation in Scripture, theology and ministry.',
      duration: '1 Year',
      mode: 'Full-Time'
    },
    'prog-dipth': {
      summary: 'Practical biblical and pastoral preparation for Christian ministry.',
      duration: '2 Years',
      mode: 'Full-Time'
    },
    'prog-bth': {
      summary: 'Rigorous theological formation for pastoral and ministry leadership.',
      duration: '4 Years',
      mode: 'Full-Time'
    },
    'prog-pgdth': {
      summary: 'Focused theological training for graduates entering ministry.',
      duration: '1 Year',
      mode: 'Executive / Modular'
    },
    'prog-mth': {
      summary: 'Advanced biblical and theological study for ministry and scholarship.',
      duration: '2 Years',
      mode: 'Full-Time / Modular'
    }
  };

  const filteredProgrammes = programmes.filter((p) => {
    if (levelFilter === 'All') return true;
    if (levelFilter === 'Undergraduate') return p.level === 'Undergraduate' || p.level === 'Diploma';
    if (levelFilter === 'Postgraduate') return p.level === 'Postgraduate' || p.level === 'Masters';
    if (levelFilter === 'Certificate') return p.level === 'Certificate';
    return true;
  });

  return (
    <section
      ref={sectionRef}
      className="py-24 sm:py-28 lg:py-32 bg-white border-b border-[#E5E7EB]"
      id="programmes"
    >
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header with 700ms reveal */}
        <div
          className={`flex flex-col md:flex-row md:items-end justify-between gap-8 mb-14 transition-all duration-700 ease-out transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
        >
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#F5F6F8] border border-[#E5E7EB] text-[#0D0D0E] text-[15px] font-medium leading-[1.6] mb-4">
              <span className="w-2 h-2 rounded-full bg-[#FC8B0A]" />
              <span>Academic Programmes</span>
            </div>

            <h2 className="learnora-section-h2 text-[#0D0D0E] mb-4">
              Prepare for Faithful Ministry
            </h2>

            <p className="learnora-body-lg text-[#667085]">
              Explore rigorous theological degrees designed for biblical scholarship, pastoral formation and gospel service.
            </p>
          </div>

          {/* Learnora Filter Tabs */}
          <div className="inline-flex items-center gap-1.5 p-1.5 bg-[#F5F6F8] rounded-full border border-[#E5E7EB] self-start md:self-end">
            {filterTabs.map((tab) => {
              const isActive = tab.id === levelFilter;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setLevelFilter(tab.id)}
                  className={`px-4 py-2 text-[15px] font-medium rounded-full transition-all cursor-pointer ${
                    isActive
                      ? 'bg-white text-[#0D0D0E] shadow-xs font-semibold'
                      : 'text-[#667085] hover:text-[#0D0D0E]'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Simplified Programme Cards Grid with 700ms Stagger */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProgrammes.map((prog, index) => {
            const isFlagship = prog.code === 'B.Th.';
            const details = programmeSummaries[prog.id] || {
              summary: prog.overview,
              duration: prog.duration,
              mode: prog.studyModes[0] || 'Full-Time'
            };

            const delayClass =
              index === 0
                ? 'delay-100'
                : index === 1
                ? 'delay-200'
                : index === 2
                ? 'delay-300'
                : index === 3
                ? 'delay-400'
                : 'delay-500';

            return (
              <div
                key={prog.id}
                className={`rounded-2xl border transition-all duration-700 ease-out flex flex-col justify-between bg-white overflow-hidden p-8 hover:-translate-y-1 motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${delayClass} ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                } ${
                  isFlagship
                    ? 'border-[#0D1524] shadow-md ring-1 ring-[#0D1524]'
                    : 'border-[#E5E7EB] hover:border-[#FC8B0A] shadow-xs'
                }`}
              >
                <div>
                  {/* Category & Qualification Row */}
                  <div className="flex items-center justify-between text-[14px] text-[#667085] font-normal mb-4">
                    <span>{prog.level} Degree</span>
                    <span className="font-medium text-[#FC8B0A]">{prog.code}</span>
                  </div>

                  {/* Degree Title */}
                  <h3 className="learnora-card-title text-[#0D0D0E] mb-3 leading-[1.3]">
                    {prog.title}
                  </h3>

                  {/* One Concise Sentence Summary */}
                  <p className="text-[16px] text-[#4E5161] leading-[1.6] mb-6 font-normal">
                    {details.summary}
                  </p>

                  {/* Duration · Study Mode */}
                  <div className="flex items-center gap-2 text-[14px] text-[#667085] font-medium pt-4 border-t border-[#E5E7EB]/80">
                    <Clock className="w-4 h-4 text-[#FC8B0A]" />
                    <span>{details.duration}</span>
                    <span className="text-slate-300">·</span>
                    <span>{details.mode}</span>
                  </div>
                </div>

                {/* Footer Actions */}
                <div className="pt-6 mt-6 border-t border-slate-100 flex items-center justify-between gap-4">
                  <button
                    type="button"
                    onClick={() => navigateTo('programme-detail', prog.id)}
                    className="text-[15px] font-medium text-[#0D0D0E] hover:text-[#FC8B0A] transition-colors cursor-pointer"
                  >
                    View Programme
                  </button>

                  <button
                    type="button"
                    onClick={() => navigateTo('auth-register')}
                    className="px-5 py-2.5 bg-[#0D0D0E] hover:bg-[#FC8B0A] text-white text-[14px] font-semibold rounded-full transition-colors cursor-pointer shadow-xs inline-flex items-center gap-1.5"
                  >
                    <span>Apply</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
