/**
 * CRBEM Theological Seminary - Digital Library Preview Section
 * Streamlined to Learnora card standards & minimal copy rule:
 * - Heading: "Digital Theological Library"
 * - Supporting line: "Scripture, theology, biblical languages, history and CRBEM archives."
 * - Each item shows only: Title (larger type), Author, Year/Category, Availability
 * - Subtle 700ms entrance animation with scroll observer respecting prefers-reduced-motion
 * - CTA: "Explore Library"
 */

import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { ArrowRight, CheckCircle2 } from 'lucide-react';

export const LibraryPreviewSection: React.FC = () => {
  const { libraryBooks, navigateTo } = useApp();
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.15 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  // Highlight 4 representative scholarly volumes
  const featuredBooks = libraryBooks.slice(0, 4);

  return (
    <section
      ref={sectionRef}
      className="py-24 sm:py-28 lg:py-32 bg-[#F5F6F8] border-b border-[#E5E7EB]"
      id="library-preview"
    >
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header with Explore Library CTA - 700ms entrance */}
        <div
          className={`flex flex-col md:flex-row md:items-end justify-between gap-8 mb-14 transition-all duration-700 ease-out transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
        >
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-[#E5E7EB] text-[#0D0D0E] text-[15px] font-medium leading-[1.6] mb-4 shadow-xs">
              <span className="w-2 h-2 rounded-full bg-[#FC8B0A]" />
              <span>Scholarly Holdings</span>
            </div>

            <h2 className="learnora-section-h2 text-[#0D0D0E] mb-4">
              Digital Theological Library
            </h2>

            <p className="learnora-body-lg text-[#667085]">
              Scripture, theology, biblical languages, history and CRBEM archives.
            </p>
          </div>

          <button
            type="button"
            onClick={() => navigateTo('library')}
            className="learnora-btn px-7 py-3.5 bg-[#0D0D0E] hover:bg-[#0D1524] text-white rounded-full transition-all inline-flex items-center gap-2.5 cursor-pointer shadow-xs self-start md:self-end"
          >
            <span>Explore Library</span>
            <ArrowRight className="w-4 h-4 text-[#FC8B0A]" />
          </button>
        </div>

        {/* 4 Clean Book Cards Grid with 700ms subtle stagger */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {featuredBooks.map((book, idx) => {
            const delayClass =
              idx === 0
                ? 'delay-100'
                : idx === 1
                ? 'delay-200'
                : idx === 2
                ? 'delay-300'
                : 'delay-400';

            return (
              <div
                key={book.id}
                className={`bg-white rounded-2xl border border-[#E5E7EB] hover:border-[#FC8B0A] p-7 transition-all duration-700 ease-out flex flex-col justify-between group hover:-translate-y-1 shadow-xs transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${delayClass} ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
              >
                <div>
                  {/* Category & Availability Row */}
                  <div className="flex items-center justify-between text-xs text-[#667085] mb-4">
                    <span className="font-medium text-[#FC8B0A]">{book.category}</span>
                    <span className="flex items-center gap-1 text-emerald-700 font-medium">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{book.availableCopies} Available</span>
                    </span>
                  </div>

                  {/* Larger Book Title: Cabinet Grotesk 700 20px */}
                  <h3 className="learnora-card-title text-[#0D0D0E] mb-2 leading-[1.3] line-clamp-2">
                    {book.title}
                  </h3>

                  {/* Author & Publication Year */}
                  <p className="text-[15px] text-[#4E5161] mb-4 font-normal">
                    {book.author} · {book.publicationYear}
                  </p>

                  {/* Shelf Location Tag */}
                  <div className="text-xs text-[#667085] pt-4 border-t border-slate-100 flex items-center justify-between">
                    <span>Shelf Call:</span>
                    <span className="font-medium text-[#0D0D0E]">{book.shelfLocation}</span>
                  </div>
                </div>

                {/* Action Button */}
                <div className="pt-5 mt-6 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => navigateTo('library')}
                    className="w-full py-2 text-center text-sm font-semibold text-[#0D0D0E] group-hover:text-[#FC8B0A] transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <span>View Catalogue Record</span>
                    <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
