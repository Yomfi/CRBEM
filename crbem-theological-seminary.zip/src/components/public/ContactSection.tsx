/**
 * CRBEM Theological Seminary - Contact Section
 * Simplified to Learnora typography and minimal copy rules:
 * - Heading: "Talk to Admissions"
 * - Supporting text: "Have a question about programmes or admission? Our team is ready to help."
 * - Essential contact details only (Campus address, direct phone, admissions email)
 * - Generous field heights, clear typography, preserved submission & validation logic
 * - Subtle 700ms entrance animation with scroll observer respecting prefers-reduced-motion
 */

import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { MapPin, Phone, Mail, Send, CheckCircle2 } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const { submitContactEnquiry } = useApp();

  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    programmeOfInterest: 'Bachelor of Theology (B.Th.)',
    message: ''
  });

  const [submitted, setSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.15 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
    if (errorMsg) setErrorMsg('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName.trim()) {
      setErrorMsg('Please enter your full name.');
      return;
    }
    if (!formData.email.trim() || !formData.email.includes('@')) {
      setErrorMsg('Please provide a valid email address.');
      return;
    }
    if (!formData.message.trim()) {
      setErrorMsg('Please enter your inquiry message.');
      return;
    }

    submitContactEnquiry({
      fullName: formData.fullName,
      email: formData.email,
      phone: formData.phone,
      subject: `Admissions Inquiry: ${formData.programmeOfInterest}`,
      category: 'Admissions',
      message: `[Programme: ${formData.programmeOfInterest}]\n\n${formData.message}`
    });

    setSubmitted(true);
  };

  return (
    <section
      ref={sectionRef}
      className="py-24 sm:py-28 lg:py-32 bg-[#F5F6F8] border-b border-[#E5E7EB]"
      id="contact"
    >
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          {/* Left Column: Essential Contact Details - 700ms entrance */}
          <div
            className={`lg:col-span-5 space-y-8 transition-all duration-700 ease-out transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
          >
            <div>
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-[#E5E7EB] text-[#0D0D0E] text-[15px] font-medium leading-[1.6] mb-4 shadow-xs">
                <span className="w-2 h-2 rounded-full bg-[#FC8B0A]" />
                <span>Admissions Secretariat</span>
              </div>
              <h2 className="learnora-section-h2 text-[#0D0D0E] mb-4">
                Talk to Admissions
              </h2>
              <p className="learnora-body-lg text-[#667085]">
                Have a question about programmes or admission? Our team is ready to help.
              </p>
            </div>

            {/* Essential Contact Information Cards */}
            <div className="space-y-4 pt-2">
              <div className="bg-white rounded-2xl border border-[#E5E7EB] p-6 flex items-start gap-4 shadow-xs">
                <div className="w-10 h-10 rounded-xl bg-[#0D1524] text-[#FC8B0A] flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-[#667085] mb-1">Seminary Campus</div>
                  <div className="text-[15px] font-medium text-[#0D0D0E] leading-snug">
                    CRBEM Theological Seminary Campus, Kilometre 42, Lagos-Ibadan Expressway, Nigeria
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-2xl border border-[#E5E7EB] p-6 flex items-start gap-4 shadow-xs">
                <div className="w-10 h-10 rounded-xl bg-[#0D1524] text-[#FC8B0A] flex items-center justify-center shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-[#667085] mb-1">Admissions Phone</div>
                  <div className="text-[15px] font-medium text-[#0D0D0E]">
                    +234 803 000 CRBEM · +234 802 333 4455
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-2xl border border-[#E5E7EB] p-6 flex items-start gap-4 shadow-xs">
                <div className="w-10 h-10 rounded-xl bg-[#0D1524] text-[#FC8B0A] flex items-center justify-center shrink-0">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-[#667085] mb-1">Secretariat Email</div>
                  <div className="text-[15px] font-medium text-[#0D0D0E]">
                    admissions@crbemseminary.edu.ng
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Simplified High-Elegance Inquiry Form - 700ms entrance delay-150 */}
          <div
            className={`lg:col-span-7 bg-white rounded-3xl border border-[#E5E7EB] p-8 sm:p-12 shadow-sm transition-all duration-700 ease-out delay-150 transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            {submitted ? (
              <div className="py-12 text-center space-y-4">
                <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="font-display text-2xl font-bold text-[#0D0D0E]">
                  Inquiry Received
                </h3>
                <p className="text-[16px] text-[#4E5161] max-w-md mx-auto leading-relaxed">
                  Thank you for reaching out. The Admissions Secretariat has received your message and will respond within 24 business hours.
                </p>
                <div className="pt-4">
                  <button
                    type="button"
                    onClick={() => {
                      setSubmitted(false);
                      setFormData({
                        fullName: '',
                        email: '',
                        phone: '',
                        programmeOfInterest: 'Bachelor of Theology (B.Th.)',
                        message: ''
                      });
                    }}
                    className="px-6 py-2.5 text-sm font-semibold text-[#0D0D0E] bg-[#F5F6F8] hover:bg-slate-200 rounded-full transition-colors cursor-pointer"
                  >
                    Send Another Inquiry
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <h3 className="font-display text-2xl font-bold text-[#0D0D0E] mb-2">
                    Send an Inquiry
                  </h3>
                  <p className="text-sm text-[#667085]">
                    Our admissions advisors will guide you through programme details and requirements.
                  </p>
                </div>

                {errorMsg && (
                  <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700">
                    {errorMsg}
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div className="space-y-1.5">
                    <label className="block text-sm font-medium text-[#0D0D0E]">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      name="fullName"
                      value={formData.fullName}
                      onChange={handleChange}
                      placeholder="e.g. Pastor Samuel Adeleke"
                      className="w-full px-4 py-3.5 rounded-xl border border-[#E5E7EB] focus:outline-none focus:border-[#FC8B0A] text-sm text-[#0D0D0E] bg-white transition-colors"
                      required
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-sm font-medium text-[#0D0D0E]">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="samuel@ministry.org"
                      className="w-full px-4 py-3.5 rounded-xl border border-[#E5E7EB] focus:outline-none focus:border-[#FC8B0A] text-sm text-[#0D0D0E] bg-white transition-colors"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div className="space-y-1.5">
                    <label className="block text-sm font-medium text-[#0D0D0E]">
                      Phone / WhatsApp Number
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      placeholder="+234 803 000 0000"
                      className="w-full px-4 py-3.5 rounded-xl border border-[#E5E7EB] focus:outline-none focus:border-[#FC8B0A] text-sm text-[#0D0D0E] bg-white transition-colors"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-sm font-medium text-[#0D0D0E]">
                      Programme of Interest
                    </label>
                    <select
                      name="programmeOfInterest"
                      value={formData.programmeOfInterest}
                      onChange={handleChange}
                      className="w-full px-4 py-3.5 rounded-xl border border-[#E5E7EB] focus:outline-none focus:border-[#FC8B0A] text-sm text-[#0D0D0E] bg-white transition-colors"
                    >
                      <option value="Certificate in Theology (C.Th.)">Certificate in Theology (C.Th.)</option>
                      <option value="Diploma in Theology (Dip.Th.)">Diploma in Theology (Dip.Th.)</option>
                      <option value="Bachelor of Theology (B.Th.)">Bachelor of Theology (B.Th.)</option>
                      <option value="Postgraduate Diploma in Theology (PGD.Th.)">Postgraduate Diploma (PGD.Th.)</option>
                      <option value="Master of Theology (M.Th.)">Master of Theology (M.Th.)</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-sm font-medium text-[#0D0D0E]">
                    Inquiry Message *
                  </label>
                  <textarea
                    name="message"
                    rows={4}
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Share any questions regarding study mode, academic credentials, or ministerial preparation..."
                    className="w-full p-4 rounded-xl border border-[#E5E7EB] focus:outline-none focus:border-[#FC8B0A] text-sm text-[#0D0D0E] bg-white transition-colors resize-none"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="learnora-btn w-full py-4 bg-[#0D0D0E] hover:bg-[#0D1524] text-white rounded-full transition-all inline-flex items-center justify-center gap-2 cursor-pointer shadow-md"
                >
                  <Send className="w-4 h-4 text-[#FC8B0A]" />
                  <span>Submit Inquiry to Admissions</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
