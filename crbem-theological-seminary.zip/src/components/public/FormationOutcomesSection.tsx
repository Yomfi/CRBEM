/**
 * CRBEM Theological Seminary - Core Formation Outcomes Section
 * Inspired by Eductix Core Learning Outcomes layout:
 * - Two balanced columns joined by a restrained center timeline/visual marker
 * - Heading: "Formation for Faithful Ministry"
 * - Left Side:
 *     Biblical Exegesis, Biblical Languages, Systematic Theology, Church History, Research & Scholarship
 * - Right Side:
 *     Spiritual Discipline, Pastoral Leadership, Expository Preaching, Evangelism & Mission, Christian Character
 * - Alternating white/soft-neutral and dark/orange emphasis using CRBEM palette (no green)
 * - Gentle row reveal animation
 */

import React, { useEffect, useRef, useState } from 'react';
import { BookOpen, Flame, Check } from 'lucide-react';

interface OutcomeRow {
  academic: {
    title: string;
    description: string;
  };
  pastoral: {
    title: string;
    description: string;
  };
}

export const FormationOutcomesSection: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.15 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const outcomes: OutcomeRow[] = [
    {
      academic: {
        title: 'Biblical Exegesis',
        description: 'Grammatical-historical study directly grounding sermon preparation and doctrinal integrity.'
      },
      pastoral: {
        title: 'Spiritual Discipline',
        description: 'Disciplined prayer life, devotional habits, and deep personal communion with Jesus Christ.'
      }
    },
    {
      academic: {
        title: 'Biblical Languages',
        description: 'Original language competence in Koine Greek and Biblical Hebrew for exegetical fidelity.'
      },
      pastoral: {
        title: 'Pastoral Leadership',
        description: 'Shepherding congregations with humility, biblical administration, and servant authority.'
      }
    },
    {
      academic: {
        title: 'Systematic Theology',
        description: 'Coherent orthodox understanding of the Trinity, Christology, Soteriology, and Ecclesiology.'
      },
      pastoral: {
        title: 'Expository Preaching',
        description: 'Clear, compelling verse-by-verse proclamation of God’s Word with urgent application.'
      }
    },
    {
      academic: {
        title: 'Church History',
        description: 'Historical perspectives on patristic councils, the Protestant Reformation, and global missions.'
      },
      pastoral: {
        title: 'Evangelism & Mission',
        description: 'Apostolic zeal for church planting, personal evangelism, and cross-cultural gospel ministry.'
      }
    },
    {
      academic: {
        title: 'Research & Scholarship',
        description: 'Academic theses contributing faithful theological scholarship to the global church.'
      },
      pastoral: {
        title: 'Christian Character',
        description: 'Uncompromising moral holiness, financial integrity, domestic uprightness, and humility.'
      }
    }
  ];

  return (
    <section
      ref={sectionRef}
      className="py-24 sm:py-28 lg:py-32 bg-white border-b border-[#E5E7EB]"
      id="outcomes"
    >
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div
          className={`max-w-2xl mx-auto text-center mb-16 transition-all duration-700 ease-out transform ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#F5F6F8] border border-[#E5E7EB] text-[#0D0D0E] text-[15px] font-medium leading-[1.6] mb-4">
            <span className="w-2 h-2 rounded-full bg-[#FC8B0A]" />
            <span>Curricular Balance</span>
          </div>
          <h2 className="learnora-section-h2 text-[#0D0D0E] mb-4">
            Formation for Faithful Ministry
          </h2>
          <p className="learnora-body-lg text-[#667085]">
            Bridging theological depth with pastoral heart and practical ministry leadership.
          </p>
        </div>

        {/* Column Headers */}
        <div className="hidden lg:grid grid-cols-12 gap-8 mb-8 text-center">
          <div className="col-span-5 p-3 rounded-xl bg-[#0D1524] text-white flex items-center justify-center gap-2">
            <BookOpen className="w-4 h-4 text-[#FC8B0A]" />
            <span className="font-display font-bold text-base">Theological Scholarship</span>
          </div>
          <div className="col-span-2 flex items-center justify-center">
            <span className="text-xs font-semibold text-[#667085]">Integral Balance</span>
          </div>
          <div className="col-span-5 p-3 rounded-xl bg-[#0D1524] text-white flex items-center justify-center gap-2">
            <Flame className="w-4 h-4 text-[#FC8B0A]" />
            <span className="font-display font-bold text-base">Pastoral Character & Practice</span>
          </div>
        </div>

        {/* Two Balanced Columns with Center Timeline Marker */}
        <div className="relative space-y-6">
          {/* Subtle Center Line (desktop only) */}
          <div className="hidden lg:block absolute left-1/2 top-0 bottom-0 w-0.5 bg-[#E5E7EB] -translate-x-1/2" />

          {outcomes.map((row, index) => {
            const isEven = index % 2 === 0;
            const delayClass =
              index === 0
                ? 'delay-100'
                : index === 1
                ? 'delay-200'
                : index === 2
                ? 'delay-300'
                : index === 3
                ? 'delay-400'
                : 'delay-500';

            return (
              <div
                key={index}
                className={`grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-center relative transition-all duration-700 ease-out ${delayClass} ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
                }`}
              >
                {/* Left Card: Academic Discipline */}
                <div
                  className={`lg:col-span-5 rounded-2xl border p-6 sm:p-7 transition-all duration-300 ${
                    isEven
                      ? 'bg-white border-[#E5E7EB] hover:border-[#FC8B0A] shadow-xs'
                      : 'bg-[#F5F6F8] border-[#E5E7EB] hover:border-slate-400'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-display font-bold text-lg text-[#0D0D0E]">
                      {row.academic.title}
                    </h3>
                    <span className="text-xs font-bold text-[#FC8B0A] bg-amber-50 px-2 py-0.5 rounded">
                      0{index + 1}A
                    </span>
                  </div>
                  <p className="text-[15px] text-[#4E5161] leading-[1.6]">
                    {row.academic.description}
                  </p>
                </div>

                {/* Center Node Marker */}
                <div className="hidden lg:flex lg:col-span-2 items-center justify-center relative z-10">
                  <div className="w-8 h-8 rounded-full bg-white border-2 border-[#FC8B0A] flex items-center justify-center text-[11px] font-bold text-[#0D0D0E] shadow-xs">
                    {index + 1}
                  </div>
                </div>

                {/* Right Card: Pastoral Practice */}
                <div
                  className={`lg:col-span-5 rounded-2xl border p-6 sm:p-7 transition-all duration-300 ${
                    !isEven
                      ? 'bg-white border-[#E5E7EB] hover:border-[#FC8B0A] shadow-xs'
                      : 'bg-[#F5F6F8] border-[#E5E7EB] hover:border-slate-400'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-display font-bold text-lg text-[#0D0D0E]">
                      {row.pastoral.title}
                    </h3>
                    <span className="text-xs font-bold text-[#FC8B0A] bg-amber-50 px-2 py-0.5 rounded">
                      0{index + 1}P
                    </span>
                  </div>
                  <p className="text-[15px] text-[#4E5161] leading-[1.6]">
                    {row.pastoral.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
