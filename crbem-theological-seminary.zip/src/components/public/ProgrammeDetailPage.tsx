/**
 * CRBEM Theological Seminary - Programme Detail View
 * Comprehensive curriculum roadmap, semester course tables, requirements, outcomes
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Breadcrumbs } from '../common/Breadcrumbs';
import { Clock, Award, User, CheckCircle2, FileText, ArrowRight, BookOpen, Layers } from 'lucide-react';

export const ProgrammeDetailPage: React.FC = () => {
  const { selectedProgrammeId, programmes, navigateTo } = useApp();

  const programme = programmes.find((p) => p.id === selectedProgrammeId) || programmes[2]; // Default to B.Th.
  const [activeCurriculumTab, setActiveCurriculumTab] = useState<number>(0);

  return (
    <div className="py-10 bg-white">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb Path */}
        <Breadcrumbs
          items={[
            { label: 'Seminary Home', view: 'public-home' },
            { label: 'Academic Programmes', view: 'programmes' },
            { label: `${programme.code} - ${programme.title}` }
          ]}
          className="mb-8"
        />

        {/* Hero Header */}
        <div className="bg-[#0D1524] text-white rounded-xl p-8 sm:p-10 mb-12 border border-slate-800 relative overflow-hidden">
          <div className="max-w-3xl space-y-4 relative z-10">
            <div className="flex items-center gap-2 text-xs text-slate-400 font-sans">
              <span className="text-[#FC8B0A] font-semibold">{programme.level} Degree</span>
              <span>·</span>
              <span>{programme.creditsRequired} Total Credits</span>
              <span>·</span>
              <span>{programme.duration}</span>
            </div>

            <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight">
              {programme.title} ({programme.code})
            </h1>

            <p className="text-slate-300 text-sm sm:text-base leading-relaxed font-light">
              {programme.theologicalAim}
            </p>

            <div className="pt-4 flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={() => navigateTo('auth-register')}
                className="px-6 py-3 bg-[#FC8B0A] hover:bg-[#E07702] text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 cursor-pointer"
              >
                <span>Apply for this Programme</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => navigateTo('admissions')}
                className="px-5 py-3 bg-white/10 hover:bg-white/15 text-white border border-white/20 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
              >
                Tuition & Requirements
              </button>
            </div>
          </div>
        </div>

        {/* 2-Column Academic Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Main Content: Overview, Curriculum, Outcomes */}
          <div className="lg:col-span-8 space-y-12">
            {/* Overview */}
            <section>
              <h2 className="font-display text-2xl font-bold text-[#0D0D0E] mb-4">
                Programme Overview & Ministerial Vision
              </h2>
              <p className="text-sm text-[#0D0D0E]/80 leading-relaxed font-sans mb-4">
                {programme.overview}
              </p>
              <p className="text-sm text-[#0D0D0E]/80 leading-relaxed font-sans">
                At CRBEM Seminary, candidate training is deliberately shielded from secularized academic dilution. Students engage directly with primary theological literature, historical creeds (Apostles', Nicene, Chalcedonian), and original scriptural texts to cultivate sound judgement and enduring ministerial stamina.
              </p>
            </section>

            {/* Semester-by-Semester Curriculum Breakdown */}
            <section className="pt-6 border-t border-[#E5E7EB]">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="font-display text-2xl font-bold text-[#0D0D0E]">
                    Curriculum Structure
                  </h2>
                  <p className="text-xs text-[#667085] mt-1">
                    Structured progression by academic semesters
                  </p>
                </div>
              </div>

              {/* Semester Tabs */}
              <div className="flex gap-2 overflow-x-auto pb-2 border-b border-[#E5E7EB] mb-6">
                {programme.curriculum.map((curr, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setActiveCurriculumTab(idx)}
                    className={`px-4 py-2 text-xs font-medium rounded-md whitespace-nowrap transition-colors cursor-pointer ${
                      activeCurriculumTab === idx
                        ? 'bg-[#0D0D0E] text-white font-semibold'
                        : 'text-[#667085] hover:text-[#0D0D0E] hover:bg-[#F5F6F8]'
                    }`}
                  >
                    {curr.semester}
                  </button>
                ))}
              </div>

              {/* Selected Semester Course Table */}
              {programme.curriculum[activeCurriculumTab] && (
                <div className="border border-[#E5E7EB] rounded-xl overflow-hidden bg-white shadow-xs">
                  <div className="bg-[#F5F6F8] px-5 py-3 border-b border-[#E5E7EB] font-display font-semibold text-xs text-[#0D0D0E] flex items-center justify-between">
                    <span>{programme.curriculum[activeCurriculumTab].semester} Course Modules</span>
                    <span className="text-[11px] text-[#667085] font-sans font-normal">
                      {programme.curriculum[activeCurriculumTab].courses.reduce((acc, c) => acc + c.credits, 0)} Total Credits
                    </span>
                  </div>

                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-[#E5E7EB] text-[#667085] bg-white">
                        <th className="py-3 px-5 font-medium">Course Code</th>
                        <th className="py-3 px-5 font-medium">Course Title</th>
                        <th className="py-3 px-5 font-medium text-center">Credits</th>
                        <th className="py-3 px-5 font-medium text-right">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#E5E7EB]">
                      {programme.curriculum[activeCurriculumTab].courses.map((course, cIdx) => (
                        <tr key={cIdx} className="hover:bg-[#F5F6F8]/60 transition-colors">
                          <td className="py-3.5 px-5 font-mono font-semibold text-[#0D0D0E]">
                            {course.code}
                          </td>
                          <td className="py-3.5 px-5 text-[#0D0D0E] font-medium">
                            {course.title}
                          </td>
                          <td className="py-3.5 px-5 text-center text-[#667085]">
                            {course.credits} Credits
                          </td>
                          <td className="py-3.5 px-5 text-right">
                            <span className="text-[11px] text-slate-600 font-medium">
                              {course.isCore ? 'Core Required' : 'Elective'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </section>

            {/* Programme Outcomes */}
            <section className="pt-6 border-t border-[#E5E7EB]">
              <h2 className="font-display text-2xl font-bold text-[#0D0D0E] mb-4">
                Expected Graduate Competencies
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {programme.outcomes.map((outcome, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-lg border border-[#E5E7EB] bg-[#F5F6F8]/40 flex items-start gap-3"
                  >
                    <CheckCircle2 className="w-4 h-4 text-[#FC8B0A] shrink-0 mt-0.5" />
                    <span className="text-xs text-[#0D0D0E] leading-relaxed">
                      {outcome}
                    </span>
                  </div>
                ))}
              </div>
            </section>
          </div>

          {/* Right Column: Admission Prerequisites, Faculty, Details Card */}
          <div className="lg:col-span-4 space-y-6">
            {/* Quick Details Box */}
            <div className="p-6 rounded-xl border border-[#E5E7EB] bg-[#F5F6F8] space-y-4">
              <h3 className="font-display text-base font-bold text-[#0D0D0E]">
                Programme Information
              </h3>

              <div className="space-y-3 text-xs divide-y divide-[#E5E7EB]/80">
                <div className="pt-2 flex justify-between">
                  <span className="text-[#667085]">Academic Level:</span>
                  <span className="font-semibold text-[#0D0D0E]">{programme.level}</span>
                </div>
                <div className="pt-2 flex justify-between">
                  <span className="text-[#667085]">Duration:</span>
                  <span className="font-semibold text-[#0D0D0E]">{programme.duration}</span>
                </div>
                <div className="pt-2 flex justify-between">
                  <span className="text-[#667085]">Total Credits:</span>
                  <span className="font-semibold text-[#0D0D0E]">{programme.creditsRequired} Units</span>
                </div>
                <div className="pt-2 flex justify-between">
                  <span className="text-[#667085]">Study Modes:</span>
                  <span className="font-semibold text-[#0D0D0E] text-right">
                    {programme.studyModes.join(', ')}
                  </span>
                </div>
                <div className="pt-2 flex justify-between">
                  <span className="text-[#667085]">Dean / Lead Faculty:</span>
                  <span className="font-semibold text-[#0D0D0E] text-right">
                    {programme.leadFaculty}
                  </span>
                </div>
              </div>

              <div className="pt-4 border-t border-[#E5E7EB]">
                <button
                  type="button"
                  onClick={() => navigateTo('auth-register')}
                  className="w-full py-2.5 bg-[#0D0D0E] hover:bg-[#0D1524] text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                >
                  Apply Online for 2026/2027
                </button>
              </div>
            </div>

            {/* Admission Requirements Card */}
            <div className="p-6 rounded-xl border border-[#E5E7EB] bg-white space-y-4">
              <h3 className="font-display text-base font-bold text-[#0D0D0E]">
                Admission Requirements
              </h3>
              <ul className="space-y-3 text-xs text-[#0D0D0E]/80">
                {programme.admissionRequirements.map((req, i) => (
                  <li key={i} className="flex items-start gap-2.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#FC8B0A] shrink-0 mt-1.5" />
                    <span>{req}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
