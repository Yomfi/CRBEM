/**
 * CRBEM Theological Seminary - Hero Section
 * Full-width cinematic photographic hero with Learnora typography & subtle entrance animations:
 * - Aligns strictly with 600-800ms duration rule (700ms - 750ms ease-out)
 * - Respects prefers-reduced-motion settings
 * - Concise hero copy:
 *     Equipping Faithful Shepherds.
 *     Advancing the Gospel.
 * - Supporting paragraph:
 *     Biblical scholarship, spiritual formation and pastoral preparation for faithful ministry.
 * - Buttons:
 *     Apply for 2026/2027 & Explore Programmes
 */

import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { ArrowRight } from 'lucide-react';

export const HeroSection: React.FC = () => {
  const { navigateTo } = useApp();
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setLoaded(true), 50);
    return () => clearTimeout(timer);
  }, []);

  return (
    <section className="relative min-h-[640px] lg:min-h-[720px] flex items-center justify-center overflow-hidden bg-[#0D1524] text-white">
      {/* 1. Background Cinematic Documentary Photograph (750ms duration) */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <img
          src="/src/assets/images/crbem_hero_pastor_1791299498076.jpg"
          alt="African Christian minister studying the Holy Bible in a seminary library"
          referrerPolicy="no-referrer"
          className={`w-full h-full object-cover object-center transition-all duration-750 ease-out transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-40 ${
            loaded ? 'opacity-40 scale-100' : 'opacity-0 scale-[1.025]'
          }`}
        />
        {/* Deep Navy/Black Overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#0D1524]/90 via-[#0D1524]/85 to-[#0D1524]/95" />
      </div>

      {/* 2. Hero Content Container */}
      <div className="relative z-10 w-full max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-28">
        <div className="flex flex-col items-center text-center max-w-[920px] mx-auto">
          {/* Headline Line 1 - 700ms fade upward */}
          <h1 className="learnora-hero-h1 tracking-normal text-balance mb-6">
            <span
              className={`block text-white transition-all duration-700 ease-out transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
                loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              Equipping Faithful Shepherds.
            </span>
            {/* Headline Line 2 - 700ms delay-150 in CRBEM Orange */}
            <span
              className={`block text-[#FC8B0A] transition-all duration-700 ease-out delay-150 transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
                loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              Advancing the Gospel.
            </span>
          </h1>

          {/* Supporting Paragraph - 700ms delay-300 */}
          <p
            className={`learnora-body-lg text-slate-200/90 max-w-[580px] mx-auto mb-10 font-normal transition-all duration-700 ease-out delay-300 transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
              loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'
            }`}
          >
            Biblical scholarship, spiritual formation and pastoral preparation for faithful ministry.
          </p>

          {/* CTA Buttons - 700ms delay-450 */}
          <div
            className={`flex flex-wrap items-center justify-center gap-4 transition-all duration-700 ease-out delay-450 transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
              loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            <button
              type="button"
              onClick={() => navigateTo('auth-register')}
              className="learnora-btn px-8 py-4 bg-[#FC8B0A] hover:bg-[#E07702] text-white rounded-full transition-all duration-200 shadow-md cursor-pointer inline-flex items-center gap-2.5 group"
            >
              <span>Apply for 2026/2027</span>
              <div className="w-5 h-5 rounded-full bg-white/20 flex items-center justify-center transition-transform group-hover:translate-x-1">
                <ArrowRight className="w-3.5 h-3.5 text-white" />
              </div>
            </button>

            <button
              type="button"
              onClick={() => navigateTo('programmes')}
              className="learnora-btn px-8 py-4 bg-white/10 hover:bg-white/20 text-white border border-white/25 rounded-full transition-all duration-200 cursor-pointer inline-flex items-center gap-2"
            >
              <span>Explore Programmes</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
