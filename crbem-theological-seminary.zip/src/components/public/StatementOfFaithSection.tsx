/**
 * CRBEM Theological Seminary - Statement of Faith & Doctrinal Confession
 * Historic Orthodox, Evangelical, Reformed & Pentecostal Heritage
 */

import React from 'react';
import { ShieldCheck, BookOpen, Heart, Flame, Compass, Check } from 'lucide-react';

export const StatementOfFaithSection: React.FC = () => {
  const articles = [
    {
      title: 'Article I: The Holy Scriptures',
      text: 'We believe in the verbal, plenary inspiration of the sixty-six canonical books of the Old and New Testaments as originally given. The Scriptures are completely inerrant, infallible, supreme, and final in all matters of faith, doctrine, and Christian living (2 Timothy 3:16–17; 2 Peter 1:20–21).'
    },
    {
      title: 'Article II: The Triune God',
      text: 'We confess one God, eternally existing in three distinct, co-equal, and co-eternal Persons: the Father, the Son, and the Holy Spirit; identical in essence, equal in glory and majesty, and executing distinct yet harmonious offices in the great work of redemption (Matthew 28:19; 2 Corinthians 13:14).'
    },
    {
      title: 'Article III: The Lord Jesus Christ',
      text: 'We believe in the absolute deity of our Lord Jesus Christ, His virgin birth, His sinless life, His miracles, His vicarious and substitutionary death upon the cross as full satisfaction for divine justice, His bodily resurrection, His ascension to the right hand of the Father, and His imminent personal return in power and glory.'
    },
    {
      title: 'Article IV: The Fall & Total Depravity of Man',
      text: 'We believe that man was created in the image of God, but through voluntary transgression fell into sin, incurring both physical death and spiritual alienation from God. As descendants of Adam, all human beings are born with a sinful nature, under the wrath of God, and incapable of self-redemption apart from sovereign divine grace.'
    },
    {
      title: 'Article V: Salvation by Grace Through Faith Alone',
      text: 'We believe that justification is an act of God’s sovereign grace alone (Sola Gratia), received through faith alone (Sola Fide) in Jesus Christ alone (Solus Christus). No human works, rituals, or ecclesiastical merits can contribute to salvation. The sinner is pardoned and declared righteous solely through the imputed righteousness of Jesus Christ.'
    },
    {
      title: 'Article VI: The Holy Spirit & Sanctification',
      text: 'We believe in the personality and deity of the Holy Spirit, who regenerates sinners, indwells the believer at conversion, empowers the Church with spiritual gifts for ministry, produces the fruit of holiness, and seals the redeemed unto the day of redemption.'
    },
    {
      title: 'Article VII: The Church & The Great Commission',
      text: 'We believe that the universal Church is the spiritual body of Jesus Christ. The mission of the Church is the faithful preaching of the gospel, the administration of the ordinances of Baptism and the Lord\'s Supper, and the relentless discipleship of all nations to the glory of God.'
    }
  ];

  return (
    <section className="py-20 bg-white border-b border-[#E5E7EB]">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mb-14">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#F5F6F8] border border-[#E5E7EB] text-[#0D0D0E] text-[15px] font-medium leading-[1.6] mb-4">
            <span className="w-2 h-2 rounded-full bg-[#FC8B0A]" />
            <span>Orthodox Confession</span>
          </div>
          <h2 className="learnora-section-h2 text-[#0D0D0E] mb-4">
            Institutional Statement of Faith
          </h2>
          <p className="learnora-body-lg text-[#667085]">
            All faculty, administrative officers, and admitted candidates subscribe annually to this confession of biblical truth without mental reservation.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {articles.map((art, idx) => (
            <div
              key={idx}
              className="p-7 rounded-xl border border-[#E5E7EB] bg-[#F5F6F8]/50 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <ShieldCheck className="w-4 h-4 text-[#FC8B0A] shrink-0" />
                  <h3 className="font-display text-base font-bold text-[#0D0D0E]">
                    {art.title}
                  </h3>
                </div>
                <p className="text-xs text-[#0D0D0E]/80 leading-relaxed font-sans">
                  {art.text}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
