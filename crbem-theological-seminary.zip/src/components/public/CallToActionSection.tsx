/**
 * CRBEM Theological Seminary - Closing Call-To-Action Section
 * Major visual moment before footer with Learnora typography & cinematic background:
 * - Photographic backdrop: /src/assets/images/crbem_calling_cta_1791299523359.jpg
 * - Heading: "Ready to Answer the Pastoral Call?"
 * - Supporting text: "Begin your journey of biblical formation, faithful ministry and gospel service."
 * - CTAs: "Apply Now" & "Explore Programmes"
 * - Deep navy/black overlay, generous vertical spacing, subtle scroll reveal (750ms ease-out).
 * - Adheres strictly to prefers-reduced-motion settings.
 */

import React, { useEffect, useRef, useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ArrowRight } from 'lucide-react';

export const CallToActionSection: React.FC = () => {
  const { navigateTo } = useApp();
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative py-28 sm:py-36 lg:py-44 bg-[#0D1524] text-white overflow-hidden"
    >
      {/* Background Image with Deep Navy/Black Overlay */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <img
          src="/src/assets/images/crbem_calling_cta_1791299523359.jpg"
          alt="Sacred Bible on pulpit in church sanctuary"
          referrerPolicy="no-referrer"
          className={`w-full h-full object-cover object-center transition-all duration-750 ease-out transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-30 ${
            isVisible ? 'opacity-30 scale-100' : 'opacity-0 scale-[1.03]'
          }`}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0D1524] via-[#0D1524]/90 to-[#0D1524]" />
      </div>

      <div className="relative z-10 max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div
          className={`max-w-[820px] mx-auto transition-all duration-750 ease-out transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          {/* Eyebrow */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 border border-white/15 text-slate-200 text-[15px] font-medium leading-[1.6] mb-6 backdrop-blur-sm">
            <span className="w-2 h-2 rounded-full bg-[#FC8B0A]" />
            <span>2026/2027 Admissions Open</span>
          </div>

          {/* Large Heading */}
          <h2 className="font-display font-extrabold text-4xl sm:text-5xl lg:text-6xl text-white mb-6 leading-[1.1] text-balance">
            Ready to Answer the{' '}
            <span className="text-[#FC8B0A]">Pastoral Call?</span>
          </h2>

          {/* Concise Supporting Text */}
          <p className="learnora-body-lg text-slate-300 max-w-[600px] mx-auto mb-12 font-normal">
            Begin your journey of biblical formation, faithful ministry and gospel service.
          </p>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-5">
            <button
              type="button"
              onClick={() => navigateTo('auth-register')}
              className="learnora-btn px-9 py-4 bg-[#FC8B0A] hover:bg-[#E07702] text-white rounded-full transition-all duration-200 shadow-lg cursor-pointer inline-flex items-center gap-2.5 group"
            >
              <span>Apply Now</span>
              <div className="w-5 h-5 rounded-full bg-white/20 flex items-center justify-center transition-transform group-hover:translate-x-1">
                <ArrowRight className="w-3.5 h-3.5 text-white" />
              </div>
            </button>

            <button
              type="button"
              onClick={() => navigateTo('programmes')}
              className="learnora-btn px-9 py-4 bg-white/10 hover:bg-white/20 text-white border border-white/25 rounded-full transition-all duration-200 cursor-pointer inline-flex items-center gap-2"
            >
              <span>Explore Programmes</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
