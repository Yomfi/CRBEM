/**
 * CRBEM Theological Seminary - Seminary Life & Community View
 * Devotional piety, chapel schedule, pastoral practicum, and student community
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { Breadcrumbs } from '../common/Breadcrumbs';
import { Flame, BookOpen, Globe2, Users, Clock, Heart, Award, Check } from 'lucide-react';

export const SeminaryLifeView: React.FC = () => {
  const { navigateTo } = useApp();

  return (
    <div className="py-10 bg-[#F5F6F8]">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <Breadcrumbs
          items={[
            { label: 'Seminary Home', view: 'public-home' },
            { label: 'Seminary Life & Community' }
          ]}
        />

        <div className="bg-[#0D1524] text-white rounded-xl p-8 border border-slate-800 shadow-sm space-y-3">
          <span className="text-[12px] font-medium text-[#FC8B0A]">
            Spiritual Ethos & Ministerial Community
          </span>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-white tracking-tight">
            Life at CRBEM Theological Seminary
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-3xl leading-relaxed font-light">
            We believe that a seminary must be more than a theological trade school. It is a covenantal community where mind and spirit are consecrated daily unto the glory of Christ Jesus.
          </p>
        </div>

        {/* Life Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white rounded-xl border border-[#E5E7EB] p-7 shadow-xs space-y-4">
            <div className="w-10 h-10 rounded-lg bg-[#0D1524] flex items-center justify-center text-[#FC8B0A]">
              <Flame className="w-5 h-5" />
            </div>
            <h3 className="font-display text-lg font-bold text-[#0D0D0E]">
              Daily Chapel & Communal Prayer
            </h3>
            <p className="text-xs text-[#667085] leading-relaxed">
              Every morning begins at 07:30 AM with the Seminary Chapel Service. Faculty and students worship together, sit under expository preaching, and intercede for global revival and the unreached.
            </p>
            <div className="pt-2 text-xs text-slate-700 font-medium">
              Schedule: Mon – Fri · 07:30 – 08:30 AM
            </div>
          </div>

          <div className="bg-white rounded-xl border border-[#E5E7EB] p-7 shadow-xs space-y-4">
            <div className="w-10 h-10 rounded-lg bg-[#0D1524] flex items-center justify-center text-[#FC8B0A]">
              <Users className="w-5 h-5" />
            </div>
            <h3 className="font-display text-lg font-bold text-[#0D0D0E]">
              Pastoral Mentorship Cohorts
            </h3>
            <p className="text-xs text-[#667085] leading-relaxed">
              Every student is assigned to a senior faculty advisor who conducts bi-weekly devotional check-ins, prayer sessions, homiletic critiques, and pastoral character reviews.
            </p>
            <div className="pt-2 text-xs text-slate-700 font-medium">
              Format: Small-group intimate mentorship
            </div>
          </div>

          <div className="bg-white rounded-xl border border-[#E5E7EB] p-7 shadow-xs space-y-4">
            <div className="w-10 h-10 rounded-lg bg-[#0D1524] flex items-center justify-center text-[#FC8B0A]">
              <Globe2 className="w-5 h-5" />
            </div>
            <h3 className="font-display text-lg font-bold text-[#0D0D0E]">
              Frontier Field Evangelism
            </h3>
            <p className="text-xs text-[#667085] leading-relaxed">
              During the mid-semester break, candidates participate in supervised missionary outreach across suburban frontiers, conducting open-air evangelism, hospital visits, and church planting surveys.
            </p>
            <div className="pt-2 text-xs text-slate-700 font-medium">
              Annual Mission Practicum: Required Units
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="bg-[#0D0D0E] text-white rounded-xl p-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1">
            <h3 className="font-display text-xl font-bold text-white">
              Experience the CRBEM Seminary Community
            </h3>
            <p className="text-xs text-slate-300">
              Schedule a campus tour or attend a public chapel exposition.
            </p>
          </div>
          <button
            type="button"
            onClick={() => navigateTo('contact')}
            className="px-5 py-2.5 bg-[#FC8B0A] hover:bg-[#E07702] text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
          >
            Contact Chapel Secretariat
          </button>
        </div>
      </div>
    </div>
  );
};
