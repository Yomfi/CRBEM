/**
 * CRBEM Theological Seminary - Sign In Form
 * Supports Candidate, Student, and Staff credential access
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { AuthSplitLayout } from './AuthSplitLayout';
import { Mail, Lock, ArrowRight, UserCheck, GraduationCap, Shield } from 'lucide-react';

export const CandidateLoginForm: React.FC = () => {
  const { applicants, students, faculty, loginAs, navigateTo, quickSwitchPersona } = useApp();

  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [showForgotNotice, setShowForgotNotice] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!identifier.trim()) {
      setError('Please provide your Application Reference, Matriculation Number, or Email.');
      return;
    }

    // Match applicant, student, or faculty
    const matchedApplicant = applicants.find(
      (a) => a.email.toLowerCase() === identifier.toLowerCase() || a.applicationReference.toLowerCase() === identifier.toLowerCase()
    );

    if (matchedApplicant) {
      loginAs(matchedApplicant);
      return;
    }

    const matchedStudent = students.find(
      (s) => s.email.toLowerCase() === identifier.toLowerCase() || s.matriculationNumber.toLowerCase() === identifier.toLowerCase()
    );

    if (matchedStudent) {
      loginAs(matchedStudent);
      return;
    }

    const matchedFaculty = faculty.find((f) => f.email.toLowerCase() === identifier.toLowerCase());
    if (matchedFaculty) {
      loginAs(matchedFaculty);
      return;
    }

    // Default: Log in as candidate or show notice
    if (identifier.includes('@')) {
      loginAs(applicants[0]);
    } else {
      setError('Credentials not found. You may use one of the one-click demo credentials below.');
    }
  };

  return (
    <AuthSplitLayout
      title="Portal Sign In"
      subtitle="Access your candidate dossier, student records, or academic directory"
    >
      <form onSubmit={handleSubmit} className="space-y-5">
        {error && (
          <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-md">
            {error}
          </div>
        )}

        {showForgotNotice && (
          <div className="p-3 bg-blue-50 border border-blue-200 text-blue-800 text-xs rounded-md leading-relaxed">
            Please contact the Office of the Registrar at <span className="font-mono font-medium">registrar@crbemseminary.edu</span> or call <span className="font-mono font-medium">+234 803 456 7890</span> to reset your portal password.
          </div>
        )}

        <div>
          <label className="block text-xs font-medium text-[#0D0D0E] mb-1.5">
            Application Reference, Matriculation No. or Email
          </label>
          <div className="relative">
            <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              required
              value={identifier}
              onChange={(e) => setIdentifier(e.target.value)}
              placeholder="e.g. CRBEM-APP-2026-0412 or e.adeyemi@..."
              className="w-full pl-10 pr-3.5 py-2.5 bg-white border border-[#E5E7EB] rounded-lg text-xs text-[#0D0D0E] outline-none focus:border-[#FC8B0A] transition-all"
            />
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-medium text-[#0D0D0E]">
              Secret Key / Password
            </label>
            <button
              type="button"
              onClick={() => setShowForgotNotice(!showForgotNotice)}
              className="text-[11px] text-[#FC8B0A] hover:underline cursor-pointer"
            >
              Forgot password?
            </button>
          </div>
          <div className="relative">
            <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••••••"
              className="w-full pl-10 pr-3.5 py-2.5 bg-white border border-[#E5E7EB] rounded-lg text-xs text-[#0D0D0E] outline-none focus:border-[#FC8B0A] transition-all"
            />
          </div>
        </div>

        <button
          type="submit"
          className="w-full py-3 bg-[#0D0D0E] hover:bg-[#0D1524] text-white text-xs font-semibold rounded-lg transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer shadow-xs"
        >
          <span>Sign In to Portal</span>
          <ArrowRight className="w-4 h-4 text-[#FC8B0A]" />
        </button>

        {/* Quick-fill Helper for Evaluator */}
        <div className="pt-5 border-t border-[#E5E7EB] space-y-2.5">
          <div className="text-[13px] text-[#4E5161] font-medium">
            Demo Access Profiles
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => quickSwitchPersona('Applicant')}
              className="p-2 border border-[#E5E7EB] rounded-lg hover:border-[#FC8B0A] bg-[#F5F6F8] text-left transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-1.5 text-xs font-semibold text-[#0D0D0E]">
                <UserCheck className="w-3.5 h-3.5 text-[#FC8B0A]" />
                <span>Candidate</span>
              </div>
              <div className="text-[10px] text-[#667085] mt-0.5">David Babalola</div>
            </button>

            <button
              type="button"
              onClick={() => quickSwitchPersona('Student')}
              className="p-2 border border-[#E5E7EB] rounded-lg hover:border-[#FC8B0A] bg-[#F5F6F8] text-left transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-1.5 text-xs font-semibold text-[#0D0D0E]">
                <GraduationCap className="w-3.5 h-3.5 text-emerald-600" />
                <span>Student</span>
              </div>
              <div className="text-[10px] text-[#667085] mt-0.5">Adeyemi (B.Th.)</div>
            </button>

            <button
              type="button"
              onClick={() => quickSwitchPersona('Registrar')}
              className="p-2 border border-[#E5E7EB] rounded-lg hover:border-[#FC8B0A] bg-[#F5F6F8] text-left transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-1.5 text-xs font-semibold text-[#0D0D0E]">
                <Shield className="w-3.5 h-3.5 text-blue-600" />
                <span>Registrar</span>
              </div>
              <div className="text-[10px] text-[#667085] mt-0.5">Admin console</div>
            </button>
          </div>
        </div>

        <div className="pt-2 text-center text-xs text-[#667085]">
          New candidate seeking admission?{' '}
          <button
            type="button"
            onClick={() => navigateTo('auth-register')}
            className="text-[#FC8B0A] font-semibold hover:underline cursor-pointer"
          >
            Create Candidate Account
          </button>
        </div>
      </form>
    </AuthSplitLayout>
  );
};
