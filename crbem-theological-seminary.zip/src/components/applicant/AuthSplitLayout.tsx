/**
 * CRBEM Theological Seminary - Authentication Split Screen Layout
 * Replicates the authoritative dark branded left panel & crisp white right panel
 * Strict typographic match to Learnora (Cabinet Grotesk headings, Inter body, no monospace/uppercase spam)
 * Subtle 700ms entrance animation with prefers-reduced-motion support
 */

import React, { useState, useEffect } from 'react';
import { CrbemLogo } from '../common/CrbemLogo';
import { CheckCircle } from 'lucide-react';

interface AuthSplitLayoutProps {
  children: React.ReactNode;
  title: string;
  subtitle: string;
  panelMessage?: string;
}

export const AuthSplitLayout: React.FC<AuthSplitLayoutProps> = ({
  children,
  title,
  subtitle,
  panelMessage = 'Preparing men and women of God for apostolic and pastoral ministry across nations.'
}) => {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setMounted(true), 50);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="min-h-[calc(100vh-140px)] flex flex-col lg:flex-row bg-[#F5F6F8]">
      {/* Dark Branded Institutional Left Panel - 700ms entrance */}
      <div
        className={`lg:w-5/12 bg-[#0D1524] text-white p-8 sm:p-12 lg:p-16 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-slate-800 relative overflow-hidden transition-all duration-700 ease-out transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
          mounted ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-4'
        }`}
      >
        <div className="relative z-10 space-y-8">
          {/* Logo & Mark */}
          <CrbemLogo variant="light" size="lg" />

          <div className="space-y-4 pt-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-[#FC8B0A] text-[13px] font-medium">
              Academic & Candidate Portal
            </div>
            <h1 className="font-display text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white leading-[1.15]">
              Christ Redemption Bible Evangelical Mission Theological Seminary
            </h1>
            <p className="text-sm text-slate-300 font-sans leading-relaxed">
              {panelMessage}
            </p>
          </div>

          <div className="pt-6 border-t border-slate-800 space-y-3">
            <div className="flex items-center gap-2.5 text-sm text-slate-300">
              <CheckCircle className="w-4 h-4 text-[#FC8B0A] shrink-0" />
              <span>Full-Time, Executive Part-Time, & Modular Distance</span>
            </div>
            <div className="flex items-center gap-2.5 text-sm text-slate-300">
              <CheckCircle className="w-4 h-4 text-[#FC8B0A] shrink-0" />
              <span>Biblical Inerrancy & Greek/Hebrew Exegetical Rigor</span>
            </div>
            <div className="flex items-center gap-2.5 text-sm text-slate-300">
              <CheckCircle className="w-4 h-4 text-[#FC8B0A] shrink-0" />
              <span>Autonomous Theological Academic Certification</span>
            </div>
          </div>
        </div>

        {/* Latin Motto & Scripture Anchor */}
        <div className="relative z-10 pt-10 border-t border-slate-800/80 mt-8 text-sm text-slate-400">
          <div className="font-sans font-medium text-slate-200">
            "Veritas et Ministerium"
          </div>
          <div className="text-[13px] text-slate-400 mt-0.5">
            2 Timothy 2:15 · Founded 1984
          </div>
        </div>
      </div>

      {/* Crisp White Form Panel Right - 700ms entrance */}
      <div
        className={`lg:w-7/12 flex items-center justify-center p-6 sm:p-12 lg:p-16 bg-white transition-all duration-700 ease-out delay-100 transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
          mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
        }`}
      >
        <div className="w-full max-w-lg">
          <div className="mb-8">
            <h2 className="font-display text-2xl sm:text-3xl font-extrabold text-[#0D0D0E]">
              {title}
            </h2>
            <p className="text-sm text-[#4E5161] mt-1.5 font-sans leading-normal">
              {subtitle}
            </p>
          </div>

          {children}
        </div>
      </div>
    </div>
  );
};
