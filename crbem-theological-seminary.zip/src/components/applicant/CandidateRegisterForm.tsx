/**
 * CRBEM Theological Seminary - Candidate Registration & Application Intake
 * Split-Screen Editorial Admissions Layout with Subtle Framer Transitions:
 * - 600-800ms duration rule on all entrance transitions
 * - Staggered reveal of hero elements and individual form rows
 * - Strict adherence to prefers-reduced-motion settings
 * - Desktop: 58% photographic panel / 42% form panel
 * - Preserves all registration logic, validation, and submission behavior
 */

import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { CrbemLogo } from '../common/CrbemLogo';
import { StudyMode } from '../../types';
import { ArrowRight, ChevronDown, AlertCircle, Phone, Mail } from 'lucide-react';

export const CandidateRegisterForm: React.FC = () => {
  const { programmes, submitNewApplication, navigateTo } = useApp();

  const [formData, setFormData] = useState({
    title: 'Bro.',
    fullName: '',
    email: '',
    phone: '',
    programmeId: 'prog-bth',
    studyMode: 'Full-Time (On-Campus)' as StudyMode,
    denomination: 'Christ Redemption Bible Evangelical Mission',
    pastorName: '',
    yearsBornAgain: 4,
    calling: ''
  });

  const [error, setError] = useState<string | null>(null);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    // 50ms mount trigger for smooth 700ms entrance
    const timer = setTimeout(() => setMounted(true), 50);
    return () => clearTimeout(timer);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName.trim() || !formData.email.trim() || !formData.pastorName.trim()) {
      setError('Please fill in all required fields: Full Legal Name, Email Address, and Supervising Pastor.');
      return;
    }

    const selectedProg = programmes.find((p) => p.id === formData.programmeId);

    submitNewApplication({
      fullName: `${formData.title} ${formData.fullName.trim()}`,
      email: formData.email.trim(),
      phoneNumber: formData.phone.trim(),
      programmeId: formData.programmeId,
      programmeName: selectedProg ? selectedProg.title : 'Bachelor of Theology (B.Th.)',
      studyMode: formData.studyMode,
      personalInfo: {
        title: formData.title,
        dateOfBirth: '1996-03-20',
        gender: formData.title === 'Sister' ? 'Female' : 'Male',
        nationality: 'Nigerian',
        residentialAddress: 'Lagos, Nigeria',
        churchDenomination: formData.denomination.trim() || 'Christ Redemption Bible Evangelical Mission',
        pastorName: formData.pastorName.trim(),
        yearsBornAgain: Number(formData.yearsBornAgain) || 5,
        ministerialCalling: formData.calling.trim() || 'Pastoral and evangelistic ministry'
      }
    });
  };

  return (
    <div className="min-h-screen w-full flex flex-col lg:flex-row bg-white selection:bg-[#FC8B0A]/20 selection:text-[#0D0D0E]">
      {/* ========================================================
          LEFT: 58% PHOTOGRAPHIC VISUAL PANEL (Desktop)
         ======================================================== */}
      <div className="w-full lg:w-[58%] min-h-[360px] sm:min-h-[440px] lg:min-h-screen relative bg-[#0D1524] text-white flex flex-col justify-between p-6 sm:p-10 lg:p-14 xl:p-16 overflow-hidden">
        {/* Background B&W Photograph with 750ms scale & fade transition */}
        <div className="absolute inset-0 z-0 overflow-hidden">
          <img
            src="/src/assets/images/crbem_pastor_bw_study_1791300875670.jpg"
            alt="African theology student and pastor in quiet library study holding the Holy Bible"
            referrerPolicy="no-referrer"
            className={`w-full h-full object-cover object-center filter grayscale contrast-[1.08] brightness-[0.9] transition-all duration-750 ease-out transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-60 ${
              mounted ? 'scale-100 opacity-60' : 'scale-[1.025] opacity-0'
            }`}
          />
          {/* Subtle Deep Navy/Black Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#0D1524] via-[#0D1524]/75 to-[#0D1524]/60" />
        </div>

        {/* Top Minimal Navigation on Image: CRBEM Logo + Seminary */}
        <div
          className={`relative z-10 flex items-center justify-between transition-all duration-700 ease-out transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
            mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}
        >
          <button
            type="button"
            onClick={() => navigateTo('public-home')}
            className="cursor-pointer text-left focus:outline-none inline-flex items-center group transition-transform hover:opacity-95"
            title="Return to Seminary Homepage"
          >
            <CrbemLogo variant="light" size="md" />
          </button>

          {/* Mobile Shortcut to Sign In */}
          <button
            type="button"
            onClick={() => navigateTo('auth-login')}
            className="lg:hidden text-xs font-medium text-slate-200 hover:text-white bg-white/10 hover:bg-white/15 px-3 py-1.5 rounded-full transition-colors cursor-pointer backdrop-blur-sm"
          >
            Sign In
          </button>
        </div>

        {/* Lower Left Editorial Copy Block with 600-800ms Stagger */}
        <div className="relative z-10 max-w-xl mt-auto pt-12 lg:pt-24 space-y-4">
          {/* Eyebrow marker - 100ms delay */}
          <div
            className={`inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/15 text-slate-200 text-xs font-medium backdrop-blur-sm transition-all duration-700 ease-out delay-100 transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
              mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-[#FC8B0A]" />
            <span>Admissions Intake 2026/2027</span>
          </div>

          {/* Main Editorial Headline - 175ms delay */}
          <h1
            className={`font-display font-extrabold text-3xl sm:text-4xl lg:text-5xl text-white leading-[1.1] text-balance transition-all duration-700 ease-out delay-175 transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
              mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'
            }`}
          >
            Begin Your Journey{' '}
            <span className="text-[#FC8B0A] block sm:inline">in Biblical Formation.</span>
          </h1>

          {/* Concise Supporting Text - 250ms delay */}
          <p
            className={`text-sm sm:text-base text-slate-300 font-sans leading-relaxed max-w-lg transition-all duration-700 ease-out delay-250 transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
              mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'
            }`}
          >
            Prepare for faithful ministry through Scripture, spiritual formation and theological study.
          </p>

          {/* Admissions Office Direct Contacts - 325ms delay */}
          <div
            className={`pt-6 border-t border-slate-700/70 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-slate-300 transition-all duration-700 ease-out delay-325 transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
              mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            <div className="flex items-center gap-1.5 font-medium text-slate-200">
              <span className="text-[#FC8B0A]">Admissions Office</span>
            </div>
            <span className="text-slate-600 hidden sm:inline">·</span>
            <div className="flex items-center gap-1.5 text-slate-300">
              <Mail className="w-3.5 h-3.5 text-[#FC8B0A]" />
              <span>admissions@crbemseminary.edu.ng</span>
            </div>
            <span className="text-slate-600 hidden sm:inline">·</span>
            <div className="flex items-center gap-1.5 text-slate-300">
              <Phone className="w-3.5 h-3.5 text-[#FC8B0A]" />
              <span>+234 803 000 CRBEM</span>
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================
          RIGHT: 42% CLEAN WHITE REGISTRATION PANEL (Desktop)
         ======================================================== */}
      <div className="w-full lg:w-[42%] min-h-screen bg-white flex flex-col justify-between p-6 sm:p-10 lg:p-12 xl:p-16">
        {/* Top Header: "Already registered? Sign In" */}
        <div
          className={`hidden lg:flex items-center justify-end pb-8 border-b border-slate-100 mb-8 transition-all duration-700 ease-out transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
            mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-3'
          }`}
        >
          <div className="text-sm text-[#4E5161]">
            Already registered?{' '}
            <button
              type="button"
              onClick={() => navigateTo('auth-login')}
              className="font-semibold text-[#0D0D0E] hover:text-[#FC8B0A] transition-colors cursor-pointer ml-1 underline underline-offset-4 decoration-slate-300 hover:decoration-[#FC8B0A]"
            >
              Sign In
            </button>
          </div>
        </div>

        {/* Main Registration Form Container */}
        <div className="max-w-xl mx-auto w-full my-auto">
          {/* Progress Indicator & Form Heading - 150ms delay */}
          <div
            className={`mb-8 transition-all duration-700 ease-out delay-150 transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
              mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'
            }`}
          >
            <div className="text-xs font-semibold text-[#FC8B0A] mb-2 tracking-wide">
              01 — Candidate Details
            </div>
            <h2 className="font-display font-extrabold text-3xl sm:text-4xl text-[#0D0D0E] leading-tight mb-2">
              Candidate Registration
            </h2>
            <p className="text-[15px] sm:text-[16px] text-[#4E5161] leading-normal font-sans">
              Begin your application for the 2026/2027 Academic Session.
            </p>

            {/* Mobile-only Sign In prompt under description */}
            <div className="lg:hidden mt-3 text-sm text-[#4E5161]">
              Already registered?{' '}
              <button
                type="button"
                onClick={() => navigateTo('auth-login')}
                className="font-semibold text-[#0D0D0E] hover:text-[#FC8B0A] underline underline-offset-2"
              >
                Sign In
              </button>
            </div>
          </div>

          {/* Error Notice */}
          {error && (
            <div className="mb-6 p-4 bg-rose-50 border border-rose-200 text-rose-700 text-sm rounded-xl flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Staggered Form Fields: 600-800ms duration rule */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* ROW 1: Title + Full Legal Name - 225ms delay */}
            <div
              className={`grid grid-cols-1 sm:grid-cols-12 gap-4 transition-all duration-700 ease-out delay-225 transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
                mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
              }`}
            >
              <div className="sm:col-span-4 space-y-2">
                <label className="block text-sm font-semibold text-[#0D0D0E]">
                  Title *
                </label>
                <div className="relative">
                  <select
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    className="w-full h-13 px-4 bg-white border border-[#E5E7EB] rounded-xl text-sm font-medium text-[#0D0D0E] outline-none focus:border-[#FC8B0A] focus:ring-1 focus:ring-[#FC8B0A] cursor-pointer appearance-none transition-colors"
                  >
                    <option value="Pastor">Pastor</option>
                    <option value="Evangelist">Evang.</option>
                    <option value="Rev.">Rev.</option>
                    <option value="Bro.">Bro.</option>
                    <option value="Sister">Sister</option>
                  </select>
                  <ChevronDown className="w-4 h-4 text-[#667085] absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>
              </div>

              <div className="sm:col-span-8 space-y-2">
                <label className="block text-sm font-semibold text-[#0D0D0E]">
                  Full Legal Name *
                </label>
                <input
                  type="text"
                  required
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  placeholder="e.g. Samuel Olumide Adeyemo"
                  className="w-full h-13 px-4 bg-white border border-[#E5E7EB] rounded-xl text-sm text-[#0D0D0E] placeholder:text-slate-400 outline-none focus:border-[#FC8B0A] focus:ring-1 focus:ring-[#FC8B0A] transition-colors"
                />
              </div>
            </div>

            {/* ROW 2: Email Address + Phone Number - 300ms delay */}
            <div
              className={`grid grid-cols-1 sm:grid-cols-2 gap-4 transition-all duration-700 ease-out delay-300 transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
                mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
              }`}
            >
              <div className="space-y-2">
                <label className="block text-sm font-semibold text-[#0D0D0E]">
                  Email Address *
                </label>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="samuel@ministry.org"
                  className="w-full h-13 px-4 bg-white border border-[#E5E7EB] rounded-xl text-sm text-[#0D0D0E] placeholder:text-slate-400 outline-none focus:border-[#FC8B0A] focus:ring-1 focus:ring-[#FC8B0A] transition-colors"
                />
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-semibold text-[#0D0D0E]">
                  Phone Number
                </label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="+234 803 000 0000"
                  className="w-full h-13 px-4 bg-white border border-[#E5E7EB] rounded-xl text-sm text-[#0D0D0E] placeholder:text-slate-400 outline-none focus:border-[#FC8B0A] focus:ring-1 focus:ring-[#FC8B0A] transition-colors"
                />
              </div>
            </div>

            {/* ROW 3: Programme Desired + Study Mode - 375ms delay */}
            <div
              className={`grid grid-cols-1 sm:grid-cols-2 gap-4 transition-all duration-700 ease-out delay-375 transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
                mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
              }`}
            >
              <div className="space-y-2">
                <label className="block text-sm font-semibold text-[#0D0D0E]">
                  Programme Desired *
                </label>
                <div className="relative">
                  <select
                    value={formData.programmeId}
                    onChange={(e) => setFormData({ ...formData, programmeId: e.target.value })}
                    className="w-full h-13 px-4 bg-white border border-[#E5E7EB] rounded-xl text-sm font-medium text-[#0D0D0E] outline-none focus:border-[#FC8B0A] focus:ring-1 focus:ring-[#FC8B0A] cursor-pointer appearance-none transition-colors"
                  >
                    {programmes.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.code} — {p.title}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="w-4 h-4 text-[#667085] absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-semibold text-[#0D0D0E]">
                  Study Mode *
                </label>
                <div className="relative">
                  <select
                    value={formData.studyMode}
                    onChange={(e) => setFormData({ ...formData, studyMode: e.target.value as StudyMode })}
                    className="w-full h-13 px-4 bg-white border border-[#E5E7EB] rounded-xl text-sm font-medium text-[#0D0D0E] outline-none focus:border-[#FC8B0A] focus:ring-1 focus:ring-[#FC8B0A] cursor-pointer appearance-none transition-colors"
                  >
                    <option value="Full-Time (On-Campus)">Full-Time (On-Campus)</option>
                    <option value="Part-Time (Executive)">Part-Time (Executive)</option>
                    <option value="Modular Distance">Modular Distance</option>
                  </select>
                  <ChevronDown className="w-4 h-4 text-[#667085] absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>
              </div>
            </div>

            {/* ROW 4: Church Denomination + Supervising Pastor Name - 450ms delay */}
            <div
              className={`grid grid-cols-1 sm:grid-cols-2 gap-4 transition-all duration-700 ease-out delay-450 transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
                mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
              }`}
            >
              <div className="space-y-2">
                <label className="block text-sm font-semibold text-[#0D0D0E]">
                  Church Denomination
                </label>
                <input
                  type="text"
                  value={formData.denomination}
                  onChange={(e) => setFormData({ ...formData, denomination: e.target.value })}
                  placeholder="e.g. CRBEM / Evangelical"
                  className="w-full h-13 px-4 bg-white border border-[#E5E7EB] rounded-xl text-sm text-[#0D0D0E] placeholder:text-slate-400 outline-none focus:border-[#FC8B0A] focus:ring-1 focus:ring-[#FC8B0A] transition-colors"
                />
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-semibold text-[#0D0D0E]">
                  Supervising Pastor Name *
                </label>
                <input
                  type="text"
                  required
                  value={formData.pastorName}
                  onChange={(e) => setFormData({ ...formData, pastorName: e.target.value })}
                  placeholder="e.g. Pastor J. O. Alabi"
                  className="w-full h-13 px-4 bg-white border border-[#E5E7EB] rounded-xl text-sm text-[#0D0D0E] placeholder:text-slate-400 outline-none focus:border-[#FC8B0A] focus:ring-1 focus:ring-[#FC8B0A] transition-colors"
                />
              </div>
            </div>

            {/* FULL WIDTH: Statement of Ministerial Calling - 525ms delay */}
            <div
              className={`space-y-2 transition-all duration-700 ease-out delay-525 transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
                mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
              }`}
            >
              <label className="block text-sm font-semibold text-[#0D0D0E]">
                Statement of Ministerial Calling
              </label>
              <textarea
                rows={3}
                value={formData.calling}
                onChange={(e) => setFormData({ ...formData, calling: e.target.value })}
                placeholder="Briefly describe your sense of calling to pastoral, evangelistic, or teaching ministry..."
                className="w-full p-4 bg-white border border-[#E5E7EB] rounded-xl text-sm text-[#0D0D0E] placeholder:text-slate-400 outline-none focus:border-[#FC8B0A] focus:ring-1 focus:ring-[#FC8B0A] transition-colors resize-none leading-relaxed"
              />
            </div>

            {/* PRIMARY CTA: Submit Application - 600ms delay */}
            <div
              className={`pt-2 transition-all duration-700 ease-out delay-600 transform motion-reduce:transition-none motion-reduce:transform-none motion-reduce:opacity-100 ${
                mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
              }`}
            >
              <button
                type="submit"
                className="learnora-btn w-full h-14 bg-[#0D0D0E] hover:bg-[#FC8B0A] text-white rounded-full transition-all duration-200 flex items-center justify-center gap-2.5 cursor-pointer shadow-sm group text-[16px] font-bold"
              >
                <span>Submit Application</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>

              <div className="text-center text-xs text-[#667085] mt-3 font-normal">
                Your application reference will be generated after submission.
              </div>
            </div>
          </form>
        </div>

        {/* Bottom subtle copyright note on right side */}
        <div className="pt-8 border-t border-slate-100 text-xs text-slate-400 text-center lg:text-left">
          © {new Date().getFullYear()} Christ Redemption Bible Evangelical Mission Theological Seminary
        </div>
      </div>
    </div>
  );
};
