/**
 * CRBEM Theological Seminary - Candidate / Applicant Portal
 * Full milestone tracking, dossier inspection, official admission decision letter,
 * and matriculation acceptance.
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Applicant } from '../../types';
import { StatusBadge } from '../common/StatusBadge';
import { Breadcrumbs } from '../common/Breadcrumbs';
import { Modal } from '../common/Modal';
import {
  FileText,
  UserCheck,
  CheckCircle2,
  Clock,
  Award,
  Download,
  AlertCircle,
  HelpCircle,
  Calendar,
  Building,
  GraduationCap,
  ExternalLink,
  ShieldCheck,
  ArrowRight
} from 'lucide-react';

export const ApplicantDashboard: React.FC = () => {
  const {
    currentUser,
    applicants,
    acceptOfferAndMatriculate,
    navigateTo,
    addToast
  } = useApp();

  // Find active applicant dossier
  const applicant: Applicant = (
    currentUser && currentUser.role === 'Applicant'
      ? (currentUser as Applicant)
      : applicants[0]
  ) || applicants[0];

  const [letterModalOpen, setLetterModalOpen] = useState(false);
  const [helpModalOpen, setHelpModalOpen] = useState(false);

  // Milestones progression
  const milestones = [
    {
      step: 1,
      title: 'Application Dossier Submitted',
      date: applicant.submissionDate,
      done: true,
      current: false
    },
    {
      step: 2,
      title: 'Pastoral Referee & Document Vetting',
      date: 'Completed',
      done: true,
      current: false
    },
    {
      step: 3,
      title: 'Theological Entrance Exam & Interview',
      date: applicant.interviewDate || 'Completed Satisfactorily',
      done: applicant.status === 'Offer Issued' || applicant.status === 'Matriculated',
      current: applicant.status === 'Interview Scheduled' || applicant.status === 'In Review'
    },
    {
      step: 4,
      title: 'Senate Admission Decision',
      date: applicant.admissionDecision?.decisionDate || 'Pending Committee',
      done: applicant.status === 'Offer Issued' || applicant.status === 'Matriculated',
      current: applicant.status === 'Decision Pending'
    },
    {
      step: 5,
      title: 'Acceptance & Matriculation Issuance',
      date: applicant.status === 'Matriculated' ? 'Officially Matriculated' : 'Action Required',
      done: applicant.status === 'Matriculated',
      current: applicant.status === 'Offer Issued'
    }
  ];

  const handleAcceptOffer = () => {
    acceptOfferAndMatriculate(applicant.id);
    setLetterModalOpen(false);
  };

  return (
    <div className="py-10 bg-[#F5F6F8]">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Breadcrumb Path */}
        <Breadcrumbs
          items={[
            { label: 'Seminary Home', view: 'public-home' },
            { label: 'Candidate Portal' },
            { label: applicant.applicationReference }
          ]}
        />

        {/* Top Dossier Summary Header */}
        <div className="bg-[#0D1524] text-white rounded-xl p-6 sm:p-8 border border-slate-800 shadow-sm">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <span className="font-mono text-xs text-[#FC8B0A] font-semibold">
                  REF: {applicant.applicationReference}
                </span>
                <span className="text-slate-600">·</span>
                <span className="text-xs text-slate-300 font-sans">
                  {applicant.intakeSession}
                </span>
              </div>

              <h1 className="font-display text-2xl sm:text-3xl font-bold text-white tracking-tight">
                {applicant.fullName}
              </h1>

              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-300">
                <span className="font-medium text-white">{applicant.programmeName}</span>
                <span>·</span>
                <span>{applicant.studyMode}</span>
                <span>·</span>
                <span className="text-slate-400">Submitted: {applicant.submissionDate}</span>
              </div>
            </div>

            {/* Action State / Decision Banner */}
            <div className="flex items-center gap-3 shrink-0">
              {applicant.status === 'Offer Issued' && (
                <button
                  type="button"
                  onClick={() => setLetterModalOpen(true)}
                  className="px-5 py-2.5 bg-[#FC8B0A] hover:bg-[#E07702] text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 cursor-pointer shadow-sm animate-pulse"
                >
                  <Award className="w-4 h-4" />
                  <span>Review Admission Offer & Letter</span>
                </button>
              )}

              {applicant.status === 'Matriculated' && (
                <button
                  type="button"
                  onClick={() => navigateTo('student-portal')}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 cursor-pointer shadow-sm"
                >
                  <GraduationCap className="w-4 h-4" />
                  <span>Enter Student Portal</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => setHelpModalOpen(true)}
                className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <HelpCircle className="w-4 h-4 text-[#FC8B0A]" />
                <span>Admissions Help</span>
              </button>
            </div>
          </div>
        </div>

        {/* Milestone Progression Bar */}
        <div className="bg-white rounded-xl border border-[#E5E7EB] p-6 sm:p-7 shadow-xs">
          <div className="flex items-center justify-between pb-4 border-b border-[#E5E7EB] mb-6">
            <h3 className="font-display text-base font-bold text-[#0D0D0E]">
              Admission Milestones & Committee Vetting
            </h3>
            <div className="flex items-center gap-2 text-xs">
              <span className="text-[#667085]">Current Status:</span>
              <StatusBadge status={applicant.status} />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-5 gap-4 relative">
            {milestones.map((ms, idx) => (
              <div
                key={ms.step}
                className={`p-4 rounded-lg border transition-all ${
                  ms.done
                    ? 'border-emerald-200 bg-emerald-50/30'
                    : ms.current
                    ? 'border-[#FC8B0A] bg-amber-50/20 shadow-xs'
                    : 'border-[#E5E7EB] bg-slate-50/50 opacity-70'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="font-mono text-xs font-bold text-[#667085]">
                    Step 0{ms.step}
                  </span>
                  {ms.done ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  ) : ms.current ? (
                    <Clock className="w-4 h-4 text-[#FC8B0A] animate-spin" />
                  ) : (
                    <div className="w-3.5 h-3.5 rounded-full border border-slate-300" />
                  )}
                </div>

                <div className="text-xs font-bold text-[#0D0D0E] leading-snug mb-1">
                  {ms.title}
                </div>
                <div className="text-[11px] text-[#667085]">
                  {ms.date}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Offer Notice Card if Offer Issued */}
        {applicant.status === 'Offer Issued' && applicant.admissionDecision && (
          <div className="bg-gradient-to-r from-amber-50 to-orange-50 border border-[#FC8B0A]/40 rounded-xl p-6 sm:p-8 flex flex-col sm:flex-row sm:items-center justify-between gap-6 shadow-xs">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-xs font-semibold text-[#FC8B0A] font-medium">
                <ShieldCheck className="w-4 h-4" />
                <span>Senate Decision: Provisional Admission Granted</span>
              </div>
              <h2 className="font-display text-xl sm:text-2xl font-bold text-[#0D0D0E]">
                Official Admission Offer Letter Ready
              </h2>
              <p className="text-xs text-[#0D0D0E]/80 max-w-2xl leading-relaxed">
                The Board of Admissions has admitted you into the <span className="font-semibold">{applicant.programmeName}</span> programme. Your provisional matriculation number is <span className="font-mono font-bold text-[#0D0D0E]">{applicant.admissionDecision.matriculationNumber}</span>. Please accept this offer to complete your student registration.
              </p>
            </div>

            <button
              type="button"
              onClick={() => setLetterModalOpen(true)}
              className="px-6 py-3 bg-[#0D0D0E] hover:bg-[#0D1524] text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 cursor-pointer shrink-0 shadow-sm"
            >
              <span>View Letter & Accept Offer</span>
              <ArrowRight className="w-4 h-4 text-[#FC8B0A]" />
            </button>
          </div>
        )}

        {/* Matriculated Confirmation Banner */}
        {applicant.status === 'Matriculated' && (
          <div className="bg-emerald-50 border border-emerald-300 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
              <div>
                <h4 className="font-display text-sm font-bold text-emerald-950">
                  Admission Formally Accepted · Matriculation Number Issued
                </h4>
                <p className="text-xs text-emerald-800 mt-0.5">
                  Your formal student profile is active with matriculation credentials. You can access the student portal, course syllabus, and lecture timetables.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => navigateTo('student-portal')}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer shrink-0"
            >
              Open Student Portal &rarr;
            </button>
          </div>
        )}

        {/* 2-Column Details: Dossier Records & Uploaded Documents */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left: Personal & Church Background */}
          <div className="lg:col-span-7 space-y-6">
            <div className="bg-white rounded-xl border border-[#E5E7EB] p-6 shadow-xs space-y-5">
              <h3 className="font-display text-base font-bold text-[#0D0D0E] pb-3 border-b border-[#E5E7EB]">
                Personal & Ministerial Dossier
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="text-[#667085] block">Full Name:</span>
                  <span className="font-semibold text-[#0D0D0E]">{applicant.fullName}</span>
                </div>
                <div>
                  <span className="text-[#667085] block">Email:</span>
                  <span className="font-semibold text-[#0D0D0E]">{applicant.email}</span>
                </div>
                <div>
                  <span className="text-[#667085] block">Church Affiliation:</span>
                  <span className="font-semibold text-[#0D0D0E]">
                    {applicant.personalInfo.churchDenomination}
                  </span>
                </div>
                <div>
                  <span className="text-[#667085] block">Supervising Pastor:</span>
                  <span className="font-semibold text-[#0D0D0E]">
                    {applicant.personalInfo.pastorName}
                  </span>
                </div>
                <div>
                  <span className="text-[#667085] block">Years Born Again:</span>
                  <span className="font-semibold text-[#0D0D0E]">
                    {applicant.personalInfo.yearsBornAgain} Years
                  </span>
                </div>
                <div>
                  <span className="text-[#667085] block">Nationality / Origin:</span>
                  <span className="font-semibold text-[#0D0D0E]">
                    {applicant.personalInfo.nationality} {applicant.personalInfo.stateOfOrigin ? `(${applicant.personalInfo.stateOfOrigin})` : ''}
                  </span>
                </div>
              </div>

              <div className="pt-3 border-t border-[#E5E7EB]">
                <span className="text-[#667085] block text-xs mb-1">
                  Ministerial Calling Statement:
                </span>
                <p className="text-xs text-[#0D0D0E] bg-[#F5F6F8] p-3 rounded-lg leading-relaxed">
                  "{applicant.personalInfo.ministerialCalling}"
                </p>
              </div>
            </div>

            {/* Education History Card */}
            <div className="bg-white rounded-xl border border-[#E5E7EB] p-6 shadow-xs space-y-4">
              <h3 className="font-display text-base font-bold text-[#0D0D0E] pb-3 border-b border-[#E5E7EB]">
                Academic & Educational Background
              </h3>

              <div className="space-y-3">
                {applicant.educationHistory.map((edu, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-lg border border-[#E5E7EB] bg-[#F5F6F8]/60 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="font-semibold text-[#0D0D0E]">
                        {edu.qualification}
                      </div>
                      <div className="text-[#667085] mt-0.5">
                        {edu.institution}
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="font-mono text-[#0D0D0E] font-medium">
                        {edu.yearCompleted}
                      </span>
                      {edu.gradeOrClass && (
                        <div className="text-[11px] text-[#FC8B0A] font-medium">
                          {edu.gradeOrClass}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right: Uploaded Credentials & Registry Notifications */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white rounded-xl border border-[#E5E7EB] p-6 shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
                <h3 className="font-display text-base font-bold text-[#0D0D0E]">
                  Submitted Credentials ({applicant.documents.length})
                </h3>
                <span className="text-[11px] text-[#667085]">
                  Registry Verified
                </span>
              </div>

              <div className="space-y-2.5">
                {applicant.documents.map((doc) => (
                  <div
                    key={doc.id}
                    className="p-3 rounded-lg border border-[#E5E7EB] flex items-center justify-between text-xs hover:bg-slate-50 transition-colors"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <FileText className="w-4 h-4 text-[#FC8B0A] shrink-0" />
                      <div className="min-w-0">
                        <div className="font-medium text-[#0D0D0E] truncate">
                          {doc.name}
                        </div>
                        <div className="text-[10px] text-[#667085]">
                          {doc.type} · {doc.fileSize}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {doc.verified ? (
                        <span className="text-[10px] text-emerald-700 font-medium">
                          Verified
                        </span>
                      ) : (
                        <span className="text-[10px] text-amber-700 font-medium">
                          Pending
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Admissions Committee Notice */}
            <div className="p-6 rounded-xl border border-[#E5E7EB] bg-white space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-[#0D0D0E]">
                <Building className="w-4 h-4 text-[#FC8B0A]" />
                <span>Office of the Registrar Guidance</span>
              </div>
              <p className="text-xs text-[#667085] leading-relaxed">
                Candidates admitted into residential tracks are required to present original copies of all uploaded academic credentials during the matriculation screening session on October 22, 2026.
              </p>
              <div className="pt-2 text-xs text-[#0D0D0E] font-medium">
                Helpline: +234 803 456 7890 (Ext. 12)
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Admission Decision Offer Letter Modal */}
      {applicant.admissionDecision && (
        <Modal
          isOpen={letterModalOpen}
          onClose={() => setLetterModalOpen(false)}
          title="Official Provisional Offer of Admission"
          subtitle={`Academic Session: ${applicant.intakeSession} · Ref: ${applicant.applicationReference}`}
          maxWidth="2xl"
        >
          <div className="space-y-6 text-xs text-[#0D0D0E]">
            {/* Formal Letterhead */}
            <div className="p-4 bg-[#F5F6F8] rounded-xl border border-[#E5E7EB] text-center space-y-1">
              <div className="font-display text-sm font-bold text-[#0D0D0E] tracking-tight">
                CHRIST REDEMPTION BIBLE EVANGELICAL MISSION THEOLOGICAL SEMINARY
              </div>
              <div className="text-[10px] text-[#667085] font-mono">
                Office of the Registrar · Academic Directorate
              </div>
              <div className="text-[10px] text-[#FC8B0A] font-semibold">
                Veritas et Ministerium (2 Timothy 2:15)
              </div>
            </div>

            {/* Letter Content */}
            <div className="whitespace-pre-line leading-relaxed text-slate-800 bg-white p-4 border border-[#E5E7EB] rounded-lg font-sans">
              {applicant.admissionDecision.letterContent}
            </div>

            {/* Candidate Acceptance Section */}
            <div className="p-4 rounded-xl bg-amber-50/60 border border-[#FC8B0A]/30 space-y-3">
              <h4 className="font-display text-xs font-bold text-[#0D0D0E]">
                Candidate Declaration & Acceptance of Offer
              </h4>
              <p className="text-[11px] text-[#667085] leading-relaxed">
                By clicking "Accept Offer & Matriculate", you affirm your commitment to the CRBEM Theological Seminary Doctrinal Confession, Christian discipline, and academic diligence.
              </p>

              {applicant.status === 'Matriculated' ? (
                <div className="flex items-center gap-2 text-emerald-700 font-semibold text-xs">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Offer Accepted. Matriculation Number: {applicant.admissionDecision.matriculationNumber}</span>
                </div>
              ) : (
                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setLetterModalOpen(false)}
                    className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
                  >
                    Review Later
                  </button>
                  <button
                    type="button"
                    onClick={handleAcceptOffer}
                    className="px-5 py-2.5 bg-[#FC8B0A] hover:bg-[#E07702] text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer shadow-xs flex items-center gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Accept Offer & Formally Matriculate</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </Modal>
      )}

      {/* Admissions Help Modal */}
      <Modal
        isOpen={helpModalOpen}
        onClose={() => setHelpModalOpen(false)}
        title="Admissions Directorate Support Desk"
        subtitle="Assistance for applicants and registered candidates"
        maxWidth="md"
      >
        <div className="space-y-4 text-xs text-[#0D0D0E]">
          <p className="text-slate-600 leading-relaxed">
            If you need assistance regarding document verification, fee payment arrangements, or interview schedules, please contact our admissions officers directly:
          </p>
          <div className="p-3 bg-[#F5F6F8] rounded-lg border border-[#E5E7EB] space-y-2">
            <div>
              <span className="font-semibold block text-[#0D0D0E]">Email Support:</span>
              <a href="mailto:admissions@crbemseminary.edu" className="text-[#FC8B0A] hover:underline">
                admissions@crbemseminary.edu
              </a>
            </div>
            <div>
              <span className="font-semibold block text-[#0D0D0E]">Phone Helpline:</span>
              <span className="font-mono text-slate-700">+234 (0) 803 456 7890</span>
            </div>
            <div>
              <span className="font-semibold block text-[#0D0D0E]">Office Desk:</span>
              <span>Registry Block A, Room 104, CRBEM Central Grounds</span>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setHelpModalOpen(false)}
            className="w-full py-2.5 bg-[#0D0D0E] text-white rounded-lg font-semibold hover:bg-slate-800 transition-colors"
          >
            Close Help Desk
          </button>
        </div>
      </Modal>
    </div>
  );
};
