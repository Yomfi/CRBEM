/**
 * CRBEM Theological Seminary - Digital Theological Library Catalogue
 * Modern university library catalogue with shelf classification, citations,
 * scholarly excerpts, and borrowing loan tracker.
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { LibraryBook } from '../../types';
import { Breadcrumbs } from '../common/Breadcrumbs';
import { Modal } from '../common/Modal';
import { SearchFilterBar } from '../common/SearchFilterBar';
import { Tabs } from '../common/Tabs';
import { EmptyState } from '../common/EmptyState';
import {
  Library,
  BookOpen,
  Bookmark,
  BookmarkCheck,
  Quote,
  Clock,
  CheckCircle2,
  Copy,
  Check,
  ExternalLink,
  RotateCcw
} from 'lucide-react';

export const DigitalLibraryView: React.FC = () => {
  const {
    libraryBooks,
    libraryLoans,
    savedBookIds,
    borrowBook,
    returnBook,
    toggleSaveBook,
    addToast
  } = useApp();

  const [activeTab, setActiveTab] = useState<'catalogue' | 'saved' | 'loans'>('catalogue');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All Categories');

  // Modals state
  const [detailBook, setDetailBook] = useState<LibraryBook | null>(null);
  const [excerptBook, setExcerptBook] = useState<LibraryBook | null>(null);
  const [citeBook, setCiteBook] = useState<LibraryBook | null>(null);
  const [citationFormat, setCitationFormat] = useState<'Turabian' | 'APA' | 'MLA'>('Turabian');
  const [copiedCitation, setCopiedCitation] = useState(false);

  const categories = [
    'All Categories',
    'Systematic Theology',
    'Biblical Exegesis',
    'Biblical Languages',
    'Pastoral Ministry',
    'Church History',
    'CRBEM Archives'
  ];

  // Filter books
  const filteredBooks = libraryBooks.filter((book) => {
    const matchesCategory =
      selectedCategory === 'All Categories' || book.category === selectedCategory;
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      book.title.toLowerCase().includes(q) ||
      book.author.toLowerCase().includes(q) ||
      book.isbn.toLowerCase().includes(q) ||
      book.shelfLocation.toLowerCase().includes(q) ||
      book.summary.toLowerCase().includes(q);
    return matchesCategory && matchesSearch;
  });

  const savedBooks = libraryBooks.filter((b) => savedBookIds.includes(b.id));

  // Generate citation string
  const generateCitation = (book: LibraryBook, format: 'Turabian' | 'APA' | 'MLA') => {
    if (format === 'Turabian') {
      return `${book.author}. ${book.title}. ${book.edition}. Lagos: CRBEM Theological Seminary Library Repository, ${book.publicationYear}. Shelf: ${book.shelfLocation}.`;
    }
    if (format === 'APA') {
      return `${book.author} (${book.publicationYear}). ${book.title} (${book.edition}). CRBEM Theological Library. https://library.crbemseminary.edu/catalog/${book.isbn}`;
    }
    return `${book.author}. "${book.title}." ${book.edition}, CRBEM Theological Seminary Press, ${book.publicationYear}.`;
  };

  const handleCopyCitation = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCitation(true);
    addToast('Citation Copied', 'Copied to clipboard in ' + citationFormat + ' format.', 'info');
    setTimeout(() => setCopiedCitation(false), 2500);
  };

  return (
    <div className="py-10 bg-[#F5F6F8]">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <Breadcrumbs
          items={[
            { label: 'Seminary Home', view: 'public-home' },
            { label: 'Digital Theological Library & Archives' }
          ]}
        />

        {/* Library Header */}
        <div className="bg-[#0D1524] text-white rounded-xl p-8 border border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-xs font-mono text-[#FC8B0A]">
              <Library className="w-4 h-4" />
              <span>CRBEM THEOLOGICAL LIBRARY & RESEARCH REPOSITORY</span>
            </div>
            <h1 className="font-display text-2xl sm:text-3xl font-bold text-white tracking-tight">
              Scholarly Catalogue & Archival Holdings
            </h1>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              Serving faculty, students, and research fellows with peer-reviewed evangelical texts, Greek/Hebrew lexica, patristic sourcebooks, and historic mission archives.
            </p>
          </div>

          <div className="flex items-center gap-4 bg-slate-900/90 border border-slate-700/80 p-4 rounded-xl shrink-0 text-left">
            <div>
              <div className="text-[11px] text-slate-400">Total Volumes</div>
              <div className="font-display text-xl font-bold text-white">
                {libraryBooks.length} Catalogued
              </div>
            </div>
            <div className="border-l border-slate-700 pl-4">
              <div className="text-[11px] text-slate-400">Active Loans</div>
              <div className="font-display text-xl font-bold text-[#FC8B0A]">
                {libraryLoans.filter((l) => l.status === 'Active').length} Issued
              </div>
            </div>
          </div>
        </div>

        {/* Tabs: Catalogue / Saved / Loans */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <Tabs
            tabs={[
              { id: 'catalogue', label: 'Library Catalogue', count: libraryBooks.length },
              { id: 'saved', label: 'My Reading List', count: savedBooks.length },
              { id: 'loans', label: 'Borrowing History & Loans', count: libraryLoans.length }
            ]}
            activeTab={activeTab}
            onChange={(tab) => setActiveTab(tab as any)}
          />

          {activeTab === 'catalogue' && (
            <div className="text-xs text-[#667085]">
              Showing <span className="font-semibold text-[#0D0D0E]">{filteredBooks.length}</span> volumes
            </div>
          )}
        </div>

        {/* Tab 1: Catalogue */}
        {activeTab === 'catalogue' && (
          <div className="space-y-6">
            {/* Search and Category Filter */}
            <SearchFilterBar
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
              placeholder="Search by title, author, ISBN (e.g. Grudem, 978-0310286707), or shelf location..."
              categories={categories}
              selectedCategory={selectedCategory}
              onCategoryChange={setSelectedCategory}
            />

            {filteredBooks.length === 0 ? (
              <EmptyState
                title="No Volumes Found"
                description={`No theological volumes found matching "${searchQuery}". Try searching for systematic theology, Greek, or another keyword.`}
                actionText="Reset Filters"
                onAction={() => {
                  setSearchQuery('');
                  setSelectedCategory('All Categories');
                }}
              />
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredBooks.map((book) => {
                  const isSaved = savedBookIds.includes(book.id);
                  const isAvailable = book.availableCopies > 0;

                  return (
                    <div
                      key={book.id}
                      className="bg-white rounded-xl border border-[#E5E7EB] hover:border-slate-400 transition-all p-6 flex flex-col justify-between shadow-xs"
                    >
                      <div>
                        {/* Shelf & Category Metadata (No Pill) */}
                        <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3 text-xs">
                          <span className="font-mono font-bold text-[#0D0D0E]">
                            Shelf: {book.shelfLocation}
                          </span>
                          <span className="text-[#667085] text-[11px]">
                            {book.category}
                          </span>
                        </div>

                        <h3 className="font-display text-base font-bold text-[#0D0D0E] mb-1 leading-snug line-clamp-2">
                          {book.title}
                        </h3>

                        <div className="text-xs text-[#FC8B0A] font-medium mb-3">
                          {book.author} ({book.publicationYear})
                        </div>

                        <p className="text-xs text-[#667085] leading-relaxed line-clamp-3 mb-4">
                          {book.summary}
                        </p>

                        <div className="text-[11px] text-[#667085] space-y-1 mb-4">
                          <div><span className="font-medium text-slate-700">ISBN:</span> {book.isbn}</div>
                          <div><span className="font-medium text-slate-700">Edition:</span> {book.edition}</div>
                          <div>
                            <span className="font-medium text-slate-700">Copies:</span>{' '}
                            <span className={isAvailable ? 'text-emerald-700 font-semibold' : 'text-rose-700 font-semibold'}>
                              {book.availableCopies} available of {book.totalCopies}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Action Bar */}
                      <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => setExcerptBook(book)}
                            className="px-2.5 py-1.5 bg-[#F5F6F8] hover:bg-slate-200/70 text-[#0D0D0E] text-[11px] font-semibold rounded-md transition-colors cursor-pointer"
                            title="Read scholarly excerpt"
                          >
                            Read Excerpt
                          </button>
                          <button
                            type="button"
                            onClick={() => setCiteBook(book)}
                            className="px-2.5 py-1.5 bg-[#F5F6F8] hover:bg-slate-200/70 text-[#0D0D0E] text-[11px] font-medium rounded-md transition-colors cursor-pointer"
                            title="Generate citation"
                          >
                            <Quote className="w-3 h-3 inline mr-1" />
                            Cite
                          </button>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => toggleSaveBook(book.id)}
                            className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                              isSaved
                                ? 'text-[#FC8B0A] bg-amber-50'
                                : 'text-slate-400 hover:text-slate-700 hover:bg-slate-100'
                            }`}
                            title={isSaved ? 'Remove from saved' : 'Save to reading list'}
                          >
                            <Bookmark className="w-4 h-4" />
                          </button>

                          <button
                            type="button"
                            disabled={!isAvailable}
                            onClick={() => borrowBook(book.id)}
                            className={`px-3 py-1.5 text-[11px] font-semibold rounded-md transition-colors cursor-pointer ${
                              isAvailable
                                ? 'bg-[#0D0D0E] hover:bg-[#0D1524] text-white'
                                : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                            }`}
                          >
                            {isAvailable ? 'Check Out' : 'All Loaned'}
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Saved Reading List */}
        {activeTab === 'saved' && (
          <div className="space-y-4">
            {savedBooks.length === 0 ? (
              <EmptyState
                title="Your Reading List is Empty"
                description="Save theological volumes from the catalogue to prepare research bibliographies or study lists."
                actionText="Explore Catalogue"
                onAction={() => setActiveTab('catalogue')}
              />
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {savedBooks.map((book) => (
                  <div
                    key={book.id}
                    className="bg-white rounded-xl border border-[#E5E7EB] p-6 shadow-xs flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between pb-2 border-b border-slate-100 mb-3 text-xs">
                        <span className="font-mono font-bold">{book.shelfLocation}</span>
                        <span className="text-[#667085]">{book.category}</span>
                      </div>
                      <h3 className="font-display text-base font-bold text-[#0D0D0E] mb-1">
                        {book.title}
                      </h3>
                      <div className="text-xs text-[#FC8B0A] font-medium mb-3">
                        {book.author}
                      </div>
                      <p className="text-xs text-[#667085] line-clamp-3 mb-4">
                        {book.summary}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                      <button
                        type="button"
                        onClick={() => setExcerptBook(book)}
                        className="text-xs font-semibold text-[#0D0D0E] hover:underline"
                      >
                        Read Excerpt &rarr;
                      </button>
                      <button
                        type="button"
                        onClick={() => toggleSaveBook(book.id)}
                        className="text-xs text-rose-600 hover:underline cursor-pointer"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Loans & Borrowing History */}
        {activeTab === 'loans' && (
          <div className="bg-white rounded-xl border border-[#E5E7EB] overflow-hidden shadow-xs">
            <div className="p-5 border-b border-[#E5E7EB] bg-[#F5F6F8]">
              <h3 className="font-display text-base font-bold text-[#0D0D0E]">
                Active Loans & Circulation Records
              </h3>
              <p className="text-xs text-[#667085] mt-0.5">
                Standard borrowing privilege is 21 calendar days per volume.
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#F5F6F8] text-[#667085] border-b border-[#E5E7EB]">
                  <tr>
                    <th className="py-3 px-5 font-semibold">Volume Title</th>
                    <th className="py-3 px-5 font-semibold">Author</th>
                    <th className="py-3 px-5 font-semibold">Shelf Location</th>
                    <th className="py-3 px-5 font-semibold">Borrower</th>
                    <th className="py-3 px-5 font-semibold">Due Date</th>
                    <th className="py-3 px-5 font-semibold text-right">Status / Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E5E7EB]">
                  {libraryLoans.map((loan) => (
                    <tr key={loan.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3.5 px-5 font-medium text-[#0D0D0E]">
                        {loan.bookTitle}
                      </td>
                      <td className="py-3.5 px-5 text-[#667085]">
                        {loan.bookAuthor}
                      </td>
                      <td className="py-3.5 px-5 font-mono text-[#0D0D0E]">
                        {loan.shelfLocation}
                      </td>
                      <td className="py-3.5 px-5 text-[#0D0D0E]">
                        {loan.userName}
                      </td>
                      <td className="py-3.5 px-5 font-mono text-[#667085]">
                        {loan.dueDate}
                      </td>
                      <td className="py-3.5 px-5 text-right">
                        {loan.status === 'Active' ? (
                          <button
                            type="button"
                            onClick={() => returnBook(loan.id)}
                            className="px-3 py-1 bg-[#F5F6F8] hover:bg-slate-200 text-[#0D0D0E] font-medium rounded-md border border-[#E5E7EB] transition-colors cursor-pointer"
                          >
                            <RotateCcw className="w-3 h-3 inline mr-1 text-[#FC8B0A]" />
                            Return Volume
                          </button>
                        ) : (
                          <span className="text-emerald-700 font-medium">
                            Returned ({loan.returnDate})
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Read Excerpt Modal */}
      {excerptBook && (
        <Modal
          isOpen={!!excerptBook}
          onClose={() => setExcerptBook(null)}
          title={`Scholarly Excerpt: ${excerptBook.title}`}
          subtitle={`${excerptBook.author} · Shelf: ${excerptBook.shelfLocation}`}
          maxWidth="2xl"
        >
          <div className="space-y-5 text-xs text-[#0D0D0E]">
            <div className="p-4 bg-[#F5F6F8] rounded-xl border border-[#E5E7EB] flex items-center justify-between">
              <div>
                <span className="font-semibold block text-[#0D0D0E]">{excerptBook.edition}</span>
                <span className="text-[11px] text-[#667085]">Category: {excerptBook.category} · ISBN: {excerptBook.isbn}</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setCiteBook(excerptBook);
                }}
                className="px-3 py-1.5 bg-white border border-[#E5E7EB] hover:bg-slate-100 rounded-md text-xs font-semibold"
              >
                Cite this Text
              </button>
            </div>

            <div className="p-5 bg-white border border-[#E5E7EB] rounded-xl font-display text-sm leading-relaxed text-slate-800 space-y-4">
              <div className="text-[11px] font-sans font-medium text-[#FC8B0A]">
                Selected Excerpt from the Archives
              </div>
              <p className="italic">
                "{excerptBook.excerpt}"
              </p>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setExcerptBook(null)}
                className="px-4 py-2 bg-[#0D0D0E] text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition-colors"
              >
                Close Reader
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Citation Modal */}
      {citeBook && (
        <Modal
          isOpen={!!citeBook}
          onClose={() => setCiteBook(null)}
          title="Cite Theological Resource"
          subtitle={citeBook.title}
          maxWidth="lg"
        >
          <div className="space-y-5 text-xs text-[#0D0D0E]">
            <div className="flex items-center gap-2">
              <span className="text-slate-600 font-medium">Citation Style:</span>
              {(['Turabian', 'APA', 'MLA'] as const).map((fmt) => (
                <button
                  key={fmt}
                  type="button"
                  onClick={() => setCitationFormat(fmt)}
                  className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                    citationFormat === fmt
                      ? 'bg-[#0D0D0E] text-white'
                      : 'bg-[#F5F6F8] text-[#667085] hover:text-[#0D0D0E]'
                  }`}
                >
                  {fmt === 'Turabian' ? 'Chicago / Turabian (17th)' : fmt}
                </button>
              ))}
            </div>

            <div className="p-4 bg-[#F5F6F8] border border-[#E5E7EB] rounded-xl font-mono text-xs text-slate-800 leading-relaxed break-words">
              {generateCitation(citeBook, citationFormat)}
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setCiteBook(null)}
                className="px-4 py-2 text-slate-600 hover:text-slate-900"
              >
                Dismiss
              </button>
              <button
                type="button"
                onClick={() => handleCopyCitation(generateCitation(citeBook, citationFormat))}
                className="px-5 py-2.5 bg-[#FC8B0A] hover:bg-[#E07702] text-white font-semibold rounded-lg transition-colors flex items-center gap-2 cursor-pointer shadow-xs"
              >
                {copiedCitation ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copiedCitation ? 'Copied!' : 'Copy Citation to Clipboard'}</span>
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
