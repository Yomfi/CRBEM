/**
 * CRBEM Theological Seminary - Administration Portal
 * Multi-role governance: Registrar, Admissions Officer, Lecturer, Librarian, Super Admin
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Applicant, Student, Announcement } from '../../types';
import { StatusBadge } from '../common/StatusBadge';
import { Breadcrumbs } from '../common/Breadcrumbs';
import { Modal } from '../common/Modal';
import { Tabs } from '../common/Tabs';
import {
  ShieldCheck,
  UserCheck,
  GraduationCap,
  BookOpen,
  Library,
  Bell,
  Mail,
  Settings,
  FileText,
  Search,
  CheckCircle2,
  XCircle,
  Clock,
  Plus,
  RotateCcw,
  Eye,
  Award
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const {
    currentRole,
    currentUser,
    applicants,
    students,
    courses,
    libraryBooks,
    libraryLoans,
    announcements,
    enquiries,
    auditLogs,
    updateApplicationStatus,
    issueAdmissionOffer,
    publishAnnouncement,
    markEnquiryReplied,
    returnBook,
    addToast
  } = useApp();

  const [activeTab, setActiveTab] = useState<
    'applications' | 'students' | 'courses' | 'library' | 'announcements' | 'enquiries' | 'audit'
  >('applications');

  // Filter/search in applications
  const [appSearch, setAppSearch] = useState('');
  const [selectedApp, setSelectedApp] = useState<Applicant | null>(null);

  // Assign matriculation modal
  const [matricModalOpen, setMatricModalOpen] = useState(false);
  const [targetAppId, setTargetAppId] = useState<string | null>(null);
  const [matricInput, setMatricInput] = useState('CRBEM/BTH/2026/088');

  // New announcement form modal
  const [newAnnounceModal, setNewAnnounceModal] = useState(false);
  const [announceTitle, setAnnounceTitle] = useState('');
  const [announceContent, setAnnounceContent] = useState('');
  const [announcePriority, setAnnouncePriority] = useState<'Normal' | 'High' | 'Urgent'>('High');

  const filteredApplicants = applicants.filter(
    (a) =>
      a.fullName.toLowerCase().includes(appSearch.toLowerCase()) ||
      a.applicationReference.toLowerCase().includes(appSearch.toLowerCase()) ||
      a.programmeName.toLowerCase().includes(appSearch.toLowerCase())
  );

  const handleOpenMatricModal = (app: Applicant) => {
    setTargetAppId(app.id);
    setMatricInput(`CRBEM/${app.programmeId === 'prog-bth' ? 'BTH' : 'DIP'}/2026/${Math.floor(100 + Math.random() * 900)}`);
    setMatricModalOpen(true);
  };

  const handleConfirmMatriculation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetAppId || !matricInput) return;
    issueAdmissionOffer(targetAppId, matricInput);
    setMatricModalOpen(false);
    setTargetAppId(null);
  };

  const handleCreateAnnouncement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!announceTitle || !announceContent) return;

    publishAnnouncement({
      title: announceTitle,
      category: 'Registrar',
      content: announceContent,
      author: currentUser?.fullName || 'Office of the Registrar',
      priority: announcePriority,
      targetAudience: 'All'
    });

    setNewAnnounceModal(false);
    setAnnounceTitle('');
    setAnnounceContent('');
  };

  return (
    <div className="py-10 bg-[#F5F6F8]">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <Breadcrumbs
          items={[
            { label: 'Seminary Home', view: 'public-home' },
            { label: 'Administration Directorate' },
            { label: `${currentRole} Console` }
          ]}
        />

        {/* Admin Header */}
        <div className="bg-[#0D1524] text-white rounded-xl p-8 border border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-xs font-mono text-[#FC8B0A]">
              <ShieldCheck className="w-4 h-4" />
              <span>INSTITUTIONAL ADMINISTRATION & REGISTRAR CONSOLE</span>
            </div>
            <h1 className="font-display text-2xl sm:text-3xl font-bold text-white tracking-tight">
              Academic Directorate Portal
            </h1>
            <p className="text-xs text-slate-300">
              Active Administrative Role: <strong className="text-white font-semibold">{currentRole}</strong> · Academic Session 2026/2027
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setNewAnnounceModal(true)}
              className="px-4 py-2.5 bg-[#FC8B0A] hover:bg-[#E07702] text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>Publish Notice</span>
            </button>
          </div>
        </div>

        {/* Admin Navigation Tabs */}
        <div className="bg-white rounded-xl border border-[#E5E7EB] p-2 shadow-xs">
          <Tabs
            tabs={[
              { id: 'applications', label: 'Candidate Applications', count: applicants.length, icon: <UserCheck className="w-3.5 h-3.5" /> },
              { id: 'students', label: 'Student Records', count: students.length, icon: <GraduationCap className="w-3.5 h-3.5" /> },
              { id: 'courses', label: 'Curricula & Courses', count: courses.length, icon: <BookOpen className="w-3.5 h-3.5" /> },
              { id: 'library', label: 'Library Circulation', count: libraryLoans.length, icon: <Library className="w-3.5 h-3.5" /> },
              { id: 'announcements', label: 'Notices & Bulletins', count: announcements.length, icon: <Bell className="w-3.5 h-3.5" /> },
              { id: 'enquiries', label: 'Contact Enquiries', count: enquiries.length, icon: <Mail className="w-3.5 h-3.5" /> },
              { id: 'audit', label: 'System Audit Logs', count: auditLogs.length, icon: <Settings className="w-3.5 h-3.5" /> }
            ]}
            activeTab={activeTab}
            onChange={(tab) => setActiveTab(tab as any)}
          />
        </div>

        {/* Tab 1: Applications Management */}
        {activeTab === 'applications' && (
          <div className="bg-white rounded-xl border border-[#E5E7EB] overflow-hidden shadow-xs space-y-4 p-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="font-display text-lg font-bold text-[#0D0D0E]">
                  Candidate Admissions Review
                </h3>
                <p className="text-xs text-[#667085]">
                  Vetting dossiers, issuing entrance interview notes, and assigning matriculation credentials.
                </p>
              </div>

              <div className="relative sm:w-72">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={appSearch}
                  onChange={(e) => setAppSearch(e.target.value)}
                  placeholder="Filter candidate name or ref..."
                  className="w-full pl-9 pr-3 py-2 text-xs border border-[#E5E7EB] rounded-lg outline-none focus:border-[#FC8B0A]"
                />
              </div>
            </div>

            <div className="border border-[#E5E7EB] rounded-lg overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#F5F6F8] text-[#667085] border-b border-[#E5E7EB]">
                  <tr>
                    <th className="py-3 px-4 font-semibold">Ref Number</th>
                    <th className="py-3 px-4 font-semibold">Candidate</th>
                    <th className="py-3 px-4 font-semibold">Programme</th>
                    <th className="py-3 px-4 font-semibold">Mode</th>
                    <th className="py-3 px-4 font-semibold">Status</th>
                    <th className="py-3 px-4 font-semibold text-right">Committee Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E5E7EB]">
                  {filteredApplicants.map((app) => (
                    <tr key={app.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-[#0D0D0E]">
                        {app.applicationReference}
                      </td>
                      <td className="py-3 px-4 font-medium text-[#0D0D0E]">
                        {app.fullName}
                        <div className="text-[10px] text-[#667085]">{app.email}</div>
                      </td>
                      <td className="py-3 px-4 text-[#0D0D0E]">
                        {app.programmeName}
                      </td>
                      <td className="py-3 px-4 text-[#667085]">
                        {app.studyMode}
                      </td>
                      <td className="py-3 px-4">
                        <StatusBadge status={app.status} />
                      </td>
                      <td className="py-3 px-4 text-right space-x-1.5 whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => setSelectedApp(app)}
                          className="px-2.5 py-1 text-[11px] bg-[#F5F6F8] hover:bg-slate-200 text-[#0D0D0E] font-medium rounded-md border border-[#E5E7EB]"
                          title="View complete dossier"
                        >
                          Dossier
                        </button>

                        {app.status !== 'Matriculated' && app.status !== 'Offer Issued' && (
                          <button
                            type="button"
                            onClick={() => handleOpenMatricModal(app)}
                            className="px-2.5 py-1 text-[11px] bg-[#0D0D0E] hover:bg-[#0D1524] text-white font-semibold rounded-md shadow-xs cursor-pointer"
                          >
                            Grant Offer & Matric
                          </button>
                        )}

                        {app.status === 'Offer Issued' && (
                          <span className="text-[10px] font-mono text-[#FC8B0A] font-semibold">
                            {app.admissionDecision?.matriculationNumber}
                          </span>
                        )}

                        {app.status === 'Matriculated' && (
                          <span className="text-[10px] font-mono text-emerald-700 font-semibold">
                            Matriculated
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 2: Students Records */}
        {activeTab === 'students' && (
          <div className="bg-white rounded-xl border border-[#E5E7EB] p-6 shadow-xs space-y-4">
            <h3 className="font-display text-lg font-bold text-[#0D0D0E]">
              Matriculated Student Registry
            </h3>

            <div className="border border-[#E5E7EB] rounded-lg overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#F5F6F8] text-[#667085] border-b border-[#E5E7EB]">
                  <tr>
                    <th className="py-3 px-4 font-semibold">Matriculation No</th>
                    <th className="py-3 px-4 font-semibold">Student Name</th>
                    <th className="py-3 px-4 font-semibold">Programme</th>
                    <th className="py-3 px-4 font-semibold">Level</th>
                    <th className="py-3 px-4 font-semibold">Advisor</th>
                    <th className="py-3 px-4 font-semibold text-right">CGPA</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E5E7EB]">
                  {students.map((stu) => (
                    <tr key={stu.id} className="hover:bg-slate-50">
                      <td className="py-3 px-4 font-mono font-bold text-[#0D0D0E]">
                        {stu.matriculationNumber}
                      </td>
                      <td className="py-3 px-4 font-medium text-[#0D0D0E]">
                        {stu.fullName}
                      </td>
                      <td className="py-3 px-4 text-[#0D0D0E]">
                        {stu.programmeName}
                      </td>
                      <td className="py-3 px-4 text-[#667085]">
                        {stu.level}
                      </td>
                      <td className="py-3 px-4 text-[#667085]">
                        {stu.facultyAdvisor}
                      </td>
                      <td className="py-3 px-4 text-right font-bold text-emerald-700 font-mono">
                        {stu.cumulativeGpa > 0 ? stu.cumulativeGpa.toFixed(2) : '3.84'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 3: Courses Manager */}
        {activeTab === 'courses' && (
          <div className="bg-white rounded-xl border border-[#E5E7EB] p-6 shadow-xs space-y-4">
            <h3 className="font-display text-lg font-bold text-[#0D0D0E]">
              Academic Courses & Lecturers
            </h3>

            <div className="border border-[#E5E7EB] rounded-lg overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#F5F6F8] text-[#667085] border-b border-[#E5E7EB]">
                  <tr>
                    <th className="py-3 px-4 font-semibold">Code</th>
                    <th className="py-3 px-4 font-semibold">Title</th>
                    <th className="py-3 px-4 font-semibold">Credits</th>
                    <th className="py-3 px-4 font-semibold">Assigned Lecturer</th>
                    <th className="py-3 px-4 font-semibold">Schedule & Venue</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E5E7EB]">
                  {courses.map((c) => (
                    <tr key={c.id} className="hover:bg-slate-50">
                      <td className="py-3 px-4 font-mono font-bold text-[#0D0D0E]">
                        {c.code}
                      </td>
                      <td className="py-3 px-4 font-medium text-[#0D0D0E]">
                        {c.title}
                      </td>
                      <td className="py-3 px-4 text-[#667085]">
                        {c.credits} Units
                      </td>
                      <td className="py-3 px-4 text-[#0D0D0E]">
                        {c.lecturerName}
                      </td>
                      <td className="py-3 px-4 text-[#667085]">
                        {c.schedule} · {c.venue}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 4: Library Circulation Manager */}
        {activeTab === 'library' && (
          <div className="bg-white rounded-xl border border-[#E5E7EB] p-6 shadow-xs space-y-4">
            <h3 className="font-display text-lg font-bold text-[#0D0D0E]">
              Library Circulation & Active Loans
            </h3>

            <div className="border border-[#E5E7EB] rounded-lg overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#F5F6F8] text-[#667085] border-b border-[#E5E7EB]">
                  <tr>
                    <th className="py-3 px-4 font-semibold">Volume</th>
                    <th className="py-3 px-4 font-semibold">Shelf</th>
                    <th className="py-3 px-4 font-semibold">Borrower</th>
                    <th className="py-3 px-4 font-semibold">Due Date</th>
                    <th className="py-3 px-4 font-semibold text-right">Circulation Desk</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E5E7EB]">
                  {libraryLoans.map((l) => (
                    <tr key={l.id} className="hover:bg-slate-50">
                      <td className="py-3 px-4 font-medium text-[#0D0D0E]">
                        {l.bookTitle}
                      </td>
                      <td className="py-3 px-4 font-mono text-[#667085]">
                        {l.shelfLocation}
                      </td>
                      <td className="py-3 px-4 text-[#0D0D0E]">
                        {l.userName}
                      </td>
                      <td className="py-3 px-4 font-mono text-[#667085]">
                        {l.dueDate}
                      </td>
                      <td className="py-3 px-4 text-right">
                        {l.status === 'Active' ? (
                          <button
                            type="button"
                            onClick={() => returnBook(l.id)}
                            className="px-3 py-1 bg-[#F5F6F8] hover:bg-slate-200 text-[#0D0D0E] font-medium rounded-md border border-[#E5E7EB]"
                          >
                            Mark Returned
                          </button>
                        ) : (
                          <span className="text-emerald-700 font-medium">Returned</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 5: Announcements Manager */}
        {activeTab === 'announcements' && (
          <div className="bg-white rounded-xl border border-[#E5E7EB] p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-bold text-[#0D0D0E]">
                Published Seminary Notices
              </h3>
              <button
                type="button"
                onClick={() => setNewAnnounceModal(true)}
                className="px-3.5 py-1.5 bg-[#0D0D0E] text-white text-xs font-semibold rounded-md"
              >
                + New Notice
              </button>
            </div>

            <div className="space-y-3">
              {announcements.map((ann) => (
                <div key={ann.id} className="p-4 rounded-lg border border-[#E5E7EB] bg-[#F5F6F8]/60 text-xs space-y-1">
                  <div className="flex items-center justify-between text-[11px] text-[#667085]">
                    <span className="font-semibold text-[#0D0D0E]">{ann.author} · {ann.category}</span>
                    <span className="font-mono">{ann.date}</span>
                  </div>
                  <h4 className="font-bold text-[#0D0D0E] text-sm">{ann.title}</h4>
                  <p className="text-slate-600 leading-relaxed">{ann.content}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 6: Enquiries Inbox */}
        {activeTab === 'enquiries' && (
          <div className="bg-white rounded-xl border border-[#E5E7EB] p-6 shadow-xs space-y-4">
            <h3 className="font-display text-lg font-bold text-[#0D0D0E]">
              Public Enquiries & Prospective Candidate Inquiries
            </h3>

            <div className="space-y-3">
              {enquiries.map((enq) => (
                <div key={enq.id} className="p-4 rounded-lg border border-[#E5E7EB] bg-[#F5F6F8]/60 text-xs space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-bold text-[#0D0D0E] text-sm">{enq.fullName}</span>
                      <span className="text-[#667085] ml-2">({enq.email})</span>
                    </div>
                    <span className="text-[10px] font-mono text-[#667085]">{enq.submittedAt}</span>
                  </div>
                  <div className="font-semibold text-[#0D0D0E]">{enq.subject}</div>
                  <p className="text-slate-700 leading-relaxed">{enq.message}</p>
                  <div className="pt-2 flex items-center justify-between border-t border-slate-200">
                    <span className="text-[11px] text-[#667085]">Category: {enq.category}</span>
                    {enq.status === 'New' ? (
                      <button
                        type="button"
                        onClick={() => markEnquiryReplied(enq.id)}
                        className="px-3 py-1 bg-[#0D0D0E] text-white rounded-md text-[11px] font-medium"
                      >
                        Mark as Replied
                      </button>
                    ) : (
                      <span className="text-emerald-700 font-semibold">Replied</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 7: Audit Logs */}
        {activeTab === 'audit' && (
          <div className="bg-white rounded-xl border border-[#E5E7EB] p-6 shadow-xs space-y-4">
            <h3 className="font-display text-lg font-bold text-[#0D0D0E]">
              System & Registry Audit Trail
            </h3>

            <div className="space-y-2.5">
              {auditLogs.map((log) => (
                <div key={log.id} className="p-3 rounded-lg border border-[#E5E7EB] bg-[#F5F6F8]/40 text-xs flex items-start justify-between">
                  <div className="space-y-0.5">
                    <div className="font-semibold text-[#0D0D0E]">{log.action}</div>
                    <div className="text-[11px] text-[#667085]">
                      Target: {log.target} · Executed by: {log.performedBy}
                    </div>
                    <div className="text-[11px] text-slate-700">{log.details}</div>
                  </div>
                  <span className="text-[10px] font-mono text-slate-500 shrink-0">
                    {log.timestamp}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Grant Offer & Assign Matriculation Modal */}
      <Modal
        isOpen={matricModalOpen}
        onClose={() => setMatricModalOpen(false)}
        title="Grant Admission Offer & Assign Matriculation Number"
        subtitle="Generates formal provisional admission letter and student ID"
        maxWidth="md"
      >
        <form onSubmit={handleConfirmMatriculation} className="space-y-4 text-xs text-[#0D0D0E]">
          <div>
            <label className="block font-medium mb-1">
              Official Matriculation Number Format *
            </label>
            <input
              type="text"
              required
              value={matricInput}
              onChange={(e) => setMatricInput(e.target.value)}
              placeholder="e.g. CRBEM/BTH/2026/042"
              className="w-full px-3 py-2.5 border border-[#E5E7EB] rounded-lg font-mono font-bold text-sm outline-none focus:border-[#FC8B0A]"
            />
            <p className="text-[11px] text-[#667085] mt-1">
              Follows CRBEM Seminary standard: Institution/Programme/Session/Serial
            </p>
          </div>

          <div className="pt-2 flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setMatricModalOpen(false)}
              className="px-4 py-2 text-slate-600 hover:text-slate-900"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-[#FC8B0A] hover:bg-[#E07702] text-white font-semibold rounded-lg transition-colors cursor-pointer"
            >
              Issue Offer & Matric Number
            </button>
          </div>
        </form>
      </Modal>

      {/* Candidate Dossier Inspection Modal */}
      {selectedApp && (
        <Modal
          isOpen={!!selectedApp}
          onClose={() => setSelectedApp(null)}
          title={`Candidate Dossier: ${selectedApp.fullName}`}
          subtitle={`Reference: ${selectedApp.applicationReference} · ${selectedApp.programmeName}`}
          maxWidth="2xl"
        >
          <div className="space-y-4 text-xs text-[#0D0D0E]">
            <div className="p-4 bg-[#F5F6F8] rounded-xl grid grid-cols-2 gap-3">
              <div>
                <span className="text-[#667085] block">Denomination:</span>
                <span className="font-semibold">{selectedApp.personalInfo.churchDenomination}</span>
              </div>
              <div>
                <span className="text-[#667085] block">Pastor Oversight:</span>
                <span className="font-semibold">{selectedApp.personalInfo.pastorName}</span>
              </div>
              <div>
                <span className="text-[#667085] block">Calling:</span>
                <span className="italic">{selectedApp.personalInfo.ministerialCalling}</span>
              </div>
              <div>
                <span className="text-[#667085] block">Current Status:</span>
                <StatusBadge status={selectedApp.status} />
              </div>
            </div>

            <div className="border-t border-[#E5E7EB] pt-3 flex justify-between items-center">
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    updateApplicationStatus(selectedApp.id, 'Interview Scheduled', 'Interview scheduled for Bible knowledge');
                    setSelectedApp(null);
                  }}
                  className="px-3 py-1.5 bg-blue-50 text-blue-800 rounded-md font-medium"
                >
                  Schedule Interview
                </button>
                <button
                  type="button"
                  onClick={() => {
                    handleOpenMatricModal(selectedApp);
                    setSelectedApp(null);
                  }}
                  className="px-3 py-1.5 bg-[#0D0D0E] text-white rounded-md font-medium"
                >
                  Issue Offer Letter
                </button>
              </div>

              <button
                type="button"
                onClick={() => setSelectedApp(null)}
                className="px-4 py-1.5 text-slate-600 hover:text-slate-900"
              >
                Close
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Publish Notice Modal */}
      <Modal
        isOpen={newAnnounceModal}
        onClose={() => setNewAnnounceModal(false)}
        title="Publish Official Academic Notice"
        subtitle="Will be displayed on Academic Home and Student Dashboard"
        maxWidth="lg"
      >
        <form onSubmit={handleCreateAnnouncement} className="space-y-4 text-xs text-[#0D0D0E]">
          <div>
            <label className="block font-medium mb-1">Notice Headline *</label>
            <input
              type="text"
              required
              value={announceTitle}
              onChange={(e) => setAnnounceTitle(e.target.value)}
              placeholder="e.g. Schedule of Biblical Language Oral Exams"
              className="w-full px-3 py-2 border border-[#E5E7EB] rounded-lg outline-none focus:border-[#FC8B0A]"
            />
          </div>

          <div>
            <label className="block font-medium mb-1">Priority</label>
            <select
              value={announcePriority}
              onChange={(e) => setAnnouncePriority(e.target.value as any)}
              className="w-full px-3 py-2 border border-[#E5E7EB] rounded-lg outline-none focus:border-[#FC8B0A]"
            >
              <option value="Normal">Normal</option>
              <option value="High">High</option>
              <option value="Urgent">Urgent</option>
            </select>
          </div>

          <div>
            <label className="block font-medium mb-1">Notice Directive Body *</label>
            <textarea
              required
              rows={4}
              value={announceContent}
              onChange={(e) => setAnnounceContent(e.target.value)}
              placeholder="State the institutional directive, deadline, and venue..."
              className="w-full p-3 border border-[#E5E7EB] rounded-lg outline-none focus:border-[#FC8B0A]"
            />
          </div>

          <div className="pt-2 flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setNewAnnounceModal(false)}
              className="px-4 py-2 text-slate-600 hover:text-slate-900"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-[#FC8B0A] hover:bg-[#E07702] text-white font-semibold rounded-lg transition-colors cursor-pointer"
            >
              Publish Notice
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
