/**
 * CRBEM Theological Seminary - Student Assignments Management
 * View pending, submitted, and graded theological coursework
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Student } from '../../types';
import { Breadcrumbs } from '../common/Breadcrumbs';
import { Modal } from '../common/Modal';
import { Clock, CheckCircle2, FileText, Upload, MessageSquare } from 'lucide-react';

export const StudentAssignmentsView: React.FC = () => {
  const { currentUser, assignments, submissions, submitAssignment, navigateTo } = useApp();
  const studentId = currentUser?.id || 'usr-student-1';

  const [activeModalAssignId, setActiveModalAssignId] = useState<string | null>(null);
  const [submissionText, setSubmissionText] = useState('');
  const [paperTitle, setPaperTitle] = useState('Exegetical_Essay_Submission.pdf');

  const selectedAssignment = assignments.find((a) => a.id === activeModalAssignId);

  const handleSubmitPaper = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeModalAssignId) return;

    submitAssignment(activeModalAssignId, submissionText, paperTitle);
    setActiveModalAssignId(null);
    setSubmissionText('');
  };

  return (
    <div className="py-10 bg-[#F5F6F8]">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <Breadcrumbs
          items={[
            { label: 'Seminary Home', view: 'public-home' },
            { label: 'Student Portal', view: 'student-portal' },
            { label: 'Theological Coursework & Assignments' }
          ]}
        />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#0D0D0E]">
              Assignments & Term Papers
            </h1>
            <p className="text-xs text-[#667085] mt-1 font-sans">
              Expository papers, language parsing drills, and research dossiers
            </p>
          </div>
        </div>

        {/* Assignments Grid */}
        <div className="space-y-4">
          {assignments.map((assign) => {
            const submission = submissions.find(
              (s) => s.assignmentId === assign.id && s.studentId === studentId
            );

            return (
              <div
                key={assign.id}
                className="bg-white rounded-xl border border-[#E5E7EB] p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6"
              >
                <div className="space-y-2 max-w-2xl">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-[#FC8B0A]">
                      {assign.courseCode}
                    </span>
                    <span className="text-slate-300">·</span>
                    <h3 className="font-display text-base font-bold text-[#0D0D0E]">
                      {assign.title}
                    </h3>
                  </div>

                  <p className="text-xs text-[#0D0D0E]/80 leading-relaxed font-sans">
                    {assign.instructions}
                  </p>

                  <div className="flex flex-wrap items-center gap-3 text-[11px] text-[#667085] pt-1">
                    <div className="flex items-center gap-1 text-rose-700">
                      <Clock className="w-3.5 h-3.5" />
                      <span>Due: {assign.dueDate}</span>
                    </div>
                    <span>·</span>
                    <span>Max Points: {assign.maxScore}</span>
                  </div>
                </div>

                {/* Submission State / Action */}
                <div className="shrink-0 flex items-center gap-3">
                  {submission ? (
                    <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs space-y-1 text-right">
                      <div className="flex items-center justify-end gap-1.5 font-bold text-emerald-800">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>{submission.status}</span>
                      </div>
                      <div className="text-[10px] text-emerald-700 font-mono">
                        {submission.submittedAt}
                      </div>
                      {submission.score !== undefined && (
                        <div className="font-bold text-emerald-900 pt-1">
                          Grade: {submission.score} / {assign.maxScore}
                        </div>
                      )}
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setActiveModalAssignId(assign.id)}
                      className="px-5 py-2.5 bg-[#0D0D0E] hover:bg-[#0D1524] text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 cursor-pointer shadow-xs"
                    >
                      <Upload className="w-3.5 h-3.5 text-[#FC8B0A]" />
                      <span>Submit Paper</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Submission Modal */}
      {selectedAssignment && (
        <Modal
          isOpen={!!activeModalAssignId}
          onClose={() => setActiveModalAssignId(null)}
          title={`Submit Assignment: ${selectedAssignment.courseCode}`}
          subtitle={selectedAssignment.title}
          maxWidth="lg"
        >
          <form onSubmit={handleSubmitPaper} className="space-y-4 text-xs text-[#0D0D0E]">
            <div>
              <label className="block font-medium mb-1">
                Executive Abstract or Answers
              </label>
              <textarea
                required
                rows={5}
                value={submissionText}
                onChange={(e) => setSubmissionText(e.target.value)}
                placeholder="Enter your scholarly thesis statement, exegetical response, or research notes..."
                className="w-full p-3 bg-white border border-[#E5E7EB] rounded-lg outline-none focus:border-[#FC8B0A]"
              />
            </div>

            <div>
              <label className="block font-medium mb-1">
                Attachment File Name
              </label>
              <input
                type="text"
                value={paperTitle}
                onChange={(e) => setPaperTitle(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-[#E5E7EB] rounded-lg outline-none focus:border-[#FC8B0A]"
              />
            </div>

            <div className="pt-2 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setActiveModalAssignId(null)}
                className="px-4 py-2 text-slate-600 hover:text-slate-900"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 bg-[#FC8B0A] hover:bg-[#E07702] text-white font-semibold rounded-lg transition-colors cursor-pointer"
              >
                Upload & Submit
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
};

export const AcademicCalendarView: React.FC = () => {
  return (
    <div className="py-10 bg-[#F5F6F8]">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <Breadcrumbs
          items={[
            { label: 'Seminary Home', view: 'public-home' },
            { label: 'Academic Calendar 2026/2027' }
          ]}
        />

        <div>
          <h1 className="font-display text-3xl font-bold text-[#0D0D0E]">
            2026/2027 Academic Session Calendar
          </h1>
          <p className="text-xs text-[#667085] mt-1 font-sans">
            Official calendar approved by the Seminary Senate
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* First Semester */}
          <div className="bg-white rounded-xl border border-[#E5E7EB] p-7 shadow-xs space-y-4">
            <div className="pb-3 border-b border-[#E5E7EB]">
              <span className="text-[10px] font-medium text-[#FC8B0A] font-bold">
                Session Part I
              </span>
              <h2 className="font-display text-xl font-bold text-[#0D0D0E]">
                First Semester (October 2026 – February 2027)
              </h2>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-[#F5F6F8] rounded-lg flex items-center justify-between">
                <span className="font-medium text-[#0D0D0E]">Lectures Commence</span>
                <span className="font-mono text-slate-700">October 19, 2026</span>
              </div>
              <div className="p-3 bg-[#F5F6F8] rounded-lg flex items-center justify-between">
                <span className="font-medium text-[#0D0D0E]">41st Matriculation Ceremony</span>
                <span className="font-mono text-[#FC8B0A] font-bold">October 24, 2026</span>
              </div>
              <div className="p-3 bg-[#F5F6F8] rounded-lg flex items-center justify-between">
                <span className="font-medium text-[#0D0D0E]">Course Registration Deadline</span>
                <span className="font-mono text-slate-700">November 06, 2026</span>
              </div>
              <div className="p-3 bg-[#F5F6F8] rounded-lg flex items-center justify-between">
                <span className="font-medium text-[#0D0D0E]">Spiritual Emphasis & Prayer Week</span>
                <span className="font-mono text-slate-700">November 23 – 27, 2026</span>
              </div>
              <div className="p-3 bg-[#F5F6F8] rounded-lg flex items-center justify-between">
                <span className="font-medium text-[#0D0D0E]">First Semester Final Examinations</span>
                <span className="font-mono text-rose-700 font-bold">Feb 15 – 27, 2027</span>
              </div>
            </div>
          </div>

          {/* Second Semester */}
          <div className="bg-white rounded-xl border border-[#E5E7EB] p-7 shadow-xs space-y-4">
            <div className="pb-3 border-b border-[#E5E7EB]">
              <span className="text-[10px] font-medium text-[#FC8B0A] font-bold">
                Session Part II
              </span>
              <h2 className="font-display text-xl font-bold text-[#0D0D0E]">
                Second Semester (March 2027 – July 2027)
              </h2>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-[#F5F6F8] rounded-lg flex items-center justify-between">
                <span className="font-medium text-[#0D0D0E]">Second Semester Lectures Begin</span>
                <span className="font-mono text-slate-700">March 15, 2027</span>
              </div>
              <div className="p-3 bg-[#F5F6F8] rounded-lg flex items-center justify-between">
                <span className="font-medium text-[#0D0D0E]">Annual Expository Preaching Practicum</span>
                <span className="font-mono text-slate-700">May 10 – 14, 2027</span>
              </div>
              <div className="p-3 bg-[#F5F6F8] rounded-lg flex items-center justify-between">
                <span className="font-medium text-[#0D0D0E]">Second Semester Final Examinations</span>
                <span className="font-mono text-slate-700">July 10 – 24, 2027</span>
              </div>
              <div className="p-3 bg-[#F5F6F8] rounded-lg flex items-center justify-between">
                <span className="font-medium text-[#0D0D0E]">Annual Convocation & Graduation</span>
                <span className="font-mono text-emerald-700 font-bold">August 07, 2027</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export const StudentProfileView: React.FC = () => {
  const { currentUser, students } = useApp();
  const student = (currentUser && currentUser.role === 'Student' ? currentUser as Student : students[0]) || students[0];

  return (
    <div className="py-10 bg-[#F5F6F8]">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <Breadcrumbs
          items={[
            { label: 'Seminary Home', view: 'public-home' },
            { label: 'Student Portal', view: 'student-portal' },
            { label: 'Student Profile Record' }
          ]}
        />

        <div className="bg-white rounded-xl border border-[#E5E7EB] p-8 shadow-xs max-w-3xl space-y-6">
          <div className="pb-4 border-b border-[#E5E7EB] flex items-center justify-between">
            <div>
              <h1 className="font-display text-2xl font-bold text-[#0D0D0E]">
                Student Identity Profile
              </h1>
              <p className="text-xs text-[#667085] mt-0.5">
                Official Matriculated Dossier
              </p>
            </div>
            <span className="text-xs font-mono font-bold text-[#FC8B0A]">
              {student.matriculationNumber}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <span className="text-[#667085] block">Full Name:</span>
              <span className="font-semibold text-[#0D0D0E] text-sm">{student.fullName}</span>
            </div>
            <div>
              <span className="text-[#667085] block">Institutional Email:</span>
              <span className="font-mono text-[#0D0D0E]">{student.email}</span>
            </div>
            <div>
              <span className="text-[#667085] block">Programme:</span>
              <span className="font-medium text-[#0D0D0E]">{student.programmeName}</span>
            </div>
            <div>
              <span className="text-[#667085] block">Study Mode:</span>
              <span className="text-[#0D0D0E]">{student.studyMode}</span>
            </div>
            <div>
              <span className="text-[#667085] block">Current Level:</span>
              <span className="text-[#0D0D0E]">{student.level}</span>
            </div>
            <div>
              <span className="text-[#667085] block">Faculty Advisor:</span>
              <span className="font-semibold text-[#0D0D0E]">{student.facultyAdvisor}</span>
            </div>
            <div>
              <span className="text-[#667085] block">Enrollment Date:</span>
              <span className="text-[#0D0D0E]">{student.enrollmentDate}</span>
            </div>
            <div>
              <span className="text-[#667085] block">Phone Contact:</span>
              <span className="text-[#0D0D0E]">{student.phoneNumber || '+234 803 456 7890'}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
