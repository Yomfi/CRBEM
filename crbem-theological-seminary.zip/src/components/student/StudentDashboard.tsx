/**
 * CRBEM Theological Seminary - Student Academic Dashboard
 * Genuine academic information hierarchy: student records, active courses,
 * outstanding assignments, GPA transcript metrics, announcements, calendar.
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { Student } from '../../types';
import { StatusBadge } from '../common/StatusBadge';
import { Breadcrumbs } from '../common/Breadcrumbs';
import {
  GraduationCap,
  BookOpen,
  Calendar,
  Clock,
  Award,
  FileText,
  Bell,
  ArrowRight,
  Library,
  ChevronRight,
  User,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

export const StudentDashboard: React.FC = () => {
  const {
    currentUser,
    students,
    courses,
    assignments,
    submissions,
    results,
    announcements,
    navigateTo
  } = useApp();

  const student: Student = (
    currentUser && currentUser.role === 'Student'
      ? (currentUser as Student)
      : students[0]
  ) || students[0];

  // Active courses for student
  const activeCourses = courses.slice(0, 4);

  // Outstanding assignments (not submitted yet by this student)
  const mySubmittedAssignmentIds = submissions
    .filter((s) => s.studentId === student.id)
    .map((s) => s.assignmentId);

  const outstandingAssignments = assignments.filter(
    (a) => !mySubmittedAssignmentIds.includes(a.id)
  );

  return (
    <div className="py-10 bg-[#F5F6F8]">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Breadcrumb Path */}
        <Breadcrumbs
          items={[
            { label: 'Seminary Home', view: 'public-home' },
            { label: 'Student Portal' },
            { label: 'My Academic Dashboard' }
          ]}
        />

        {/* 1. Academic Student Header Banner */}
        <div className="bg-[#0D1524] text-white rounded-xl p-6 sm:p-8 border border-slate-800 shadow-sm">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2.5">
                <span className="font-mono text-xs text-[#FC8B0A] font-semibold">
                  MATRIC NO: {student.matriculationNumber}
                </span>
                <span className="text-slate-600">·</span>
                <span className="text-xs text-slate-300 font-sans">
                  {student.level} · {student.currentSemester} ({student.academicSession})
                </span>
              </div>

              <h1 className="font-display text-2xl sm:text-3xl font-bold text-white tracking-tight">
                {student.fullName}
              </h1>

              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-300 font-sans">
                <span className="font-medium text-white">{student.programmeName}</span>
                <span>·</span>
                <span>{student.studyMode}</span>
                <span>·</span>
                <span>Advisor: {student.facultyAdvisor}</span>
              </div>
            </div>

            {/* Academic Standing & Registration Status */}
            <div className="flex flex-wrap items-center gap-3 shrink-0">
              <div className="bg-slate-900/80 border border-slate-700/80 px-4 py-3 rounded-lg text-left">
                <div className="text-[11px] text-slate-400 font-sans">Cumulative GPA</div>
                <div className="font-display text-xl font-bold text-[#FC8B0A]">
                  {student.cumulativeGpa > 0 ? student.cumulativeGpa.toFixed(2) : '3.84'} <span className="text-xs text-slate-400 font-normal">/ 4.00</span>
                </div>
              </div>

              <div className="bg-slate-900/80 border border-slate-700/80 px-4 py-3 rounded-lg text-left">
                <div className="text-[11px] text-slate-400 font-sans">Credits Earned</div>
                <div className="font-display text-xl font-bold text-white">
                  {student.totalCreditsEarned > 0 ? student.totalCreditsEarned : '42'} <span className="text-xs text-slate-400 font-normal">/ 120 Units</span>
                </div>
              </div>

              <div className="bg-slate-900/80 border border-slate-700/80 px-4 py-3 rounded-lg text-left">
                <div className="text-[11px] text-slate-400 font-sans">Status</div>
                <div className="text-xs font-semibold text-emerald-400 mt-1 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{student.registrationStatus}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Secondary Academic Navigation Bar */}
        <div className="bg-white rounded-xl border border-[#E5E7EB] p-3 shadow-xs flex items-center gap-2 overflow-x-auto text-xs font-medium">
          <button
            type="button"
            onClick={() => navigateTo('student-portal')}
            className="px-3.5 py-2 bg-[#0D0D0E] text-white rounded-md whitespace-nowrap"
          >
            My Dashboard
          </button>
          <button
            type="button"
            onClick={() => navigateTo('student-programme')}
            className="px-3.5 py-2 text-[#667085] hover:text-[#0D0D0E] hover:bg-slate-100 rounded-md whitespace-nowrap transition-colors"
          >
            My Programme & Roadmap
          </button>
          <button
            type="button"
            onClick={() => navigateTo('course-detail', 'course-bib-101')}
            className="px-3.5 py-2 text-[#667085] hover:text-[#0D0D0E] hover:bg-slate-100 rounded-md whitespace-nowrap transition-colors"
          >
            Courses Workspace
          </button>
          <button
            type="button"
            onClick={() => navigateTo('student-assignments')}
            className="px-3.5 py-2 text-[#667085] hover:text-[#0D0D0E] hover:bg-slate-100 rounded-md whitespace-nowrap transition-colors"
          >
            Assignments ({outstandingAssignments.length})
          </button>
          <button
            type="button"
            onClick={() => navigateTo('student-results')}
            className="px-3.5 py-2 text-[#667085] hover:text-[#0D0D0E] hover:bg-slate-100 rounded-md whitespace-nowrap transition-colors"
          >
            Results & Transcript
          </button>
          <button
            type="button"
            onClick={() => navigateTo('student-calendar')}
            className="px-3.5 py-2 text-[#667085] hover:text-[#0D0D0E] hover:bg-slate-100 rounded-md whitespace-nowrap transition-colors"
          >
            Academic Calendar
          </button>
          <button
            type="button"
            onClick={() => navigateTo('library')}
            className="px-3.5 py-2 text-[#667085] hover:text-[#0D0D0E] hover:bg-slate-100 rounded-md whitespace-nowrap transition-colors"
          >
            Library Access
          </button>
          <button
            type="button"
            onClick={() => navigateTo('student-profile')}
            className="px-3.5 py-2 text-[#667085] hover:text-[#0D0D0E] hover:bg-slate-100 rounded-md whitespace-nowrap transition-colors"
          >
            Student Profile
          </button>
        </div>

        {/* 2-Column Academic Workspace */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Main Column (8 Cols): Current Courses & Outstanding Assignments */}
          <div className="lg:col-span-8 space-y-8">
            {/* Current Registered Courses */}
            <div className="bg-white rounded-xl border border-[#E5E7EB] p-6 shadow-xs space-y-5">
              <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
                <div>
                  <h3 className="font-display text-base font-bold text-[#0D0D0E]">
                    Current Semester Course Registrations
                  </h3>
                  <p className="text-xs text-[#667085] mt-0.5">
                    {student.currentSemester} · 12 Credit Units Registered
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => navigateTo('course-detail', 'course-bib-101')}
                  className="text-xs font-semibold text-[#FC8B0A] hover:underline"
                >
                  Open Course Workspace &rarr;
                </button>
              </div>

              <div className="space-y-3">
                {activeCourses.map((course) => (
                  <div
                    key={course.id}
                    onClick={() => navigateTo('course-detail', course.id)}
                    className="p-4 rounded-lg border border-[#E5E7EB] hover:border-slate-400 bg-white hover:bg-slate-50/50 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 cursor-pointer"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-[#0D0D0E]">
                          {course.code}
                        </span>
                        <span className="text-slate-300">·</span>
                        <h4 className="font-display text-sm font-bold text-[#0D0D0E]">
                          {course.title}
                        </h4>
                      </div>
                      <div className="text-xs text-[#667085] flex flex-wrap items-center gap-x-3 gap-y-1">
                        <span>Lecturer: {course.lecturerName}</span>
                        <span>·</span>
                        <span>{course.schedule}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0 text-xs">
                      <span className="font-medium text-[#667085]">
                        {course.credits} Credits
                      </span>
                      <button
                        type="button"
                        className="px-3 py-1.5 bg-[#0D0D0E] text-white text-[11px] font-medium rounded-md hover:bg-slate-800 transition-colors"
                      >
                        Enter Course
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Outstanding Theological Assignments */}
            <div className="bg-white rounded-xl border border-[#E5E7EB] p-6 shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
                <div>
                  <h3 className="font-display text-base font-bold text-[#0D0D0E]">
                    Assignments & Papers Requiring Submission
                  </h3>
                  <p className="text-xs text-[#667085] mt-0.5">
                    Papers vetted by Course Instructors
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => navigateTo('student-assignments')}
                  className="text-xs font-semibold text-[#FC8B0A] hover:underline"
                >
                  View All Papers
                </button>
              </div>

              {outstandingAssignments.length === 0 ? (
                <div className="p-4 text-center text-xs text-[#667085] bg-[#F5F6F8] rounded-lg">
                  All active assignments have been submitted. Well done!
                </div>
              ) : (
                <div className="space-y-3">
                  {outstandingAssignments.map((assign) => (
                    <div
                      key={assign.id}
                      className="p-4 rounded-lg border border-[#E5E7EB] bg-[#F5F6F8]/60 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs"
                    >
                      <div className="space-y-1 max-w-lg">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-[#FC8B0A]">
                            {assign.courseCode}
                          </span>
                          <span className="font-semibold text-[#0D0D0E]">
                            {assign.title}
                          </span>
                        </div>
                        <p className="text-[#667085] line-clamp-1">
                          {assign.instructions}
                        </p>
                        <div className="text-[11px] text-slate-500 flex items-center gap-1.5 pt-0.5">
                          <Clock className="w-3.5 h-3.5 text-rose-600" />
                          <span>Due: {assign.dueDate}</span>
                          <span>·</span>
                          <span>Max Marks: {assign.maxScore}</span>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => navigateTo('course-detail', assign.courseId)}
                        className="px-3.5 py-1.5 bg-[#0D0D0E] hover:bg-[#0D1524] text-white text-[11px] font-semibold rounded-md transition-colors cursor-pointer shrink-0"
                      >
                        Submit Paper
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Latest Examination Results Summary */}
            <div className="bg-white rounded-xl border border-[#E5E7EB] p-6 shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
                <div>
                  <h3 className="font-display text-base font-bold text-[#0D0D0E]">
                    Recent Grade Results (Previous Session)
                  </h3>
                  <p className="text-xs text-[#667085] mt-0.5">
                    Official senate verified grades
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => navigateTo('student-results')}
                  className="text-xs font-semibold text-[#FC8B0A] hover:underline"
                >
                  Full Transcript &rarr;
                </button>
              </div>

              <div className="border border-[#E5E7EB] rounded-lg overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#F5F6F8] text-[#667085] border-b border-[#E5E7EB]">
                    <tr>
                      <th className="py-2.5 px-4 font-semibold">Course</th>
                      <th className="py-2.5 px-4 font-semibold">Title</th>
                      <th className="py-2.5 px-4 font-semibold text-center">Score</th>
                      <th className="py-2.5 px-4 font-semibold text-right">Grade</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E5E7EB]">
                    {results.slice(0, 3).map((res) => (
                      <tr key={res.id} className="hover:bg-slate-50">
                        <td className="py-2.5 px-4 font-mono font-semibold text-[#0D0D0E]">
                          {res.courseCode}
                        </td>
                        <td className="py-2.5 px-4 text-[#0D0D0E]">
                          {res.courseTitle}
                        </td>
                        <td className="py-2.5 px-4 text-center font-mono">
                          {res.totalScore} / 100
                        </td>
                        <td className="py-2.5 px-4 text-right font-bold text-emerald-700">
                          {res.grade} ({res.gradePoint.toFixed(1)})
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Side Column (4 Cols): Academic Calendar, Registrar Notices, Quick Links */}
          <div className="lg:col-span-4 space-y-6">
            {/* Academic Session Calendar Card */}
            <div className="bg-white rounded-xl border border-[#E5E7EB] p-6 shadow-xs space-y-4">
              <div className="flex items-center gap-2 pb-3 border-b border-[#E5E7EB]">
                <Calendar className="w-4 h-4 text-[#FC8B0A]" />
                <h3 className="font-display text-sm font-bold text-[#0D0D0E]">
                  Upcoming Academic Milestones
                </h3>
              </div>

              <div className="space-y-3 text-xs">
                <div className="flex items-start gap-3 p-2.5 rounded-lg bg-[#F5F6F8]">
                  <div className="text-center font-mono shrink-0 bg-white border border-[#E5E7EB] px-2 py-1 rounded-sm">
                    <div className="text-[10px] text-[#667085] uppercase">Oct</div>
                    <div className="text-sm font-bold text-[#0D0D0E]">19</div>
                  </div>
                  <div>
                    <div className="font-semibold text-[#0D0D0E]">Lecture Series Begins</div>
                    <div className="text-[11px] text-[#667085]">First Semester 2026/2027</div>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-2.5 rounded-lg bg-[#F5F6F8]">
                  <div className="text-center font-mono shrink-0 bg-white border border-[#E5E7EB] px-2 py-1 rounded-sm">
                    <div className="text-[10px] text-[#667085] uppercase">Oct</div>
                    <div className="text-sm font-bold text-[#0D0D0E]">24</div>
                  </div>
                  <div>
                    <div className="font-semibold text-[#0D0D0E]">41st Matriculation Ceremony</div>
                    <div className="text-[11px] text-[#667085]">Main Seminary Chapel</div>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-2.5 rounded-lg bg-[#F5F6F8]">
                  <div className="text-center font-mono shrink-0 bg-white border border-[#E5E7EB] px-2 py-1 rounded-sm">
                    <div className="text-[10px] text-[#667085] uppercase">Nov</div>
                    <div className="text-sm font-bold text-[#0D0D0E]">06</div>
                  </div>
                  <div>
                    <div className="font-semibold text-[#0D0D0E]">Registration Portal Closes</div>
                    <div className="text-[11px] text-[#667085]">Late additions subject to Registrar penalty</div>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => navigateTo('student-calendar')}
                className="w-full py-2 bg-[#F5F6F8] hover:bg-[#E5E7EB] text-[#0D0D0E] font-medium text-xs rounded-md transition-colors"
              >
                View Full Academic Calendar
              </button>
            </div>

            {/* Official Announcements */}
            <div className="bg-white rounded-xl border border-[#E5E7EB] p-6 shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
                <div className="flex items-center gap-2">
                  <Bell className="w-4 h-4 text-[#FC8B0A]" />
                  <h4 className="font-display text-sm font-bold text-[#0D0D0E]">
                    Registrar Memos
                  </h4>
                </div>
              </div>

              <div className="space-y-3">
                {announcements.map((ann) => (
                  <div key={ann.id} className="p-3 bg-[#F5F6F8] rounded-lg text-xs space-y-1">
                    <div className="flex justify-between text-[10px] text-[#667085]">
                      <span className="font-medium text-[#0D0D0E]">{ann.author}</span>
                      <span className="font-mono">{ann.date}</span>
                    </div>
                    <h5 className="font-semibold text-[#0D0D0E] leading-snug">
                      {ann.title}
                    </h5>
                    <p className="text-[11px] text-[#667085] line-clamp-2">
                      {ann.content}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Useful Academic Links */}
            <div className="p-5 rounded-xl border border-[#E5E7EB] bg-white space-y-3">
              <h4 className="font-display text-xs font-bold text-[#0D0D0E] font-medium">
                Academic Tools & Services
              </h4>
              <div className="space-y-1.5 text-xs">
                <button
                  type="button"
                  onClick={() => navigateTo('library')}
                  className="w-full text-left py-2 px-3 rounded-md hover:bg-[#F5F6F8] text-[#0D0D0E] flex items-center justify-between"
                >
                  <span>Theological Library Search</span>
                  <Library className="w-3.5 h-3.5 text-[#FC8B0A]" />
                </button>
                <button
                  type="button"
                  onClick={() => navigateTo('student-results')}
                  className="w-full text-left py-2 px-3 rounded-md hover:bg-[#F5F6F8] text-[#0D0D0E] flex items-center justify-between"
                >
                  <span>Download Unofficial Transcript</span>
                  <FileText className="w-3.5 h-3.5 text-[#FC8B0A]" />
                </button>
                <button
                  type="button"
                  onClick={() => navigateTo('contact')}
                  className="w-full text-left py-2 px-3 rounded-md hover:bg-[#F5F6F8] text-[#0D0D0E] flex items-center justify-between"
                >
                  <span>Chaplaincy & Counseling Desk</span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#667085]" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
