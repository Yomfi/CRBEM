/**
 * CRBEM Theological Seminary - Student Degree Roadmap & Transcript Views
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { Student } from '../../types';
import { Breadcrumbs } from '../common/Breadcrumbs';
import { CheckCircle2, Clock, BookOpen, Award, Printer, Download, FileText } from 'lucide-react';

export const MyProgrammeView: React.FC = () => {
  const { currentUser, students, programmes, navigateTo } = useApp();
  const student = (currentUser && currentUser.role === 'Student' ? currentUser as Student : students[0]) || students[0];
  const programme = programmes.find((p) => p.id === student.programmeId) || programmes[2]; // B.Th.

  return (
    <div className="py-10 bg-[#F5F6F8]">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <Breadcrumbs
          items={[
            { label: 'Seminary Home', view: 'public-home' },
            { label: 'Student Portal', view: 'student-portal' },
            { label: 'My Programme & Degree Roadmap' }
          ]}
        />

        <div className="bg-[#0D1524] text-white rounded-xl p-8 border border-slate-800">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-2">
              <span className="text-xs font-medium text-[#FC8B0A] font-semibold">
                Degree Progression Tracker
              </span>
              <h1 className="font-display text-3xl font-bold text-white">
                {programme.title} ({programme.code})
              </h1>
              <p className="text-xs text-slate-300">
                Matriculation No: {student.matriculationNumber} · {student.studyMode} · Academic Level: {student.level}
              </p>
            </div>

            <div className="flex items-center gap-4 bg-slate-900 border border-slate-800 p-4 rounded-xl">
              <div>
                <div className="text-[11px] text-slate-400">Total Credits Required</div>
                <div className="font-display text-2xl font-bold text-white">
                  {programme.creditsRequired} Units
                </div>
              </div>
              <div className="border-l border-slate-700 pl-4">
                <div className="text-[11px] text-slate-400">Credits Completed</div>
                <div className="font-display text-2xl font-bold text-[#FC8B0A]">
                  42 Units
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Curriculum Semesters */}
        <div className="space-y-6">
          <h2 className="font-display text-xl font-bold text-[#0D0D0E]">
            Degree Syllabus & Course Roadmap
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {programme.curriculum.map((sem, sIdx) => (
              <div key={sIdx} className="bg-white rounded-xl border border-[#E5E7EB] p-6 shadow-xs">
                <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB] mb-4">
                  <h3 className="font-display text-sm font-bold text-[#0D0D0E]">
                    {sem.semester}
                  </h3>
                  <span className="text-xs text-[#667085]">
                    {sem.courses.reduce((acc, c) => acc + c.credits, 0)} Units
                  </span>
                </div>

                <div className="space-y-2.5">
                  {sem.courses.map((c, cIdx) => (
                    <div
                      key={cIdx}
                      className="p-3 rounded-lg border border-[#E5E7EB] bg-[#F5F6F8]/50 flex items-center justify-between text-xs"
                    >
                      <div>
                        <div className="font-mono font-bold text-[#0D0D0E]">
                          {c.code}
                        </div>
                        <div className="text-[#0D0D0E] font-medium mt-0.5">
                          {c.title}
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-[#667085]">{c.credits} Units</span>
                        <div className="text-[10px] text-emerald-700 font-medium">
                          {sIdx === 0 ? 'Passed (A)' : 'Registered'}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export const ResultsTranscriptView: React.FC = () => {
  const { currentUser, students, results, addToast } = useApp();
  const student = (currentUser && currentUser.role === 'Student' ? currentUser as Student : students[0]) || students[0];

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    addToast('Transcript Generated', 'Official PDF statement dispatched to print queue.', 'success');
  };

  return (
    <div className="py-10 bg-[#F5F6F8]">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <Breadcrumbs
          items={[
            { label: 'Seminary Home', view: 'public-home' },
            { label: 'Student Portal', view: 'student-portal' },
            { label: 'Official Academic Results & Transcript' }
          ]}
        />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#0D0D0E]">
              Academic Transcript Record
            </h1>
            <p className="text-xs text-[#667085] mt-1 font-sans">
              Cumulative record certified by the Office of the Registrar
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrint}
              className="px-4 py-2 bg-white border border-[#E5E7EB] hover:bg-slate-50 text-xs font-semibold rounded-lg text-[#0D0D0E] flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Transcript</span>
            </button>
            <button
              type="button"
              onClick={handleDownload}
              className="px-4 py-2 bg-[#0D0D0E] hover:bg-[#0D1524] text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-[#FC8B0A]" />
              <span>Download PDF Record</span>
            </button>
          </div>
        </div>

        {/* Formal Institutional Transcript Sheet */}
        <div className="bg-white border border-[#E5E7EB] rounded-xl p-8 sm:p-10 shadow-sm space-y-8 max-w-4xl mx-auto print:shadow-none print:border-none">
          {/* Header */}
          <div className="text-center pb-6 border-b border-[#E5E7EB] space-y-1">
            <div className="font-display text-lg font-bold text-[#0D0D0E] tracking-tight">
              CHRIST REDEMPTION BIBLE EVANGELICAL MISSION THEOLOGICAL SEMINARY
            </div>
            <div className="text-xs font-medium text-[#667085]">
              Office of Academic Records & Registrar Directorate
            </div>
            <div className="text-[11px] font-mono text-[#FC8B0A]">
              UNOFFICIAL STUDENT ACADEMIC TRANSCRIPT
            </div>
          </div>

          {/* Student Dossier Table */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 bg-[#F5F6F8] rounded-lg text-xs">
            <div>
              <span className="text-[#667085] block">Student Name:</span>
              <span className="font-bold text-[#0D0D0E]">{student.fullName}</span>
            </div>
            <div>
              <span className="text-[#667085] block">Matriculation No:</span>
              <span className="font-mono font-bold text-[#0D0D0E]">{student.matriculationNumber}</span>
            </div>
            <div>
              <span className="text-[#667085] block">Programme:</span>
              <span className="font-medium text-[#0D0D0E]">{student.programmeName}</span>
            </div>
            <div>
              <span className="text-[#667085] block">Cumulative GPA:</span>
              <span className="font-bold text-[#FC8B0A]">3.84 / 4.00</span>
            </div>
          </div>

          {/* Results Table */}
          <div className="border border-[#E5E7EB] rounded-lg overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#F5F6F8] text-[#667085] border-b border-[#E5E7EB]">
                <tr>
                  <th className="py-3 px-4 font-semibold">Course Code</th>
                  <th className="py-3 px-4 font-semibold">Course Title</th>
                  <th className="py-3 px-4 font-semibold text-center">Units</th>
                  <th className="py-3 px-4 font-semibold text-center">Score (100)</th>
                  <th className="py-3 px-4 font-semibold text-center">Grade</th>
                  <th className="py-3 px-4 font-semibold text-right">Points</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E5E7EB]">
                {results.map((res) => (
                  <tr key={res.id} className="hover:bg-slate-50">
                    <td className="py-3 px-4 font-mono font-bold text-[#0D0D0E]">
                      {res.courseCode}
                    </td>
                    <td className="py-3 px-4 text-[#0D0D0E] font-medium">
                      {res.courseTitle}
                    </td>
                    <td className="py-3 px-4 text-center text-[#667085]">
                      {res.credits}
                    </td>
                    <td className="py-3 px-4 text-center font-mono">
                      {res.totalScore}
                    </td>
                    <td className="py-3 px-4 text-center font-bold text-emerald-700">
                      {res.grade}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-semibold">
                      {(res.gradePoint * res.credits).toFixed(1)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="pt-4 border-t border-[#E5E7EB] flex items-center justify-between text-xs text-[#667085]">
            <div>Grading Standard: A = 4.0 (70–100%), B = 3.0 (60–69%), C = 2.0 (50–59%)</div>
            <div className="font-medium text-[#0D0D0E]">Status: Good Academic Standing</div>
          </div>
        </div>
      </div>
    </div>
  );
};
