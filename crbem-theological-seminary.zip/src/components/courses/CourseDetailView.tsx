/**
 * CRBEM Theological Seminary - Academic Course Detail Workspace
 * Calm, highly readable, optimized for long theological text, weekly modules,
 * downloadable resources, and assignment submissions.
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Course } from '../../types';
import { Breadcrumbs } from '../common/Breadcrumbs';
import { Modal } from '../common/Modal';
import {
  BookOpen,
  User,
  Clock,
  MapPin,
  Download,
  FileText,
  Calendar,
  CheckCircle2,
  Upload,
  MessageSquare,
  HelpCircle,
  ExternalLink
} from 'lucide-react';

export const CourseDetailView: React.FC = () => {
  const {
    selectedCourseId,
    courses,
    assignments,
    submissions,
    submitAssignment,
    navigateTo,
    addToast
  } = useApp();

  const course: Course =
    courses.find((c) => c.id === selectedCourseId) || courses[0];

  const courseAssignments = assignments.filter((a) => a.courseId === course.id);

  const [activeTab, setActiveTab] = useState<'modules' | 'syllabus' | 'assignments' | 'resources'>('modules');
  const [submissionModalAssignId, setSubmissionModalAssignId] = useState<string | null>(null);
  const [submissionText, setSubmissionText] = useState('');
  const [attachmentName, setAttachmentName] = useState('Hermeneutics_Paper.pdf');

  const selectedAssign = assignments.find((a) => a.id === submissionModalAssignId);

  const handleDownloadResource = (resTitle: string) => {
    addToast('Download Initiated', `Downloaded: ${resTitle}`, 'info');
  };

  const handleModalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!submissionModalAssignId) return;
    submitAssignment(submissionModalAssignId, submissionText, attachmentName);
    setSubmissionModalAssignId(null);
    setSubmissionText('');
  };

  return (
    <div className="py-10 bg-[#F5F6F8]">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <Breadcrumbs
          items={[
            { label: 'Seminary Home', view: 'public-home' },
            { label: 'Student Portal', view: 'student-portal' },
            { label: `${course.code}: ${course.title}` }
          ]}
        />

        {/* Calm Academic Course Header */}
        <div className="bg-[#0D1524] text-white rounded-xl p-8 border border-slate-800 shadow-sm space-y-4">
          <div className="flex flex-wrap items-center gap-3 text-xs text-slate-300 font-sans">
            <span className="font-mono text-[#FC8B0A] font-bold">{course.code}</span>
            <span>·</span>
            <span>{course.level}</span>
            <span>·</span>
            <span>{course.semester}</span>
            <span>·</span>
            <span>{course.credits} Credit Units</span>
          </div>

          <h1 className="font-display text-2xl sm:text-3xl lg:text-4xl font-bold text-white tracking-tight">
            {course.title}
          </h1>

          <p className="text-xs sm:text-sm text-slate-300 max-w-3xl leading-relaxed font-light">
            {course.description}
          </p>

          <div className="pt-4 border-t border-slate-800 flex flex-wrap items-center gap-6 text-xs text-slate-300">
            <div className="flex items-center gap-2">
              <User className="w-4 h-4 text-[#FC8B0A]" />
              <span>Lecturer: <strong className="text-white font-medium">{course.lecturerName}</strong></span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#FC8B0A]" />
              <span>{course.schedule}</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#FC8B0A]" />
              <span>{course.venue}</span>
            </div>
          </div>
        </div>

        {/* Section Segmented Navigation */}
        <div className="flex items-center gap-2 border-b border-[#E5E7EB] bg-white p-2 rounded-xl shadow-xs overflow-x-auto text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('modules')}
            className={`px-4 py-2 font-medium rounded-lg transition-colors cursor-pointer ${
              activeTab === 'modules'
                ? 'bg-[#0D0D0E] text-white font-semibold'
                : 'text-[#667085] hover:text-[#0D0D0E]'
            }`}
          >
            Weekly Modules & Exegesis ({course.weeklyModules.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('syllabus')}
            className={`px-4 py-2 font-medium rounded-lg transition-colors cursor-pointer ${
              activeTab === 'syllabus'
                ? 'bg-[#0D0D0E] text-white font-semibold'
                : 'text-[#667085] hover:text-[#0D0D0E]'
            }`}
          >
            Syllabus & Bibliographical Guide
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('assignments')}
            className={`px-4 py-2 font-medium rounded-lg transition-colors cursor-pointer ${
              activeTab === 'assignments'
                ? 'bg-[#0D0D0E] text-white font-semibold'
                : 'text-[#667085] hover:text-[#0D0D0E]'
            }`}
          >
            Assignments & Term Papers ({courseAssignments.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('resources')}
            className={`px-4 py-2 font-medium rounded-lg transition-colors cursor-pointer ${
              activeTab === 'resources'
                ? 'bg-[#0D0D0E] text-white font-semibold'
                : 'text-[#667085] hover:text-[#0D0D0E]'
            }`}
          >
            Downloadable Resources ({course.resources.length})
          </button>
        </div>

        {/* Tab 1: Weekly Lessons & Theological Texts */}
        {activeTab === 'modules' && (
          <div className="space-y-6">
            <div className="space-y-4">
              {course.weeklyModules.map((mod) => (
                <div
                  key={mod.week}
                  className="bg-white rounded-xl border border-[#E5E7EB] p-7 shadow-xs space-y-3"
                >
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100 text-xs">
                    <span className="font-mono font-bold text-[#FC8B0A]">
                      WEEK 0{mod.week}
                    </span>
                    <span className="text-[#667085]">
                      Canonical Module
                    </span>
                  </div>

                  <h3 className="font-display text-lg font-bold text-[#0D0D0E]">
                    {mod.topic}
                  </h3>

                  <div className="bg-[#F5F6F8] p-4 rounded-lg border border-[#E5E7EB] space-y-2 text-xs">
                    <div>
                      <span className="font-semibold text-slate-700">Required Reading: </span>
                      <span className="italic text-[#0D0D0E] font-display">{mod.readingText}</span>
                    </div>
                    <div>
                      <span className="font-semibold text-slate-700">Theological Objectives: </span>
                      <span className="text-slate-600 font-sans">{mod.objectives}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 2: Syllabus Overview */}
        {activeTab === 'syllabus' && (
          <div className="bg-white rounded-xl border border-[#E5E7EB] p-8 shadow-xs space-y-6 text-xs text-[#0D0D0E]">
            <h3 className="font-display text-xl font-bold text-[#0D0D0E]">
              Academic Course Syllabus Overview
            </h3>
            <p className="leading-relaxed font-sans text-sm text-[#0D0D0E]/80">
              {course.syllabusOverview}
            </p>

            <div className="p-4 bg-[#F5F6F8] rounded-xl border border-[#E5E7EB] space-y-3">
              <h4 className="font-display font-bold text-sm text-[#0D0D0E]">
                Assessment & Grading Weightage
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div className="p-3 bg-white rounded-lg border border-[#E5E7EB]">
                  <div className="text-[#667085]">Continuous Exegetical Papers</div>
                  <div className="font-display text-base font-bold text-[#0D0D0E]">30%</div>
                </div>
                <div className="p-3 bg-white rounded-lg border border-[#E5E7EB]">
                  <div className="text-[#667085]">Chapel Practicum / Seminar</div>
                  <div className="font-display text-base font-bold text-[#0D0D0E]">10%</div>
                </div>
                <div className="p-3 bg-white rounded-lg border border-[#E5E7EB]">
                  <div className="text-[#667085]">Final Semester Examination</div>
                  <div className="font-display text-base font-bold text-[#FC8B0A]">60%</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Assignments */}
        {activeTab === 'assignments' && (
          <div className="space-y-4">
            {courseAssignments.length === 0 ? (
              <div className="p-8 text-center bg-white rounded-xl border border-[#E5E7EB] text-xs text-[#667085]">
                No assignments scheduled for this course at present.
              </div>
            ) : (
              courseAssignments.map((assign) => (
                <div
                  key={assign.id}
                  className="bg-white rounded-xl border border-[#E5E7EB] p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6"
                >
                  <div className="space-y-2 max-w-2xl text-xs">
                    <h3 className="font-display text-base font-bold text-[#0D0D0E]">
                      {assign.title}
                    </h3>
                    <p className="text-slate-600 leading-relaxed font-sans">
                      {assign.instructions}
                    </p>
                    <div className="text-[11px] text-[#667085] flex items-center gap-3 pt-1">
                      <span className="text-rose-700 font-medium">Due Date: {assign.dueDate}</span>
                      <span>·</span>
                      <span>Max Score: {assign.maxScore}</span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => setSubmissionModalAssignId(assign.id)}
                    className="px-5 py-2.5 bg-[#0D0D0E] hover:bg-[#0D1524] text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 cursor-pointer shrink-0"
                  >
                    <Upload className="w-4 h-4 text-[#FC8B0A]" />
                    <span>Submit Coursework</span>
                  </button>
                </div>
              ))
            )}
          </div>
        )}

        {/* Tab 4: Resources */}
        {activeTab === 'resources' && (
          <div className="space-y-3">
            {course.resources.map((res) => (
              <div
                key={res.id}
                className="bg-white rounded-xl border border-[#E5E7EB] p-4 shadow-xs flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-3">
                  <FileText className="w-5 h-5 text-[#FC8B0A] shrink-0" />
                  <div>
                    <h4 className="font-semibold text-[#0D0D0E]">{res.title}</h4>
                    <span className="text-[10px] text-[#667085]">
                      Format: {res.type} · Size: {res.fileSize}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handleDownloadResource(res.title)}
                  className="px-3.5 py-1.5 bg-[#F5F6F8] hover:bg-slate-200 text-[#0D0D0E] font-medium rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download</span>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Submission Modal */}
      {selectedAssign && (
        <Modal
          isOpen={!!submissionModalAssignId}
          onClose={() => setSubmissionModalAssignId(null)}
          title={`Course Paper Submission: ${selectedAssign.courseCode}`}
          subtitle={selectedAssign.title}
          maxWidth="lg"
        >
          <form onSubmit={handleModalSubmit} className="space-y-4 text-xs text-[#0D0D0E]">
            <div>
              <label className="block font-medium mb-1">
                Paper Excerpt or Exegetical Outline *
              </label>
              <textarea
                required
                rows={4}
                value={submissionText}
                onChange={(e) => setSubmissionText(e.target.value)}
                placeholder="Type your doctrinal submission notes or text summary..."
                className="w-full p-3 bg-white border border-[#E5E7EB] rounded-lg outline-none focus:border-[#FC8B0A]"
              />
            </div>

            <div>
              <label className="block font-medium mb-1">
                Manuscript PDF File Name
              </label>
              <input
                type="text"
                value={attachmentName}
                onChange={(e) => setAttachmentName(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-[#E5E7EB] rounded-lg outline-none focus:border-[#FC8B0A]"
              />
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setSubmissionModalAssignId(null)}
                className="px-4 py-2 text-slate-600 hover:text-slate-900"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 bg-[#FC8B0A] hover:bg-[#E07702] text-white font-semibold rounded-lg transition-colors cursor-pointer"
              >
                Submit Paper
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
};
