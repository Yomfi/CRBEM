/**
 * CRBEM Theological Seminary - Data Models & Type Definitions
 * Christ Redemption Bible Evangelical Mission Theological Seminary
 */

export type Role = 
  | 'Super Admin'
  | 'Registrar'
  | 'Admissions Officer'
  | 'Lecturer'
  | 'Librarian'
  | 'Finance Officer'
  | 'Student'
  | 'Applicant'
  | 'Guest';

export type ApplicationStatus = 
  | 'Draft'
  | 'Submitted'
  | 'In Review'
  | 'Interview Scheduled'
  | 'Decision Pending'
  | 'Offer Issued'
  | 'Matriculated'
  | 'Declined'
  | 'On Hold';

export type StudyMode = 'Full-Time (On-Campus)' | 'Part-Time (Executive)' | 'Modular Distance';

export type AcademicLevel = 'Certificate' | 'Diploma' | 'Undergraduate' | 'Postgraduate' | 'Masters';

export interface User {
  id: string;
  email: string;
  fullName: string;
  role: Role;
  avatarUrl?: string;
  phoneNumber?: string;
  department?: string;
  createdAt: string;
}

export interface Applicant extends User {
  applicationId: string;
  programmeId: string;
  programmeName: string;
  applicationReference: string;
  studyMode: StudyMode;
  status: ApplicationStatus;
  submissionDate: string;
  intakeSession: string; // e.g., '2026/2027 Academic Year'
  personalInfo: {
    title: string;
    dateOfBirth: string;
    gender: 'Male' | 'Female';
    nationality: string;
    stateOfOrigin?: string;
    residentialAddress: string;
    churchDenomination: string;
    pastorName: string;
    yearsBornAgain: number;
    ministerialCalling: string;
  };
  educationHistory: {
    institution: string;
    qualification: string;
    yearCompleted: number;
    gradeOrClass?: string;
  }[];
  documents: {
    id: string;
    name: string;
    type: string;
    uploadDate: string;
    fileSize: string;
    verified: boolean;
  }[];
  admissionDecision?: AdmissionDecision;
  interviewDate?: string;
  interviewNotes?: string;
}

export interface AdmissionDecision {
  id: string;
  applicantId: string;
  decision: 'Admitted' | 'Waitlisted' | 'Declined' | 'Conditional';
  decisionDate: string;
  issuedBy: string;
  matriculationNumber?: string;
  programmeOffered: string;
  commencementDate: string;
  letterContent: string;
  acceptedByCandidate: boolean;
  acceptedDate?: string;
}

export interface Student extends User {
  matriculationNumber: string;
  programmeId: string;
  programmeName: string;
  studyMode: StudyMode;
  level: string; // e.g., '100 Level', '200 Level'
  currentSemester: 'First Semester' | 'Second Semester';
  academicSession: string; // e.g., '2026/2027'
  registrationStatus: 'Registered' | 'Pending Fees' | 'Suspended';
  cumulativeGpa: number;
  totalCreditsEarned: number;
  totalCreditsRequired: number;
  facultyAdvisor: string;
  enrollmentDate: string;
}

export interface Staff extends User {
  staffId: string;
  title: string;
  qualification: string;
  designation: string;
  specialization: string;
  assignedCourses: string[];
  officeLocation?: string;
}

export interface Programme {
  id: string;
  code: string; // e.g., 'B.Th.'
  title: string; // e.g., 'Bachelor of Theology'
  level: AcademicLevel;
  duration: string; // e.g., '4 Years (8 Semesters)'
  studyModes: StudyMode[];
  creditsRequired: number;
  overview: string;
  theologicalAim: string;
  admissionRequirements: string[];
  outcomes: string[];
  leadFaculty: string;
  curriculum: {
    semester: string;
    courses: {
      code: string;
      title: string;
      credits: number;
      isCore: boolean;
    }[];
  }[];
}

export interface Course {
  id: string;
  code: string;
  title: string;
  credits: number;
  level: string;
  semester: 'First Semester' | 'Second Semester';
  programmeId: string;
  lecturerName: string;
  lecturerEmail: string;
  description: string;
  syllabusOverview: string;
  schedule: string;
  venue: string;
  weeklyModules: {
    week: number;
    topic: string;
    readingText: string;
    objectives: string;
  }[];
  resources: {
    id: string;
    title: string;
    type: 'PDF' | 'Syllabus' | 'Reading' | 'Audio Lecture';
    fileSize: string;
  }[];
}

export interface CourseRegistration {
  id: string;
  studentId: string;
  courseId: string;
  academicSession: string;
  semester: string;
  status: 'Approved' | 'Pending Approval' | 'Dropped';
  registeredDate: string;
}

export interface AcademicSession {
  id: string;
  name: string; // e.g. '2026/2027'
  isCurrent: boolean;
  semesters: {
    name: 'First Semester' | 'Second Semester';
    startDate: string;
    endDate: string;
    examStartDate: string;
    registrationDeadline: string;
  }[];
}

export interface Assignment {
  id: string;
  courseId: string;
  courseCode: string;
  courseTitle: string;
  title: string;
  instructions: string;
  assignedDate: string;
  dueDate: string;
  maxScore: number;
  allowLateSubmission: boolean;
}

export interface Submission {
  id: string;
  assignmentId: string;
  studentId: string;
  studentName: string;
  submittedAt: string;
  textContent?: string;
  attachmentName?: string;
  status: 'Submitted' | 'Graded' | 'Late';
  score?: number;
  lecturerFeedback?: string;
  gradedBy?: string;
  gradedAt?: string;
}

export interface Result {
  id: string;
  studentId: string;
  courseId: string;
  courseCode: string;
  courseTitle: string;
  credits: number;
  semester: string;
  session: string;
  continuousAssessment: number; // Max 30 or 40
  examinationScore: number;     // Max 70 or 60
  totalScore: number;           // Max 100
  grade: 'A' | 'B' | 'C' | 'D' | 'F';
  gradePoint: number;           // 5.0 scale or 4.0 scale (4.0 standard: A=4, B=3, C=2, D=1, F=0)
}

export interface Announcement {
  id: string;
  title: string;
  category: 'Academic' | 'Registrar' | 'Chapel & Spiritual' | 'Admissions' | 'Library';
  content: string;
  date: string;
  author: string;
  priority: 'Normal' | 'High' | 'Urgent';
  targetAudience: 'All' | 'Students' | 'Faculty' | 'Applicants';
}

export interface LibraryBook {
  id: string;
  isbn: string;
  title: string;
  author: string;
  publicationYear: number;
  edition: string;
  category: 
    | 'Systematic Theology'
    | 'Biblical Exegesis'
    | 'Biblical Languages'
    | 'Pastoral Ministry'
    | 'Church History'
    | 'CRBEM Archives';
  shelfLocation: string; // e.g., 'ST-104-A'
  summary: string;
  totalCopies: number;
  availableCopies: number;
  excerpt: string;
  tableOfContents?: string[];
  coverColor?: string;
}

export interface LibraryLoan {
  id: string;
  bookId: string;
  bookTitle: string;
  bookAuthor: string;
  shelfLocation: string;
  userId: string;
  userName: string;
  borrowDate: string;
  dueDate: string;
  returnDate?: string;
  status: 'Active' | 'Returned' | 'Overdue';
}

export interface ContactEnquiry {
  id: string;
  fullName: string;
  email: string;
  phone?: string;
  subject: string;
  message: string;
  submittedAt: string;
  status: 'New' | 'Replied' | 'Archived';
  category: 'General' | 'Admissions' | 'Sponsorship' | 'Pastoral Transcript';
}

export interface AuditLog {
  id: string;
  action: string;
  performedBy: string;
  target: string;
  timestamp: string;
  details: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  date: string;
  read: boolean;
  type: 'info' | 'success' | 'warning';
  linkToView?: string;
}
