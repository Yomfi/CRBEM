/**
 * CRBEM Theological Seminary - Seed Data
 * Christ Redemption Bible Evangelical Mission Theological Seminary
 * Isolated seed data repository ready for seamless Firebase/Firestore migration
 */

import {
  Programme,
  Course,
  LibraryBook,
  Applicant,
  Student,
  Staff,
  Announcement,
  AcademicSession,
  Assignment,
  Submission,
  Result,
  ContactEnquiry,
  LibraryLoan,
  AuditLog
} from '../types';

export const SEED_PROGRAMMES: Programme[] = [
  {
    id: 'prog-cth',
    code: 'C.Th.',
    title: 'Certificate in Theology',
    level: 'Certificate',
    duration: '1 Year (2 Semesters)',
    studyModes: ['Full-Time (On-Campus)', 'Modular Distance'],
    creditsRequired: 32,
    leadFaculty: 'Rev. Dr. Samuel O. Olawale, Th.D.',
    overview: 'An intensive foundational certificate designed for church workers, Sunday school teachers, and lay evangelists seeking solid grounding in basic biblical hermeneutics and foundational Christian doctrine.',
    theologicalAim: 'To equip lay leaders with sound biblical literacy, basic expository tools, and evangelical commitment.',
    admissionRequirements: [
      'Evidence of genuine Christian conversion and active local church membership',
      'High School Diploma / Secondary School Certificate (WASSCE / NECO or equivalent)',
      'Letter of recommendation from the candidate\'s supervising Pastor',
      'Personal statement of faith and ministerial aspiration'
    ],
    outcomes: [
      'Grasp of Old and New Testament thematic frameworks',
      'Sound understanding of cardinal doctrines of the Christian faith',
      'Basic competence in personal Bible study and small-group teaching',
      'Preparedness for ministry support roles in local congregations'
    ],
    curriculum: [
      {
        semester: 'First Semester',
        courses: [
          { code: 'BIB 101', title: 'Old Testament Survey', credits: 3, isCore: true },
          { code: 'THE 101', title: 'Survey of Christian Doctrine', credits: 3, isCore: true },
          { code: 'MIN 101', title: 'Spiritual Formation & Devotional Life', credits: 2, isCore: true },
          { code: 'MIS 101', title: 'Personal Evangelism & Discipleship', credits: 3, isCore: true },
          { code: 'ENG 101', title: 'Use of English & Theological Writing', credits: 2, isCore: true }
        ]
      },
      {
        semester: 'Second Semester',
        courses: [
          { code: 'BIB 102', title: 'New Testament Survey', credits: 3, isCore: true },
          { code: 'THE 102', title: 'Theology of Salvation & Pneumatology', credits: 3, isCore: true },
          { code: 'MIN 102', title: 'Lay Ministry Practicum', credits: 3, isCore: true },
          { code: 'HIS 102', title: 'Survey of Church History', credits: 3, isCore: true },
          { code: 'ETH 102', title: 'Christian Ethics in Daily Living', credits: 2, isCore: true }
        ]
      }
    ]
  },
  {
    id: 'prog-dipth',
    code: 'Dip.Th.',
    title: 'Diploma in Theology',
    level: 'Diploma',
    duration: '2 Years (4 Semesters)',
    studyModes: ['Full-Time (On-Campus)', 'Part-Time (Executive)', 'Modular Distance'],
    creditsRequired: 64,
    leadFaculty: 'Pastor Grace E. Adebayo, M.Th.',
    overview: 'A comprehensive two-year ministerial qualification preparing candidates for pastoral assistantships, youth pastoring, and evangelistic leadership with balanced pastoral and biblical depth.',
    theologicalAim: 'To form faithful ministers of the Word capable of pastoral counsel, homiletical delivery, and doctrinal defense.',
    admissionRequirements: [
      'Secondary School Certificate with minimum 4 credits including English Language',
      'Or Certificate in Theology from CRBEM or an accredited institution',
      'Satisfactory pastoral endorsement and personal interview with Admissions Committee',
      'Minimum two years of active Christian discipleship'
    ],
    outcomes: [
      'Competence in expository sermon design and biblical preaching',
      'Practical pastoral care and liturgical administration skills',
      'Firm grounding in historical theology and evangelical apologetics',
      'Qualification for intermediate pastoral responsibilities'
    ],
    curriculum: [
      {
        semester: 'Year 1 - First Semester',
        courses: [
          { code: 'BIB 101', title: 'Old Testament Survey & Canon', credits: 3, isCore: true },
          { code: 'THE 201', title: 'Systematic Theology I: God & Revelation', credits: 3, isCore: true },
          { code: 'MIN 201', title: 'Principles of Christian Preaching', credits: 3, isCore: true },
          { code: 'LAN 101', title: 'Introduction to Biblical Studies Tools', credits: 2, isCore: true }
        ]
      },
      {
        semester: 'Year 1 - Second Semester',
        courses: [
          { code: 'BIB 102', title: 'New Testament Survey & Gospels', credits: 3, isCore: true },
          { code: 'THE 202', title: 'Systematic Theology II: Christology & Soteriology', credits: 3, isCore: true },
          { code: 'MIN 202', title: 'Pastoral Care and Counseling', credits: 3, isCore: true },
          { code: 'HIS 202', title: 'History of the Reformation', credits: 3, isCore: true }
        ]
      }
    ]
  },
  {
    id: 'prog-bth',
    code: 'B.Th.',
    title: 'Bachelor of Theology',
    level: 'Undergraduate',
    duration: '4 Years (8 Semesters)',
    studyModes: ['Full-Time (On-Campus)', 'Part-Time (Executive)', 'Modular Distance'],
    creditsRequired: 120,
    leadFaculty: 'Ven. Prof. Jeremiah K. Alabi, Ph.D.',
    overview: 'Our flagship academic degree offering rigorous exegetical training in biblical Hebrew and Greek, extensive systematic theology, pastoral leadership, and historical theology for ordained gospel ministry and senior pastoral service.',
    theologicalAim: 'To cultivate scholarly, spiritually vibrant shepherds who rightly divide the Word of truth and lead Christ’s flock with theological integrity.',
    admissionRequirements: [
      'Senior Secondary School Certificate (SSCE/GCE/WASSCE/NECO) with minimum 5 credit passes including English Language',
      'Or Diploma in Theology (Dip.Th.) with minimum merit grade (admitted into 200 Level Direct Entry)',
      'Letter of pastoral recommendation attesting to sound Christian morals and spiritual call',
      'Written statement of personal Christian testimony and ministerial intent',
      'Successful performance in the CRBEM Seminary Entrance Examination and Oral Interview'
    ],
    outcomes: [
      'Exegesis of Old and New Testament texts using biblical Hebrew and Koine Greek',
      'Formulation of coherent systematic theological frameworks grounded in canonical Scripture',
      'Exemplary pastoral leadership, administrative wisdom, and ethical character',
      'Readiness for pastoral ordination or postgraduate theological research'
    ],
    curriculum: [
      {
        semester: 'Year 1 - First Semester',
        courses: [
          { code: 'BIB 101', title: 'Introduction to Old Testament Literature', credits: 3, isCore: true },
          { code: 'THE 201', title: 'Systematic Theology I: Prolegomena & Theology Proper', credits: 3, isCore: true },
          { code: 'HIS 101', title: 'Early Church History to AD 500', credits: 3, isCore: true },
          { code: 'MIN 101', title: 'Spiritual Formation & Discipleship', credits: 2, isCore: true },
          { code: 'ENG 101', title: 'Academic Research & Theological Writing', credits: 2, isCore: true }
        ]
      },
      {
        semester: 'Year 1 - Second Semester',
        courses: [
          { code: 'BIB 102', title: 'New Testament Survey & Exegesis', credits: 3, isCore: true },
          { code: 'THE 202', title: 'Systematic Theology II: Christology & Pneumatology', credits: 3, isCore: true },
          { code: 'LAN 205', title: 'Elements of New Testament Greek I', credits: 3, isCore: true },
          { code: 'MIS 102', title: 'The Theology of Christian Missions', credits: 3, isCore: true },
          { code: 'ETH 102', title: 'Biblical Ethics & Contemporary Culture', credits: 2, isCore: true }
        ]
      },
      {
        semester: 'Year 2 - First Semester',
        courses: [
          { code: 'LAN 206', title: 'Elements of New Testament Greek II', credits: 3, isCore: true },
          { code: 'BIB 201', title: 'The Pentateuch: Text & Theology', credits: 3, isCore: true },
          { code: 'THE 301', title: 'Systematic Theology III: Ecclesiology & Eschatology', credits: 3, isCore: true },
          { code: 'MIN 301', title: 'Expository Preaching & Homiletics', credits: 3, isCore: true },
          { code: 'HIS 201', title: 'Medieval & Reformation Church History', credits: 3, isCore: true }
        ]
      },
      {
        semester: 'Year 2 - Second Semester',
        courses: [
          { code: 'LAN 301', title: 'Biblical Hebrew Grammar I', credits: 3, isCore: true },
          { code: 'BIB 202', title: 'The Pauline Corpus: Epistles & Theology', credits: 3, isCore: true },
          { code: 'MIN 302', title: 'Pastoral Theology & Church Administration', credits: 3, isCore: true },
          { code: 'MIS 202', title: 'Cross-Cultural Church Planting', credits: 3, isCore: true },
          { code: 'THE 302', title: 'Christian Apologetics & World Religions', credits: 3, isCore: true }
        ]
      }
    ]
  },
  {
    id: 'prog-pgdth',
    code: 'PGD.Th.',
    title: 'Postgraduate Diploma in Theology',
    level: 'Postgraduate',
    duration: '1 Year (2 Semesters)',
    studyModes: ['Part-Time (Executive)', 'Modular Distance'],
    creditsRequired: 36,
    leadFaculty: 'Dr. Michael T. Danladi, Ph.D.',
    overview: 'Tailored for university graduates in secular disciplines (engineering, medicine, law, commerce) who have answered the call to pastoral ministry or theological teaching and require an accelerated bridge into academic theology.',
    theologicalAim: 'To provide mature professionals with rapid immersion in biblical languages, systematic theology, and ministerial practice.',
    admissionRequirements: [
      'Recognized Bachelor’s Degree (B.A., B.Sc., B.Eng., LL.B., etc.) in any discipline with minimum Second Class Lower',
      'Or Higher National Diploma (HND) with minimum Upper Credit',
      'Personal statement of conversion and ministerial calling',
      'Two confidential letters of reference (one ministerial, one professional)',
      'Admissions interview with the Board of Postgraduate Studies'
    ],
    outcomes: [
      'Bridge qualification providing eligibility for Master of Theology (M.Th.)',
      'Rigorous integration of secular vocation insights with biblical worldview',
      'Competence in biblical exegesis, hermeneutics, and pastoral leadership'
    ],
    curriculum: [
      {
        semester: 'First Semester',
        courses: [
          { code: 'PGD 701', title: 'Advanced Old Testament Foundations', credits: 3, isCore: true },
          { code: 'PGD 702', title: 'Advanced New Testament Foundations', credits: 3, isCore: true },
          { code: 'PGD 703', title: 'Survey of Christian Dogmatics', credits: 3, isCore: true },
          { code: 'PGD 704', title: 'Biblical Hermeneutics & Exegetical Method', credits: 3, isCore: true },
          { code: 'PGD 705', title: 'Theological Research Methodology', credits: 3, isCore: true }
        ]
      },
      {
        semester: 'Second Semester',
        courses: [
          { code: 'PGD 706', title: 'Pastoral Leadership & Strategic Ministry', credits: 3, isCore: true },
          { code: 'PGD 707', title: 'History of Global & African Christianity', credits: 3, isCore: true },
          { code: 'PGD 708', title: 'Contemporary Theological Issues', credits: 3, isCore: true },
          { code: 'PGD 709', title: 'Postgraduate Research Project', credits: 6, isCore: true }
        ]
      }
    ]
  },
  {
    id: 'prog-mth',
    code: 'M.Th.',
    title: 'Master of Theology',
    level: 'Masters',
    duration: '2 Years (4 Semesters)',
    studyModes: ['Full-Time (On-Campus)', 'Part-Time (Executive)', 'Modular Distance'],
    creditsRequired: 48,
    leadFaculty: 'Rt. Rev. Dr. Festus B. Akinwumi, Ph.D. (Cantab)',
    overview: 'An advanced postgraduate research degree designed for scholars, seminary lecturers, and senior church leaders desiring advanced specialization in Systematic Theology, Biblical Exegesis, or Christian Missions.',
    theologicalAim: 'To form high-level theological researchers and educators whose scholarship builds up the body of Christ across the globe.',
    admissionRequirements: [
      'Bachelor of Theology (B.Th.) or B.A. in Religious Studies with minimum Second Class Upper',
      'Or Postgraduate Diploma in Theology (PGD.Th.) with minimum CGPA of 3.50 on a 5.0 scale',
      'Demonstrated proficiency in at least one biblical language (Hebrew or Greek)',
      'Substantive Research Proposal (approx. 1,500 words) in prospective area of research',
      'Comprehensive interview and review by the Senate Graduate Committee'
    ],
    outcomes: [
      'Original theological scholarship contributing to evangelical academia',
      'Mastery of original Hebrew and Greek texts in exegetical analysis',
      'Competence in university and seminary level theological instruction',
      'Preparation for Doctor of Philosophy (Ph.D.) or Th.D. candidacy'
    ],
    curriculum: [
      {
        semester: 'Year 1 - First Semester',
        courses: [
          { code: 'MTH 801', title: 'Advanced Theological Hermeneutics & Epistemology', credits: 3, isCore: true },
          { code: 'MTH 802', title: 'Advanced Greek Exegesis: Romans & Hebrews', credits: 3, isCore: true },
          { code: 'MTH 803', title: 'Post-Reformation Reformed Scholasticism & Theology', credits: 3, isCore: true }
        ]
      },
      {
        semester: 'Year 1 - Second Semester',
        courses: [
          { code: 'MTH 804', title: 'Advanced Hebrew Exegesis: Isaiah & Psalms', credits: 3, isCore: true },
          { code: 'MTH 805', title: 'Theology of Missions & Intercultural Encounter', credits: 3, isCore: true },
          { code: 'MTH 806', title: 'Colloquium on African Theological Perspectives', credits: 3, isCore: true }
        ]
      },
      {
        semester: 'Year 2 - Thesis Phase',
        courses: [
          { code: 'MTH 899', title: 'Master’s Thesis & Oral Defense', credits: 12, isCore: true }
        ]
      }
    ]
  }
];

export const SEED_COURSES: Course[] = [
  {
    id: 'course-bib-101',
    code: 'BIB 101',
    title: 'Introduction to Old Testament Literature & Theology',
    credits: 3,
    level: '100 Level',
    semester: 'First Semester',
    programmeId: 'prog-bth',
    lecturerName: 'Ven. Prof. Jeremiah K. Alabi',
    lecturerEmail: 'j.alabi@crbemseminary.edu',
    schedule: 'Mondays & Wednesdays · 09:00 - 10:30 AM',
    venue: 'Academic Hall Alpha (Floor 2)',
    description: 'A canonical and theological exploration of the Hebrew Scriptures (Tanakh), focusing on literary genres, historical covenants, and Christological trajectories from Genesis through Malachi.',
    syllabusOverview: 'This course guides the student through the Pentateuch, Historical books, Poetic literature, and the Major & Minor Prophets. Emphasis is placed on redemptive-historical hermeneutics.',
    weeklyModules: [
      {
        week: 1,
        topic: 'The Nature and Canon of the Old Testament',
        readingText: 'Bruce K. Waltke, An Old Testament Theology, Chapters 1–2',
        objectives: 'Understand inspiration, text transmission, and canonical order.'
      },
      {
        week: 2,
        topic: 'Primeval History: Creation, Fall, and Covenant (Genesis 1–11)',
        readingText: 'Genesis 1–11 Exegetical Commentary & Notes',
        objectives: 'Examine cosmic temple theology and the Protoevangelium in Gen 3:15.'
      },
      {
        week: 3,
        topic: 'The Patriarchal Covenant: Abraham, Isaac, and Jacob',
        readingText: 'Gordon Wenham, Genesis 16–50, Word Biblical Commentary',
        objectives: 'Trace unconditional promises of seed, land, and universal blessing.'
      },
      {
        week: 4,
        topic: 'The Exodus Event & the Mosaic Covenant',
        readingText: 'Exodus 19–24; Leviticus 16 Sacrificial Atonement',
        objectives: 'Analyze holy law, the tabernacle, and substitutionary sacrifice.'
      },
      {
        week: 5,
        topic: 'The Prophetic Tradition and the Messianic Hope',
        readingText: 'Isaiah 52:13–53:12 The Suffering Servant Songs',
        objectives: 'Evaluate prophetic covenant prosecution and eschatological restoration.'
      }
    ],
    resources: [
      { id: 'res-1', title: 'BIB 101 Course Syllabus & Reading Guide (PDF)', type: 'Syllabus', fileSize: '1.4 MB' },
      { id: 'res-2', title: 'Old Testament Timeline & Covenant Chart', type: 'Reading', fileSize: '3.2 MB' },
      { id: 'res-3', title: 'Exegesis Paper Guide: Old Testament Narrative', type: 'PDF', fileSize: '850 KB' }
    ]
  },
  {
    id: 'course-the-201',
    code: 'THE 201',
    title: 'Systematic Theology I: God, Revelation & Humanity',
    credits: 3,
    level: '200 Level',
    semester: 'First Semester',
    programmeId: 'prog-bth',
    lecturerName: 'Rev. Dr. Samuel O. Olawale',
    lecturerEmail: 's.olawale@crbemseminary.edu',
    schedule: 'Tuesdays & Thursdays · 11:00 AM - 12:30 PM',
    venue: 'Theology Seminar Room 3',
    description: 'An in-depth doctrinal examination of Prolegomena, General and Special Revelation, the Divine Attributes, the Holy Trinity, Creation ex nihilo, and the Fall of Humanity.',
    syllabusOverview: 'Students engage with historical confessions, biblical proof-texts, and contemporary theological debates concerning inerrancy, open theism, and theological anthropology.',
    weeklyModules: [
      {
        week: 1,
        topic: 'Prolegomena: The Nature, Task, and Method of Theology',
        readingText: 'Wayne Grudem, Systematic Theology 2nd Ed., Chapter 1',
        objectives: 'Distinguish biblical, historical, practical, and systematic theology.'
      },
      {
        week: 2,
        topic: 'The Word of God: Inerrancy, Authority, and Sufficiency',
        readingText: 'The Chicago Statement on Biblical Inerrancy',
        objectives: 'Affirm the plenary verbal inspiration of the 66 canonical books.'
      },
      {
        week: 3,
        topic: 'The Holy Trinity: One Being, Three Co-Equal Persons',
        readingText: 'Augustine, De Trinitate; Nicene-Constantinopolitan Creed',
        objectives: 'Articulate orthodox Trinitarianism against historical heresies.'
      },
      {
        week: 4,
        topic: 'The Providence of God: Sovereignty, Human Will, and Evil',
        readingText: 'John Calvin, Institutes Book I, Chapters 16–18',
        objectives: 'Reconcile divine sovereignty and human moral responsibility.'
      }
    ],
    resources: [
      { id: 'res-4', title: 'THE 201 Syllabus & Primary Source Readings', type: 'Syllabus', fileSize: '1.8 MB' },
      { id: 'res-5', title: 'Historical Creeds & Confessions Sourcebook', type: 'Reading', fileSize: '4.6 MB' }
    ]
  },
  {
    id: 'course-lan-205',
    code: 'LAN 205',
    title: 'Elements of New Testament Greek I',
    credits: 3,
    level: '200 Level',
    semester: 'First Semester',
    programmeId: 'prog-bth',
    lecturerName: 'Pastor Grace E. Adebayo',
    lecturerEmail: 'g.adebayo@crbemseminary.edu',
    schedule: 'Mondays, Wednesdays & Fridays · 08:00 - 09:00 AM',
    venue: 'Language Laboratory 1',
    description: 'Introductory Koine Greek covering the alphabet, accents, noun declensions (1st and 2nd), case functions, prepositions, and present active/middle/passive indicative verbs.',
    syllabusOverview: 'Geared towards developing reading proficiency in the Greek New Testament (Nestle-Aland 28th edition). Daily translation and vocabulary drills.',
    weeklyModules: [
      {
        week: 1,
        topic: 'The Koine Alphabet, Diphthongs, and Pronunciation',
        readingText: 'William D. Mounce, Basics of Biblical Greek, Chapters 1–4',
        objectives: 'Accurate reading aloud and orthography of the Greek text.'
      },
      {
        week: 2,
        topic: 'Second Declension Nouns and the Definite Article',
        readingText: 'Mounce, Chapters 6–7',
        objectives: 'Memorize case endings (Nominative, Genitive, Dative, Accusative).'
      },
      {
        week: 3,
        topic: 'First Declension Nouns and Adjectives',
        readingText: 'Mounce, Chapters 8–9',
        objectives: 'Analyze feminine declension patterns and adjective agreement.'
      },
      {
        week: 4,
        topic: 'Prepositions and the Present Active Indicative',
        readingText: 'Mounce, Chapters 15–16',
        objectives: 'Parse primary verb stems and understand tense/aspect.'
      }
    ],
    resources: [
      { id: 'res-6', title: 'Greek Vocabulary Frequency Flashcards (PDF)', type: 'PDF', fileSize: '2.1 MB' },
      { id: 'res-7', title: 'LAN 205 Workbook & Weekly Exercises', type: 'Reading', fileSize: '5.0 MB' }
    ]
  },
  {
    id: 'course-min-301',
    code: 'MIN 301',
    title: 'Expository Preaching & Homiletics',
    credits: 3,
    level: '300 Level',
    semester: 'First Semester',
    programmeId: 'prog-bth',
    lecturerName: 'Rt. Rev. Dr. Festus B. Akinwumi',
    lecturerEmail: 'f.akinwumi@crbemseminary.edu',
    schedule: 'Fridays · 09:30 AM - 12:30 PM',
    venue: 'Chapel Lecture Hall',
    description: 'The theology and craft of biblical preaching. Instruction on bridging the gap between historical exegetical meaning and contemporary proclamation with pastoral power.',
    syllabusOverview: 'Students craft expository sermon manuscripts and deliver evaluated sermons in the seminary chapel practicum.',
    weeklyModules: [
      {
        week: 1,
        topic: 'The Mandate of Preaching: 2 Timothy 4:1–5',
        readingText: 'John Stott, Between Two Worlds: The Challenge of Preaching',
        objectives: 'Define expository preaching versus topical and subjective speech.'
      },
      {
        week: 2,
        topic: 'Discovering the Big Idea of the Text (Hermeneutics to Homiletics)',
        readingText: 'Haddon Robinson, Biblical Preaching, Chapters 3–4',
        objectives: 'Formulate the exegetical idea and the homiletical proposition.'
      },
      {
        week: 3,
        topic: 'Sermon Structure: Introduction, Transitions, Body, Conclusion',
        readingText: 'Bryan Chapell, Christ-Centered Preaching',
        objectives: 'Build cohesive outlines that hold listener engagement.'
      },
      {
        week: 4,
        topic: 'Illustrations, Application, and Pastoral Delivery',
        readingText: 'Charles Spurgeon, Lectures to My Students',
        objectives: 'Apply biblical truth directly to heart, conscience, and life.'
      }
    ],
    resources: [
      { id: 'res-8', title: 'Sermon Evaluation Rubric & Feedback Sheet', type: 'PDF', fileSize: '650 KB' },
      { id: 'res-9', title: 'Expository Sermon Manuscript Template', type: 'Syllabus', fileSize: '420 KB' }
    ]
  },
  {
    id: 'course-his-304',
    code: 'HIS 304',
    title: 'Church History: Patristic to Reformation',
    credits: 3,
    level: '300 Level',
    semester: 'First Semester',
    programmeId: 'prog-bth',
    lecturerName: 'Dr. Michael T. Danladi',
    lecturerEmail: 'm.danladi@crbemseminary.edu',
    schedule: 'Wednesdays · 02:00 - 05:00 PM',
    venue: 'Auditorium 2',
    description: 'The narrative of the Christian movement from the Apostolic Fathers through the Councils of Nicaea and Chalcedon, medieval monasticism, and the 16th-century Protestant Reformation.',
    syllabusOverview: 'Examines doctrinal controversies, institutional developments, and how providence preserved the pure gospel through historical turbulence.',
    weeklyModules: [
      {
        week: 1,
        topic: 'Persecution, Apologists, and Martyrdom in the Roman Empire',
        readingText: 'Justo L. González, The Story of Christianity Vol. 1',
        objectives: 'Understand Tertullian, Justin Martyr, and early church ethos.'
      },
      {
        week: 2,
        topic: 'Ecumenical Councils and the Christological Debates',
        readingText: 'Creeds of Nicaea (325) and Chalcedon (451)',
        objectives: 'Analyze Arianism, Nestorianism, and orthodox resolutions.'
      },
      {
        week: 3,
        topic: 'The 16th-Century Solas: Luther, Zwingli, and Calvin',
        readingText: 'Roland Bainton, Here I Stand: A Life of Martin Luther',
        objectives: 'Examine Sola Scriptura, Sola Gratia, and Sola Fide.'
      }
    ],
    resources: [
      { id: 'res-10', title: 'Patristic Source Documents Collection (PDF)', type: 'Reading', fileSize: '6.1 MB' }
    ]
  }
];

export const SEED_LIBRARY_BOOKS: LibraryBook[] = [
  {
    id: 'book-1',
    isbn: '978-0310286707',
    title: 'Systematic Theology: An Introduction to Biblical Doctrine (2nd Edition)',
    author: 'Wayne Grudem',
    publicationYear: 2020,
    edition: 'Second Edition',
    category: 'Systematic Theology',
    shelfLocation: 'ST-104-A',
    summary: 'A monumental, biblical, clear, and devotional treatment of Christian theology covering the Word of God, the Doctrine of God, Creation, Man, Christ, the Holy Spirit, the Church, and the End Times.',
    totalCopies: 8,
    availableCopies: 6,
    coverColor: '#0D1524',
    excerpt: `Theology is simply what the whole Bible teaches us today about any given topic. When we engage in systematic theology, we are asking: "What does the entirety of Scripture teach us concerning who God is, how He saves sinners, and how we are to live in response?" Systematic theology is not mere intellectual speculation; it is doxological. It must lead inevitably to worship, obedience, and vibrant pastoral love. In this revised edition, great care is taken to defend the absolute inerrancy of the Holy Scriptures, the triune nature of God, and the penal substitutionary atonement of Jesus Christ.`
  },
  {
    id: 'book-2',
    isbn: '978-0830816507',
    title: 'Knowing God',
    author: 'J.I. Packer',
    publicationYear: 1973,
    edition: 'Commemorative Edition',
    category: 'Systematic Theology',
    shelfLocation: 'ST-208-B',
    summary: 'A modern theological classic demonstrating that the study of God’s nature, holiness, grace, and wrath is the ultimate purpose of human life and the heartbeat of evangelical spirituality.',
    totalCopies: 12,
    availableCopies: 9,
    coverColor: '#1E293B',
    excerpt: `As it enters the mind of anyone who reflects upon it, the question: "What were we made for?" brings the immediate, definitive answer: "To know God." What is the best thing in life, bringing more joy, delight, and contentment than anything else? Knowledge of God. "Thus says the LORD: Let not the wise man boast in his wisdom... but let him who boasts boast in this, that he understands and knows me" (Jeremiah 9:23–24). We turn theological doctrine into personal fellowship when we contemplate God’s majesty on our knees.`
  },
  {
    id: 'book-3',
    isbn: '978-0310517825',
    title: 'How to Read the Bible for All Its Worth (4th Edition)',
    author: 'Gordon D. Fee & Douglas Stuart',
    publicationYear: 2014,
    edition: 'Fourth Edition',
    category: 'Biblical Exegesis',
    shelfLocation: 'BE-112-A',
    summary: 'The premier hermeneutics handbook teaching students how to interpret the varied literary genres of Scripture: Epistles, Old Testament Narratives, Acts, Gospels, Parables, Law, Prophets, Psalms, Wisdom, and Revelation.',
    totalCopies: 10,
    availableCopies: 7,
    coverColor: '#0F172A',
    excerpt: `The aim of good interpretation is not uniqueness; one is not trying to discover what no one else has ever seen before. The aim of good interpretation is simple: to get at the plain meaning of the text. The most common error readers make is confusing the reader's contemporary situation with the author's original historical setting. Exegesis is the careful, systematic study of the Scripture to discover the originally intended meaning. Only after we understand what the text meant can we faithfully declare what the text means today.`
  },
  {
    id: 'book-4',
    isbn: '978-0802825100',
    title: 'The Epistle to the Hebrews (New International Commentary on the NT)',
    author: 'F.F. Bruce',
    publicationYear: 1990,
    edition: 'Revised Edition',
    category: 'Biblical Exegesis',
    shelfLocation: 'BE-305-C',
    summary: 'A masterwork of evangelical exegesis detailing the supreme supremacy of Jesus Christ over angels, Moses, Aaron, and the Old Covenant sacrificial system.',
    totalCopies: 6,
    availableCopies: 4,
    coverColor: '#334155',
    excerpt: `The author of the Epistle to the Hebrews sets before us the finality of God's revelation in His Son. In times past, God spoke to the fathers by the prophets in portions and in varied manners; but in these last days He has spoken to us in a Son, whom He appointed heir of all things. The old ceremonies were but shadows of good things to come; the substance belongs to Christ. Therefore, the believer is urged to look steadfastly unto Jesus, the author and finisher of our faith, and not to draw back.`
  },
  {
    id: 'book-5',
    isbn: '978-0801021442',
    title: 'Lexical Aids for Students of New Testament Greek',
    author: 'Bruce M. Metzger',
    publicationYear: 1998,
    edition: 'Special Edition',
    category: 'Biblical Languages',
    shelfLocation: 'BL-045-A',
    summary: 'Indispensable lexical resource classifying all Greek New Testament vocabulary according to word frequency and cognate roots, accompanied by parsing charts.',
    totalCopies: 15,
    availableCopies: 11,
    coverColor: '#1E1B4B',
    excerpt: `A mastery of vocabulary is the foundation of exegetical liberty. Any theological student who memorizes all words occurring ten times or more in the Greek New Testament will be equipped to read approximately eighty percent of the New Testament text without constant recourse to a lexicon. In addition to frequency classifications, this volume groups words by root families, allowing the theological researcher to grasp theological affinities across semantic domains.`
  },
  {
    id: 'book-6',
    isbn: '978-0310537434',
    title: 'Basics of Biblical Greek Grammar (4th Edition)',
    author: 'William D. Mounce',
    publicationYear: 2019,
    edition: 'Fourth Edition',
    category: 'Biblical Languages',
    shelfLocation: 'BL-090-B',
    summary: 'The standard worldwide introductory textbook for New Testament Koine Greek, featuring integrated syntax rules, morphology charts, and real New Testament translation passages.',
    totalCopies: 14,
    availableCopies: 8,
    coverColor: '#172554',
    excerpt: `Greek is not a secret code meant to puzzle students; it was the everyday commercial language of the Mediterranean basin, chosen in God's providence so that the gospel of salvation might travel rapidly and clearly across nations. By learning noun cases and verbal aspect directly, the student sees shades of nuance that translations necessarily flatten. Our goal is not linguistic gymnastics, but the humble, accurate ministry of the living Word.`
  },
  {
    id: 'book-7',
    isbn: '978-1845501860',
    title: 'The Christian Ministry: With an Inquiry into the Causes of Its Inefficiency',
    author: 'Charles Bridges',
    publicationYear: 2006,
    edition: 'Banner of Truth Reprint',
    category: 'Pastoral Ministry',
    shelfLocation: 'PM-202-A',
    summary: 'A timeless 19th-century pastoral classic exploring the dignities, temptations, spiritual perils, pastoral visitation duties, and devotional life of the Christian minister.',
    totalCopies: 5,
    availableCopies: 3,
    coverColor: '#18181B',
    excerpt: `The Christian ministry is the most glorious and fearful office committed to human beings. We are ambassadors for Christ; as though God did beseech men by us, we pray them in Christ's stead, be ye reconciled to God. Yet how frequently is our ministry rendered inefficient by the neglect of secret prayer, conformity to the world, defect of personal holiness, or fear of man! The minister must be a man of God before he is a preacher to men. His life must be the sermon of his sermon.`
  },
  {
    id: 'book-8',
    isbn: '978-0851515243',
    title: 'The Reformed Pastor',
    author: 'Richard Baxter',
    publicationYear: 1989,
    edition: 'Edited by William Brown',
    category: 'Pastoral Ministry',
    shelfLocation: 'PM-115-D',
    summary: 'Baxter’s urgent Puritan charge based on Acts 20:28: Take heed therefore unto yourselves, and to all the flock, over the which the Holy Ghost hath made you overseers.',
    totalCopies: 7,
    availableCopies: 5,
    coverColor: '#27272A',
    excerpt: `Take heed to yourselves, lest your example contradict your doctrine, and that which you build up with your tongues you pull down with your hands. What! preaching of heaven, and yet living for earth? Preaching against pride, while you swell with ambition? Brethren, watch over yourselves with holy jealousy! Catechize every family; knock on every door; counsel the wavering; visit the sick. Let no soul under your charge perish for lack of pastoral entreaty.`
  },
  {
    id: 'book-9',
    isbn: '978-0061855887',
    title: 'The Story of Christianity, Vol. 1: The Early Church to the Dawn of the Reformation',
    author: 'Justo L. González',
    publicationYear: 2010,
    edition: 'Revised & Updated Edition',
    category: 'Church History',
    shelfLocation: 'CH-401-A',
    summary: 'A vivid, narrative-driven history of the church from apostolic times through medieval monasticism, the great schism, and the eve of the Protestant Reformation.',
    totalCopies: 9,
    availableCopies: 6,
    coverColor: '#09090B',
    excerpt: `Christianity was born in the cradle of Judaism, in a world dominated by Rome and shaped by Greek culture. The blood of the martyrs truly became the seed of the church as ordinary men and women bore witness to the resurrection under Roman imperial wrath. Through controversies regarding the person of Christ and the grace of God, thinkers such as Athanasius and Augustine gave enduring shape to Christian theology, demonstrating how God preserved His truth.`
  },
  {
    id: 'book-10',
    isbn: 'CRBEM-ARCH-1984',
    title: 'History and Foundational Charism of Christ Redemption Bible Evangelical Mission (1984–Present)',
    author: 'Office of the Seminary Historian & Founder',
    publicationYear: 2018,
    edition: 'Archival Institutional Edition',
    category: 'CRBEM Archives',
    shelfLocation: 'CR-001-SPEC',
    summary: 'The official institutional record detailing the founding vision, doctrinal confessions, pioneering missionary breakthroughs, and the establishment of CRBEM Theological Seminary.',
    totalCopies: 4,
    availableCopies: 4,
    coverColor: '#FC8B0A',
    excerpt: `Christ Redemption Bible Evangelical Mission (CRBEM) was birthed out of fervent prayer, apostolic zeal, and an unshakeable conviction that the Holy Scriptures are the inerrant Word of the living God. From humble prayer altars in 1984 to global evangelistic outreaches, the mission has remained faithful to the biblical injunction in 2 Timothy 2:15: "Study to show thyself approved unto God, a workman that needeth not to be ashamed, rightly dividing the word of truth." This volume chronicles our lineage of faith and ministerial heritage.`
  }
];

export const SEED_FACULTY: Staff[] = [
  {
    id: 'staff-1',
    staffId: 'CRBEM/FAC/001',
    email: 'j.alabi@crbemseminary.edu',
    fullName: 'Ven. Prof. Jeremiah K. Alabi',
    role: 'Lecturer',
    title: 'Professor of Old Testament & Biblical Hermeneutics',
    qualification: 'B.Th. (Hons), M.A., Ph.D. (Theology & Exegesis)',
    designation: 'Rector & Dean of Biblical Studies',
    specialization: 'Pentateuchal Theology, Biblical Hebrew, Canon History',
    assignedCourses: ['BIB 101', 'LAN 301'],
    officeLocation: 'Rectorate Wing, Suite 101',
    createdAt: '2020-01-15'
  },
  {
    id: 'staff-2',
    staffId: 'CRBEM/FAC/002',
    email: 's.olawale@crbemseminary.edu',
    fullName: 'Rev. Dr. Samuel O. Olawale',
    role: 'Lecturer',
    title: 'Associate Professor of Systematic Theology',
    qualification: 'B.Sc., M.Div., Th.D.',
    designation: 'Dean of Academic Affairs',
    specialization: 'Trinitarian Orthodoxy, Reformed Dogmatics, Apologetics',
    assignedCourses: ['THE 201', 'THE 301'],
    officeLocation: 'Academic Affairs Wing, Room 204',
    createdAt: '2021-03-10'
  },
  {
    id: 'staff-3',
    staffId: 'CRBEM/FAC/003',
    email: 'f.akinwumi@crbemseminary.edu',
    fullName: 'Rt. Rev. Dr. Festus B. Akinwumi',
    role: 'Lecturer',
    title: 'Professor of Pastoral Theology & Missiology',
    qualification: 'Dip.Th., B.A., M.Th., Ph.D. (Cantab)',
    designation: 'Head, Department of Pastoral Ministry',
    specialization: 'Expository Preaching, Homiletics, Church Planting',
    assignedCourses: ['MIN 301', 'MIS 102'],
    officeLocation: 'Pastoral Studies Complex, Room 102',
    createdAt: '2019-09-01'
  },
  {
    id: 'staff-4',
    staffId: 'CRBEM/FAC/004',
    email: 'g.adebayo@crbemseminary.edu',
    fullName: 'Pastor Grace E. Adebayo',
    role: 'Lecturer',
    title: 'Senior Lecturer in Biblical Languages',
    qualification: 'B.Th. (First Class), M.Th. (New Testament)',
    designation: 'Director of Language Studies',
    specialization: 'Koine Greek Syntax, Pauline Epistles, Textual Criticism',
    assignedCourses: ['LAN 205', 'LAN 206'],
    officeLocation: 'Language Center, Room 12',
    createdAt: '2022-08-20'
  },
  {
    id: 'staff-5',
    staffId: 'CRBEM/FAC/005',
    email: 'm.danladi@crbemseminary.edu',
    fullName: 'Dr. Michael T. Danladi',
    role: 'Lecturer',
    title: 'Senior Lecturer in Historical Theology',
    qualification: 'B.A. (History), M.A., Ph.D.',
    designation: 'Coordinator, Postgraduate Studies',
    specialization: 'Early Church Patristics, Reformation Dogma, African Christianity',
    assignedCourses: ['HIS 304', 'PGD 707'],
    officeLocation: 'Postgraduate Directorate, Room 301',
    createdAt: '2023-01-11'
  }
];

export const SEED_STUDENT: Student = {
  id: 'usr-student-1',
  email: 'e.adeyemi@student.crbemseminary.edu',
  fullName: 'Bro. Emmanuel O. Adeyemi',
  role: 'Student',
  matriculationNumber: 'CRBEM/BTH/2024/018',
  programmeId: 'prog-bth',
  programmeName: 'Bachelor of Theology (B.Th.)',
  studyMode: 'Full-Time (On-Campus)',
  level: '200 Level',
  currentSemester: 'First Semester',
  academicSession: '2026/2027',
  registrationStatus: 'Registered',
  cumulativeGpa: 3.84,
  totalCreditsEarned: 42,
  totalCreditsRequired: 120,
  facultyAdvisor: 'Rev. Dr. Samuel O. Olawale',
  enrollmentDate: '2024-09-12',
  phoneNumber: '+234 803 456 7890',
  createdAt: '2024-08-15'
};

export const SEED_APPLICANTS: Applicant[] = [
  {
    id: 'usr-applicant-1',
    email: 'david.babalola@gmail.com',
    fullName: 'Pastor David Babalola',
    role: 'Applicant',
    applicationId: 'app-2026-001',
    programmeId: 'prog-bth',
    programmeName: 'Bachelor of Theology (B.Th.)',
    applicationReference: 'CRBEM-APP-2026-0412',
    studyMode: 'Full-Time (On-Campus)',
    status: 'Offer Issued',
    submissionDate: '2026-08-14',
    intakeSession: '2026/2027 Academic Session',
    createdAt: '2026-08-10',
    personalInfo: {
      title: 'Pastor',
      dateOfBirth: '1995-04-18',
      gender: 'Male',
      nationality: 'Nigerian',
      stateOfOrigin: 'Oyo State',
      residentialAddress: '14 Grace Avenue, Ikeja, Lagos',
      churchDenomination: 'Christ Redemption Bible Evangelical Mission',
      pastorName: 'Rev. J. A. Oladele',
      yearsBornAgain: 12,
      ministerialCalling: 'Pastoral ministry and church planting among unreached suburban communities.'
    },
    educationHistory: [
      {
        institution: 'Federal Government College, Idoani',
        qualification: 'West African Senior School Certificate (WASSCE)',
        yearCompleted: 2013,
        gradeOrClass: '5 Distinctions, 3 Credits'
      },
      {
        institution: 'University of Ibadan',
        qualification: 'B.Sc. Sociology',
        yearCompleted: 2018,
        gradeOrClass: 'Second Class Upper'
      }
    ],
    documents: [
      { id: 'doc-1', name: 'WASSCE_Certificate_Certified.pdf', type: 'Certificate', uploadDate: '2026-08-14', fileSize: '2.1 MB', verified: true },
      { id: 'doc-2', name: 'Pastor_Recommendation_Letter.pdf', type: 'Reference', uploadDate: '2026-08-14', fileSize: '850 KB', verified: true },
      { id: 'doc-3', name: 'Baptismal_Certificate.pdf', type: 'Certificate', uploadDate: '2026-08-14', fileSize: '1.2 MB', verified: true },
      { id: 'doc-4', name: 'Statement_Of_Calling_Essay.pdf', type: 'Essay', uploadDate: '2026-08-14', fileSize: '640 KB', verified: true }
    ],
    admissionDecision: {
      id: 'dec-001',
      applicantId: 'usr-applicant-1',
      decision: 'Admitted',
      decisionDate: '2026-09-02',
      issuedBy: 'Office of the Registrar',
      matriculationNumber: 'CRBEM/BTH/2026/042',
      programmeOffered: 'Bachelor of Theology (B.Th.)',
      commencementDate: 'October 19, 2026',
      letterContent: `Dear Pastor David Babalola,\n\nFollowing your satisfactory performance in the CRBEM Seminary Entrance Examination and Oral Interview, the Academic Board of Christ Redemption Bible Evangelical Mission Theological Seminary is pleased to offer you provisional admission into the 4-Year Bachelor of Theology (B.Th.) degree programme for the 2026/2027 Academic Session.\n\nYour matriculation number has been designated as CRBEM/BTH/2026/042. You are expected to complete your formal acceptance of offer and register for courses prior to the matriculation ceremony on October 24, 2026.\n\nMay the grace of our Lord Jesus Christ guide your preparation for holy ministerial service.\n\nYours in Christ's Vineyard,\nOffice of the Registrar, CRBEM Seminary`,
      acceptedByCandidate: false
    }
  },
  {
    id: 'usr-applicant-2',
    email: 'ruth.okoro@outlook.com',
    fullName: 'Sister Ruth N. Okoro',
    role: 'Applicant',
    applicationId: 'app-2026-002',
    programmeId: 'prog-pgdth',
    programmeName: 'Postgraduate Diploma in Theology',
    applicationReference: 'CRBEM-APP-2026-0489',
    studyMode: 'Part-Time (Executive)',
    status: 'In Review',
    submissionDate: '2026-09-18',
    intakeSession: '2026/2027 Academic Session',
    createdAt: '2026-09-15',
    personalInfo: {
      title: 'Sister',
      dateOfBirth: '1998-11-03',
      gender: 'Female',
      nationality: 'Nigerian',
      stateOfOrigin: 'Enugu State',
      residentialAddress: '28 Praise Crescent, Garki, Abuja',
      churchDenomination: 'Redeemed Christian Church of God',
      pastorName: 'Pastor Timothy Nwosu',
      yearsBornAgain: 8,
      ministerialCalling: 'Christian education curriculum development and women discipleship coordination.'
    },
    educationHistory: [
      {
        institution: 'University of Nigeria, Nsukka',
        qualification: 'B.A. Mass Communication',
        yearCompleted: 2020,
        gradeOrClass: 'First Class Honours'
      }
    ],
    documents: [
      { id: 'doc-5', name: 'Degree_Transcript_UNN.pdf', type: 'Transcript', uploadDate: '2026-09-18', fileSize: '3.4 MB', verified: true },
      { id: 'doc-6', name: 'Pastoral_Attestation_RCCG.pdf', type: 'Reference', uploadDate: '2026-09-18', fileSize: '1.1 MB', verified: false }
    ]
  },
  {
    id: 'usr-applicant-3',
    email: 'samuel.mensah@ghanamission.org',
    fullName: 'Evangelist Samuel K. Mensah',
    role: 'Applicant',
    applicationId: 'app-2026-003',
    programmeId: 'prog-mth',
    programmeName: 'Master of Theology (M.Th.)',
    applicationReference: 'CRBEM-APP-2026-0504',
    studyMode: 'Modular Distance',
    status: 'Interview Scheduled',
    interviewDate: '2026-10-14 · 10:00 AM (West Africa Time)',
    interviewNotes: 'Oral evaluation of proposed research on Exegesis of the Pauline Doctrine of Justification in African Context.',
    submissionDate: '2026-09-25',
    intakeSession: '2026/2027 Academic Session',
    createdAt: '2026-09-20',
    personalInfo: {
      title: 'Evangelist',
      dateOfBirth: '1989-07-22',
      gender: 'Male',
      nationality: 'Ghanaian',
      residentialAddress: 'Acre Road, North Legon, Accra, Ghana',
      churchDenomination: 'Evangelical Presbyterian Church',
      pastorName: 'Rev. Dr. Kwesi Boakye',
      yearsBornAgain: 17,
      ministerialCalling: 'Seminary lecturer in biblical languages and cross-cultural mission trainer.'
    },
    educationHistory: [
      {
        institution: 'Trinity Theological Seminary, Legon',
        qualification: 'Bachelor of Theology (B.Th.)',
        yearCompleted: 2016,
        gradeOrClass: 'Summa Cum Laude'
      }
    ],
    documents: [
      { id: 'doc-7', name: 'BTh_Transcript_Trinity.pdf', type: 'Transcript', uploadDate: '2026-09-25', fileSize: '4.2 MB', verified: true },
      { id: 'doc-8', name: 'MTh_Research_Proposal_Pauline_Exegesis.pdf', type: 'Proposal', uploadDate: '2026-09-25', fileSize: '1.9 MB', verified: true }
    ]
  }
];

export const SEED_ANNOUNCEMENTS: Announcement[] = [
  {
    id: 'ann-1',
    title: 'Commencement of 2026/2027 First Semester Academic Calendar & Matriculation Notice',
    category: 'Registrar',
    content: 'The Office of the Registrar wishes to inform all returning students, faculty, and newly admitted candidates that academic lectures for the First Semester 2026/2027 session commence on Monday, October 19, 2026. The 41st Matriculation Ceremony will be held at the Main Seminary Chapel on Saturday, October 24, 2026 at 10:00 AM prompt.',
    date: '2026-10-02',
    author: 'Office of the Registrar',
    priority: 'Urgent',
    targetAudience: 'All'
  },
  {
    id: 'ann-2',
    title: 'Digital Theological Library Physical Cataloguing & JSTOR Theological Archive Access',
    category: 'Library',
    content: 'The Seminary Library Directorate has concluded the cataloguing of over 850 newly acquired theological works in Systematic Theology and Patristics. All enrolled students are entitled to institutional remote access to the digital repository using their matriculation credentials.',
    date: '2026-09-28',
    author: 'Seminary Chief Librarian',
    priority: 'Normal',
    targetAudience: 'Students'
  },
  {
    id: 'ann-3',
    title: 'Annual Spiritual Emphasis Week & Expository Hermeneutics Lectures',
    category: 'Chapel & Spiritual',
    content: 'The Seminary Spiritual Life Committee invites the seminary community to the Annual Spiritual Emphasis Week themed: "Holding Fast the Faithful Word" (Titus 1:9). Guest Expositor: Rev. Dr. Arthur Pink Memorial Chair Lecturer.',
    date: '2026-09-22',
    author: 'Dean of Spiritual Affairs',
    priority: 'High',
    targetAudience: 'All'
  }
];

export const SEED_ACADEMIC_SESSIONS: AcademicSession[] = [
  {
    id: 'sess-2026-2027',
    name: '2026/2027 Academic Session',
    isCurrent: true,
    semesters: [
      {
        name: 'First Semester',
        startDate: '2026-10-19',
        endDate: '2027-02-27',
        examStartDate: '2027-02-15',
        registrationDeadline: '2026-11-06'
      },
      {
        name: 'Second Semester',
        startDate: '2027-03-15',
        endDate: '2027-07-24',
        examStartDate: '2027-07-10',
        registrationDeadline: '2027-04-02'
      }
    ]
  }
];

export const SEED_ASSIGNMENTS: Assignment[] = [
  {
    id: 'assign-1',
    courseId: 'course-the-201',
    courseCode: 'THE 201',
    courseTitle: 'Systematic Theology I',
    title: 'Exegesis and Doctrinal Defense of Biblical Inerrancy',
    instructions: 'Write a scholarly 2,000-word doctrinal essay evaluating the Chicago Statement on Biblical Inerrancy. Contrast its biblical foundations (2 Timothy 3:16, 2 Peter 1:20-21) with modern accommodationist theories. Cite at least 5 theological sources in Turabian/Chicago format.',
    assignedDate: '2026-10-01',
    dueDate: '2026-10-25',
    maxScore: 30,
    allowLateSubmission: false
  },
  {
    id: 'assign-2',
    courseId: 'course-bib-101',
    courseCode: 'BIB 101',
    courseTitle: 'Intro to Old Testament Literature',
    title: 'Theological Analysis of the Abrahamic Covenant (Genesis 12 & 15)',
    instructions: 'Trace the progression of God\'s covenant with Abraham from Genesis 12 to 17. Discuss how the covenant promises (land, seed, blessing) find their ultimate fulfillment in the New Testament church through Jesus Christ.',
    assignedDate: '2026-09-28',
    dueDate: '2026-10-30',
    maxScore: 30,
    allowLateSubmission: true
  },
  {
    id: 'assign-3',
    courseId: 'course-lan-205',
    courseCode: 'LAN 205',
    courseTitle: 'Elements of New Testament Greek I',
    title: 'Greek Parsing Drills: 1 John Chapter 1',
    instructions: 'Provide morphological parsing for the highlighted 25 verbs and nouns in 1 John 1:1–7. Identify tense, voice, mood, person, and lexical form.',
    assignedDate: '2026-10-05',
    dueDate: '2026-10-18',
    maxScore: 20,
    allowLateSubmission: false
  }
];

export const SEED_SUBMISSIONS: Submission[] = [
  {
    id: 'sub-1',
    assignmentId: 'assign-3',
    studentId: 'usr-student-1',
    studentName: 'Bro. Emmanuel O. Adeyemi',
    submittedAt: '2026-10-06 05:40 PM',
    textContent: 'Completed parsing worksheet for 1 John 1:1-7. All 25 lexical forms accurately identified with primary accent considerations noted.',
    attachmentName: 'Adeyemi_LAN205_Greek_Parsing_Assignment.pdf',
    status: 'Submitted'
  }
];

export const SEED_RESULTS: Result[] = [
  {
    id: 'res-1',
    studentId: 'usr-student-1',
    courseId: 'course-bib-101',
    courseCode: 'BIB 101',
    courseTitle: 'Introduction to Old Testament Literature',
    credits: 3,
    semester: 'Previous Session (2025/2026)',
    session: '2025/2026',
    continuousAssessment: 28,
    examinationScore: 64,
    totalScore: 92,
    grade: 'A',
    gradePoint: 4.0
  },
  {
    id: 'res-2',
    studentId: 'usr-student-1',
    courseId: 'course-lan-205',
    courseCode: 'LAN 205',
    courseTitle: 'Elements of New Testament Greek I',
    credits: 3,
    semester: 'Previous Session (2025/2026)',
    session: '2025/2026',
    continuousAssessment: 26,
    examinationScore: 58,
    totalScore: 84,
    grade: 'A',
    gradePoint: 4.0
  },
  {
    id: 'res-3',
    studentId: 'usr-student-1',
    courseId: 'course-his-101',
    courseCode: 'HIS 101',
    courseTitle: 'Early Church History to AD 500',
    credits: 3,
    semester: 'Previous Session (2025/2026)',
    session: '2025/2026',
    continuousAssessment: 24,
    examinationScore: 53,
    totalScore: 77,
    grade: 'B',
    gradePoint: 3.0
  },
  {
    id: 'res-4',
    studentId: 'usr-student-1',
    courseId: 'course-min-101',
    courseCode: 'MIN 101',
    courseTitle: 'Spiritual Formation & Discipleship',
    credits: 2,
    semester: 'Previous Session (2025/2026)',
    session: '2025/2026',
    continuousAssessment: 29,
    examinationScore: 66,
    totalScore: 95,
    grade: 'A',
    gradePoint: 4.0
  }
];

export const SEED_LOANS: LibraryLoan[] = [
  {
    id: 'loan-1',
    bookId: 'book-1',
    bookTitle: 'Systematic Theology: An Introduction to Biblical Doctrine',
    bookAuthor: 'Wayne Grudem',
    shelfLocation: 'ST-104-A',
    userId: 'usr-student-1',
    userName: 'Bro. Emmanuel O. Adeyemi',
    borrowDate: '2026-09-24',
    dueDate: '2026-10-15',
    status: 'Active'
  },
  {
    id: 'loan-2',
    bookId: 'book-3',
    bookTitle: 'How to Read the Bible for All Its Worth',
    bookAuthor: 'Gordon D. Fee & Douglas Stuart',
    shelfLocation: 'BE-112-A',
    userId: 'usr-student-1',
    userName: 'Bro. Emmanuel O. Adeyemi',
    borrowDate: '2026-09-02',
    dueDate: '2026-09-23',
    returnDate: '2026-09-21',
    status: 'Returned'
  }
];

export const SEED_ENQUIRIES: ContactEnquiry[] = [
  {
    id: 'enq-1',
    fullName: 'Rev. Timothy Adeola',
    email: 't.adeola@gracechapel.ng',
    phone: '+234 802 334 5566',
    subject: 'Executive Modular Admission for Full-Time Pastors',
    message: 'Grace to you in Christ. I lead a congregation in Port Harcourt and wish to inquire whether the Bachelor of Theology (B.Th.) modular distance track accommodates intensive residential blocks during holiday periods.',
    submittedAt: '2026-10-04 11:20 AM',
    status: 'New',
    category: 'Admissions'
  },
  {
    id: 'enq-2',
    fullName: 'Sister Deborah Balogun',
    email: 'deborah.b@gmail.com',
    phone: '+234 818 776 9900',
    subject: 'Transcript Request for Missionary Board Verification',
    message: 'I completed the Diploma in Theology in 2021 and require an official academic transcript forwarded to the Baptist World Mission Board.',
    submittedAt: '2026-09-29 03:45 PM',
    status: 'Replied',
    category: 'Pastoral Transcript'
  }
];

export const SEED_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'log-1',
    action: 'Admission Decision Issued',
    performedBy: 'Office of the Registrar',
    target: 'Candidate: Pastor David Babalola (CRBEM-APP-2026-0412)',
    timestamp: '2026-09-02 14:10:00',
    details: 'Provisional offer of admission granted with Matriculation No: CRBEM/BTH/2026/042'
  },
  {
    id: 'log-2',
    action: 'Library Loan Recorded',
    performedBy: 'Librarian (Desk 1)',
    target: 'Student: Emmanuel Adeyemi (CRBEM/BTH/2024/018)',
    timestamp: '2026-09-24 10:15:22',
    details: 'Borrowed Wayne Grudem Systematic Theology (Barcode #ST104-03)'
  },
  {
    id: 'log-3',
    action: 'Course Syllabus Published',
    performedBy: 'Ven. Prof. Jeremiah K. Alabi',
    target: 'BIB 101 - Old Testament Literature',
    timestamp: '2026-09-28 09:00:00',
    details: 'Uploaded updated syllabus and covenant hermeneutics reading schedule.'
  }
];
