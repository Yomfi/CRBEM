/**
 * CRBEM Theological Seminary - Global Application Context
 * Decoupled state management with seamless Firebase compatibility
 */

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  Role,
  User,
  Applicant,
  Student,
  Staff,
  Programme,
  Course,
  LibraryBook,
  LibraryLoan,
  Announcement,
  Assignment,
  Submission,
  Result,
  ContactEnquiry,
  NotificationItem,
  AuditLog
} from '../types';
import {
  SEED_PROGRAMMES,
  SEED_COURSES,
  SEED_LIBRARY_BOOKS,
  SEED_APPLICANTS,
  SEED_STUDENT,
  SEED_FACULTY,
  SEED_ANNOUNCEMENTS,
  SEED_ASSIGNMENTS,
  SEED_SUBMISSIONS,
  SEED_RESULTS,
  SEED_LOANS,
  SEED_ENQUIRIES,
  SEED_AUDIT_LOGS
} from '../data/seedData';

export type AppView = 
  | 'public-home'
  | 'academic-home'
  | 'about'
  | 'statement-of-faith'
  | 'faculty'
  | 'programmes'
  | 'programme-detail'
  | 'admissions'
  | 'tuition-fees'
  | 'seminary-life'
  | 'library'
  | 'news'
  | 'contact'
  | 'auth-login'
  | 'auth-register'
  | 'applicant-portal'
  | 'student-portal'
  | 'student-programme'
  | 'student-calendar'
  | 'student-results'
  | 'student-assignments'
  | 'student-profile'
  | 'course-detail'
  | 'admin-portal';

export interface ToastMessage {
  id: string;
  title: string;
  description?: string;
  type: 'success' | 'info' | 'warning' | 'error';
}

interface AppContextType {
  // Navigation & View State
  currentView: AppView;
  selectedProgrammeId: string | null;
  selectedCourseId: string | null;
  navigateTo: (view: AppView, paramId?: string) => void;

  // Identity & Auth
  currentRole: Role;
  currentUser: User | Student | Applicant | Staff | null;
  setCurrentRole: (role: Role) => void;
  loginAs: (user: User) => void;
  logout: () => void;
  quickSwitchPersona: (persona: 'Guest' | 'Applicant' | 'Student' | 'Lecturer' | 'Registrar' | 'Super Admin') => void;

  // Data Stores
  programmes: Programme[];
  courses: Course[];
  libraryBooks: LibraryBook[];
  libraryLoans: LibraryLoan[];
  savedBookIds: string[];
  applicants: Applicant[];
  students: Student[];
  faculty: Staff[];
  announcements: Announcement[];
  assignments: Assignment[];
  submissions: Submission[];
  results: Result[];
  enquiries: ContactEnquiry[];
  auditLogs: AuditLog[];
  notifications: NotificationItem[];
  toasts: ToastMessage[];

  // Actions
  addToast: (title: string, description?: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
  removeToast: (id: string) => void;
  
  // Library Actions
  borrowBook: (bookId: string) => boolean;
  returnBook: (loanId: string) => void;
  toggleSaveBook: (bookId: string) => void;

  // Application & Admission Actions
  submitNewApplication: (data: Partial<Applicant>) => string;
  updateApplicationStatus: (applicantId: string, status: Applicant['status'], notes?: string) => void;
  issueAdmissionOffer: (applicantId: string, matriculationNumber: string) => void;
  acceptOfferAndMatriculate: (applicantId: string) => void;

  // Academic Actions
  submitAssignment: (assignmentId: string, textContent: string, attachmentName?: string) => void;
  gradeSubmission: (submissionId: string, score: number, feedback: string) => void;
  publishAnnouncement: (announcement: Omit<Announcement, 'id' | 'date'>) => void;
  submitContactEnquiry: (enquiry: Omit<ContactEnquiry, 'id' | 'submittedAt' | 'status'>) => void;
  markEnquiryReplied: (enquiryId: string) => void;
  markNotificationRead: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  APPLICANTS: 'crbem_applicants',
  STUDENTS: 'crbem_students',
  BOOKS: 'crbem_books',
  LOANS: 'crbem_loans',
  SAVED_BOOKS: 'crbem_saved_books',
  SUBMISSIONS: 'crbem_submissions',
  ANNOUNCEMENTS: 'crbem_announcements',
  ENQUIRIES: 'crbem_enquiries',
  AUDIT_LOGS: 'crbem_audit_logs',
  CURRENT_ROLE: 'crbem_current_role'
};

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Navigation
  const [currentView, setCurrentView] = useState<AppView>('public-home');
  const [selectedProgrammeId, setSelectedProgrammeId] = useState<string | null>('prog-bth');
  const [selectedCourseId, setSelectedCourseId] = useState<string | null>('course-bib-101');

  // Role & User
  const [currentRole, setCurrentRoleState] = useState<Role>('Guest');
  const [currentUser, setCurrentUser] = useState<User | Student | Applicant | Staff | null>(null);

  // Data Stores initialized with LocalStorage or Seed Data
  const [programmes] = useState<Programme[]>(SEED_PROGRAMMES);
  const [courses] = useState<Course[]>(SEED_COURSES);
  const [faculty] = useState<Staff[]>(SEED_FACULTY);
  const [assignments] = useState<Assignment[]>(SEED_ASSIGNMENTS);
  const [results] = useState<Result[]>(SEED_RESULTS);

  const [applicants, setApplicants] = useState<Applicant[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.APPLICANTS);
      return stored ? JSON.parse(stored) : SEED_APPLICANTS;
    } catch {
      return SEED_APPLICANTS;
    }
  });

  const [students, setStudents] = useState<Student[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.STUDENTS);
      return stored ? JSON.parse(stored) : [SEED_STUDENT];
    } catch {
      return [SEED_STUDENT];
    }
  });

  const [libraryBooks, setLibraryBooks] = useState<LibraryBook[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.BOOKS);
      return stored ? JSON.parse(stored) : SEED_LIBRARY_BOOKS;
    } catch {
      return SEED_LIBRARY_BOOKS;
    }
  });

  const [libraryLoans, setLibraryLoans] = useState<LibraryLoan[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.LOANS);
      return stored ? JSON.parse(stored) : SEED_LOANS;
    } catch {
      return SEED_LOANS;
    }
  });

  const [savedBookIds, setSavedBookIds] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.SAVED_BOOKS);
      return stored ? JSON.parse(stored) : ['book-1', 'book-3'];
    } catch {
      return ['book-1', 'book-3'];
    }
  });

  const [submissions, setSubmissions] = useState<Submission[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.SUBMISSIONS);
      return stored ? JSON.parse(stored) : SEED_SUBMISSIONS;
    } catch {
      return SEED_SUBMISSIONS;
    }
  });

  const [announcements, setAnnouncements] = useState<Announcement[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.ANNOUNCEMENTS);
      return stored ? JSON.parse(stored) : SEED_ANNOUNCEMENTS;
    } catch {
      return SEED_ANNOUNCEMENTS;
    }
  });

  const [enquiries, setEnquiries] = useState<ContactEnquiry[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.ENQUIRIES);
      return stored ? JSON.parse(stored) : SEED_ENQUIRIES;
    } catch {
      return SEED_ENQUIRIES;
    }
  });

  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS);
      return stored ? JSON.parse(stored) : SEED_AUDIT_LOGS;
    } catch {
      return SEED_AUDIT_LOGS;
    }
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>([
    {
      id: 'notif-1',
      title: 'First Semester Registration Deadline',
      message: 'Course registration closes November 6, 2026. Ensure all core theological courses are registered.',
      date: '2026-10-04',
      read: false,
      type: 'info'
    },
    {
      id: 'notif-2',
      title: 'Matriculation Robe Collection',
      message: 'Collection of academic gowns at the Seminary Stores begins Wednesday.',
      date: '2026-10-02',
      read: false,
      type: 'success'
    }
  ]);

  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.APPLICANTS, JSON.stringify(applicants));
  }, [applicants]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.BOOKS, JSON.stringify(libraryBooks));
  }, [libraryBooks]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LOANS, JSON.stringify(libraryLoans));
  }, [libraryLoans]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SAVED_BOOKS, JSON.stringify(savedBookIds));
  }, [savedBookIds]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SUBMISSIONS, JSON.stringify(submissions));
  }, [submissions]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ANNOUNCEMENTS, JSON.stringify(announcements));
  }, [announcements]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ENQUIRIES, JSON.stringify(enquiries));
  }, [enquiries]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(auditLogs));
  }, [auditLogs]);

  const addToast = (title: string, description?: string, type: 'success' | 'info' | 'warning' | 'error' = 'info') => {
    const id = 'toast-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4);
    setToasts((prev) => [...prev, { id, title, description, type }]);
    setTimeout(() => {
      removeToast(id);
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const navigateTo = (view: AppView, paramId?: string) => {
    if (view === 'programme-detail' && paramId) {
      setSelectedProgrammeId(paramId);
    }
    if (view === 'course-detail' && paramId) {
      setSelectedCourseId(paramId);
    }
    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const setCurrentRole = (role: Role) => {
    setCurrentRoleState(role);
  };

  const quickSwitchPersona = (persona: 'Guest' | 'Applicant' | 'Student' | 'Lecturer' | 'Registrar' | 'Super Admin') => {
    if (persona === 'Guest') {
      setCurrentRoleState('Guest');
      setCurrentUser(null);
      setCurrentView('public-home');
      addToast('Switched to Guest', 'Browsing public seminary website', 'info');
    } else if (persona === 'Applicant') {
      const app = applicants[0] || SEED_APPLICANTS[0];
      setCurrentRoleState('Applicant');
      setCurrentUser(app);
      setCurrentView('applicant-portal');
      addToast('Signed in as Applicant', `Viewing candidate portal: ${app.fullName}`, 'success');
    } else if (persona === 'Student') {
      const stu = students[0] || SEED_STUDENT;
      setCurrentRoleState('Student');
      setCurrentUser(stu);
      setCurrentView('student-portal');
      addToast('Signed in as Student', `Matric No: ${stu.matriculationNumber}`, 'success');
    } else if (persona === 'Lecturer') {
      const fac = faculty[0];
      setCurrentRoleState('Lecturer');
      setCurrentUser(fac);
      setCurrentView('admin-portal');
      addToast('Signed in as Faculty', `${fac.fullName} (${fac.title})`, 'info');
    } else if (persona === 'Registrar') {
      setCurrentRoleState('Registrar');
      setCurrentUser({
        id: 'usr-reg-1',
        fullName: 'Office of the Registrar',
        email: 'registrar@crbemseminary.edu',
        role: 'Registrar',
        createdAt: '2020-01-01'
      });
      setCurrentView('admin-portal');
      addToast('Administrative Access', 'Registrar Academic Directorate', 'info');
    } else if (persona === 'Super Admin') {
      setCurrentRoleState('Super Admin');
      setCurrentUser({
        id: 'usr-admin-1',
        fullName: 'Seminary Academic Administrator',
        email: 'admin@crbemseminary.edu',
        role: 'Super Admin',
        createdAt: '2020-01-01'
      });
      setCurrentView('admin-portal');
      addToast('Administrative Access', 'Super Admin full management mode', 'info');
    }
  };

  const loginAs = (user: User) => {
    setCurrentUser(user);
    setCurrentRoleState(user.role);
    if (user.role === 'Applicant') {
      setCurrentView('applicant-portal');
    } else if (user.role === 'Student') {
      setCurrentView('student-portal');
    } else if (['Super Admin', 'Registrar', 'Admissions Officer', 'Lecturer', 'Librarian', 'Finance Officer'].includes(user.role)) {
      setCurrentView('admin-portal');
    } else {
      setCurrentView('public-home');
    }
    addToast('Welcome back', `Signed in as ${user.fullName}`, 'success');
  };

  const logout = () => {
    setCurrentUser(null);
    setCurrentRoleState('Guest');
    setCurrentView('public-home');
    addToast('Signed Out', 'You have been safely signed out.', 'info');
  };

  // Library actions
  const borrowBook = (bookId: string): boolean => {
    const book = libraryBooks.find((b) => b.id === bookId);
    if (!book || book.availableCopies <= 0) {
      addToast('Book Unavailable', 'All copies of this volume are currently loaned out.', 'error');
      return false;
    }

    const userName = currentUser?.fullName || 'Bro. Emmanuel O. Adeyemi';
    const userId = currentUser?.id || 'usr-student-1';

    const newLoan: LibraryLoan = {
      id: 'loan-' + Date.now(),
      bookId: book.id,
      bookTitle: book.title,
      bookAuthor: book.author,
      shelfLocation: book.shelfLocation,
      userId,
      userName,
      borrowDate: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 21 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      status: 'Active'
    };

    setLibraryBooks((prev) =>
      prev.map((b) => (b.id === bookId ? { ...b, availableCopies: b.availableCopies - 1 } : b))
    );
    setLibraryLoans((prev) => [newLoan, ...prev]);

    // Add audit
    const newLog: AuditLog = {
      id: 'log-' + Date.now(),
      action: 'Library Loan Borrowed',
      performedBy: userName,
      target: `${book.title} (${book.shelfLocation})`,
      timestamp: new Date().toLocaleString(),
      details: `Loan due in 21 days.`
    };
    setAuditLogs((prev) => [newLog, ...prev]);

    addToast('Volume Checked Out', `Due in 21 days. Shelf: ${book.shelfLocation}`, 'success');
    return true;
  };

  const returnBook = (loanId: string) => {
    const loan = libraryLoans.find((l) => l.id === loanId);
    if (!loan) return;

    setLibraryLoans((prev) =>
      prev.map((l) =>
        l.id === loanId
          ? { ...l, status: 'Returned', returnDate: new Date().toISOString().split('T')[0] }
          : l
      )
    );

    setLibraryBooks((prev) =>
      prev.map((b) => (b.id === loan.bookId ? { ...b, availableCopies: b.availableCopies + 1 } : b))
    );

    addToast('Book Returned', `Returned "${loan.bookTitle}" to Library desk.`, 'info');
  };

  const toggleSaveBook = (bookId: string) => {
    if (savedBookIds.includes(bookId)) {
      setSavedBookIds((prev) => prev.filter((id) => id !== bookId));
      addToast('Removed from Reading List', undefined, 'info');
    } else {
      setSavedBookIds((prev) => [...prev, bookId]);
      addToast('Added to Reading List', undefined, 'success');
    }
  };

  // Application actions
  const submitNewApplication = (candidateData: Partial<Applicant>): string => {
    const refNumber = `CRBEM-APP-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const newApplicant: Applicant = {
      id: 'usr-app-' + Date.now(),
      email: candidateData.email || 'applicant@crbemseminary.edu',
      fullName: candidateData.fullName || 'Candidate',
      role: 'Applicant',
      applicationId: 'app-' + Date.now(),
      programmeId: candidateData.programmeId || 'prog-bth',
      programmeName: candidateData.programmeName || 'Bachelor of Theology (B.Th.)',
      applicationReference: refNumber,
      studyMode: candidateData.studyMode || 'Full-Time (On-Campus)',
      status: 'Submitted',
      submissionDate: new Date().toISOString().split('T')[0],
      intakeSession: '2026/2027 Academic Session',
      createdAt: new Date().toISOString().split('T')[0],
      personalInfo: candidateData.personalInfo || {
        title: 'Bro.',
        dateOfBirth: '1998-05-12',
        gender: 'Male',
        nationality: 'Nigerian',
        residentialAddress: 'Lagos, Nigeria',
        churchDenomination: 'Christ Redemption Bible Evangelical Mission',
        pastorName: 'Rev. Pastor In Charge',
        yearsBornAgain: 5,
        ministerialCalling: 'Evangelistic and pastoral ministry'
      },
      educationHistory: candidateData.educationHistory || [
        {
          institution: 'Senior Secondary School',
          qualification: 'WASSCE Certificate',
          yearCompleted: 2017,
          gradeOrClass: '5 Credits'
        }
      ],
      documents: [
        {
          id: 'doc-' + Date.now(),
          name: 'Academic_Credential_Copy.pdf',
          type: 'Certificate',
          uploadDate: new Date().toISOString().split('T')[0],
          fileSize: '1.8 MB',
          verified: true
        },
        {
          id: 'doc-' + (Date.now() + 1),
          name: 'Pastoral_Endorsement_Letter.pdf',
          type: 'Reference',
          uploadDate: new Date().toISOString().split('T')[0],
          fileSize: '950 KB',
          verified: false
        }
      ]
    };

    setApplicants((prev) => [newApplicant, ...prev]);

    // Audit log
    const log: AuditLog = {
      id: 'log-' + Date.now(),
      action: 'New Application Submitted',
      performedBy: newApplicant.fullName,
      target: `${newApplicant.programmeName} (${newApplicant.applicationReference})`,
      timestamp: new Date().toLocaleString(),
      details: 'Initial dossier submitted for admissions committee vetting.'
    };
    setAuditLogs((prev) => [log, ...prev]);

    // Log user in as applicant
    setCurrentUser(newApplicant);
    setCurrentRoleState('Applicant');
    setCurrentView('applicant-portal');

    addToast('Application Submitted Successfully', `Your reference number is ${refNumber}`, 'success');
    return refNumber;
  };

  const updateApplicationStatus = (applicantId: string, status: Applicant['status'], notes?: string) => {
    setApplicants((prev) =>
      prev.map((app) => (app.id === applicantId ? { ...app, status, interviewNotes: notes || app.interviewNotes } : app))
    );
    addToast('Candidate Status Updated', `Status changed to: ${status}`, 'info');
  };

  const issueAdmissionOffer = (applicantId: string, matriculationNumber: string) => {
    setApplicants((prev) =>
      prev.map((app) => {
        if (app.id === applicantId) {
          return {
            ...app,
            status: 'Offer Issued',
            admissionDecision: {
              id: 'dec-' + Date.now(),
              applicantId: app.id,
              decision: 'Admitted',
              decisionDate: new Date().toISOString().split('T')[0],
              issuedBy: 'Office of the Registrar',
              matriculationNumber,
              programmeOffered: app.programmeName,
              commencementDate: 'October 19, 2026',
              letterContent: `Dear ${app.fullName},\n\nWe are pleased to inform you that following comprehensive evaluation of your academic qualifications, pastoral recommendations, and spiritual calling, the Senate Admissions Committee has approved your admission into ${app.programmeName} for the 2026/2027 Academic Session.\n\nYour assigned Matriculation Number is: ${matriculationNumber}.\n\nPlease proceed to accept this provisional offer and complete course registration before October 24, 2026.\n\nGrace and Peace in Christ,\nOffice of the Registrar, CRBEM Seminary`,
              acceptedByCandidate: false
            }
          };
        }
        return app;
      })
    );

    const log: AuditLog = {
      id: 'log-' + Date.now(),
      action: 'Admission Offer Issued',
      performedBy: 'Office of the Registrar',
      target: `Applicant ID: ${applicantId} | Matric: ${matriculationNumber}`,
      timestamp: new Date().toLocaleString(),
      details: 'Official letter and matriculation number generated.'
    };
    setAuditLogs((prev) => [log, ...prev]);

    addToast('Admission Offer Issued', `Matriculation number ${matriculationNumber} assigned.`, 'success');
  };

  const acceptOfferAndMatriculate = (applicantId: string) => {
    const applicant = applicants.find((a) => a.id === applicantId);
    if (!applicant || !applicant.admissionDecision) {
      addToast('Error', 'No admission offer available to accept.', 'error');
      return;
    }

    const matricNumber = applicant.admissionDecision.matriculationNumber || `CRBEM/BTH/2026/${Math.floor(100 + Math.random() * 900)}`;

    // Create formal student profile
    const newStudent: Student = {
      id: applicant.id,
      email: applicant.email,
      fullName: applicant.fullName,
      role: 'Student',
      matriculationNumber: matricNumber,
      programmeId: applicant.programmeId,
      programmeName: applicant.programmeName,
      studyMode: applicant.studyMode,
      level: '100 Level',
      currentSemester: 'First Semester',
      academicSession: '2026/2027',
      registrationStatus: 'Registered',
      cumulativeGpa: 0.00,
      totalCreditsEarned: 0,
      totalCreditsRequired: 120,
      facultyAdvisor: 'Ven. Prof. Jeremiah K. Alabi',
      enrollmentDate: new Date().toISOString().split('T')[0],
      createdAt: applicant.createdAt
    };

    setStudents((prev) => [newStudent, ...prev]);

    // Update applicant state
    setApplicants((prev) =>
      prev.map((a) => {
        if (a.id === applicantId) {
          return {
            ...a,
            status: 'Matriculated',
            admissionDecision: a.admissionDecision
              ? { ...a.admissionDecision, acceptedByCandidate: true, acceptedDate: new Date().toISOString().split('T')[0] }
              : undefined
          };
        }
        return a;
      })
    );

    // Audit log
    const log: AuditLog = {
      id: 'log-' + Date.now(),
      action: 'Candidate Matriculated',
      performedBy: applicant.fullName,
      target: `Matriculation No: ${matricNumber}`,
      timestamp: new Date().toLocaleString(),
      details: `Accepted admission offer. Formal student record created.`
    };
    setAuditLogs((prev) => [log, ...prev]);

    // Update current user
    setCurrentUser(newStudent);
    setCurrentRoleState('Student');
    setCurrentView('student-portal');

    addToast('Congratulations!', `You are now formally matriculated with number: ${matricNumber}`, 'success');
  };

  // Academic Actions
  const submitAssignment = (assignmentId: string, textContent: string, attachmentName?: string) => {
    const assignment = assignments.find((a) => a.id === assignmentId);
    const newSub: Submission = {
      id: 'sub-' + Date.now(),
      assignmentId,
      studentId: currentUser?.id || 'usr-student-1',
      studentName: currentUser?.fullName || 'Bro. Emmanuel O. Adeyemi',
      submittedAt: new Date().toLocaleString(),
      textContent,
      attachmentName: attachmentName || 'Exegetical_Submission_Paper.pdf',
      status: 'Submitted'
    };

    setSubmissions((prev) => [newSub, ...prev]);
    addToast('Assignment Submitted', `Submitted for "${assignment?.courseCode || 'Course'}".`, 'success');
  };

  const gradeSubmission = (submissionId: string, score: number, feedback: string) => {
    setSubmissions((prev) =>
      prev.map((s) =>
        s.id === submissionId
          ? {
              ...s,
              score,
              lecturerFeedback: feedback,
              status: 'Graded',
              gradedBy: currentUser?.fullName || 'Course Lecturer',
              gradedAt: new Date().toLocaleString()
            }
          : s
      )
    );
    addToast('Grade Recorded', `Score: ${score} points`, 'success');
  };

  const publishAnnouncement = (ann: Omit<Announcement, 'id' | 'date'>) => {
    const newAnn: Announcement = {
      ...ann,
      id: 'ann-' + Date.now(),
      date: new Date().toISOString().split('T')[0]
    };
    setAnnouncements((prev) => [newAnn, ...prev]);
    addToast('Notice Published', newAnn.title, 'success');
  };

  const submitContactEnquiry = (enquiry: Omit<ContactEnquiry, 'id' | 'submittedAt' | 'status'>) => {
    const newEnq: ContactEnquiry = {
      ...enquiry,
      id: 'enq-' + Date.now(),
      submittedAt: new Date().toLocaleString(),
      status: 'New'
    };
    setEnquiries((prev) => [newEnq, ...prev]);
    addToast('Message Sent', 'Thank you. The Seminary Secretariat will respond shortly.', 'success');
  };

  const markEnquiryReplied = (enquiryId: string) => {
    setEnquiries((prev) =>
      prev.map((e) => (e.id === enquiryId ? { ...e, status: 'Replied' } : e))
    );
    addToast('Marked as Replied', undefined, 'info');
  };

  const markNotificationRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  return (
    <AppContext.Provider
      value={{
        currentView,
        selectedProgrammeId,
        selectedCourseId,
        navigateTo,
        currentRole,
        currentUser,
        setCurrentRole,
        loginAs,
        logout,
        quickSwitchPersona,
        programmes,
        courses,
        libraryBooks,
        libraryLoans,
        savedBookIds,
        applicants,
        students,
        faculty,
        announcements,
        assignments,
        submissions,
        results,
        enquiries,
        auditLogs,
        notifications,
        toasts,
        addToast,
        removeToast,
        borrowBook,
        returnBook,
        toggleSaveBook,
        submitNewApplication,
        updateApplicationStatus,
        issueAdmissionOffer,
        acceptOfferAndMatriculate,
        submitAssignment,
        gradeSubmission,
        publishAnnouncement,
        submitContactEnquiry,
        markEnquiryReplied,
        markNotificationRead
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
