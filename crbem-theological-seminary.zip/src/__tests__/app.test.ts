/**
 * CRBEM Theological Seminary - Unit Tests
 * Tests academic data structures, programme outcomes, library cataloguing, and admissions models
 */

import { describe, it, expect } from 'vitest';
import {
  SEED_PROGRAMMES,
  SEED_COURSES,
  SEED_LIBRARY_BOOKS,
  SEED_APPLICANTS,
  SEED_STUDENT,
  SEED_FACULTY
} from '../data/seedData';

describe('CRBEM Academic Programmes & Curriculum Integrity', () => {
  it('should include all 5 required theological academic programmes', () => {
    const codes = SEED_PROGRAMMES.map((p) => p.code);
    expect(codes).toContain('C.Th.');
    expect(codes).toContain('Dip.Th.');
    expect(codes).toContain('B.Th.');
    expect(codes).toContain('PGD.Th.');
    expect(codes).toContain('M.Th.');
  });

  it('flagship B.Th. programme should require 120 credits across 4 years', () => {
    const bth = SEED_PROGRAMMES.find((p) => p.code === 'B.Th.');
    expect(bth).toBeDefined();
    expect(bth?.creditsRequired).toBe(120);
    expect(bth?.duration).toContain('4 Years');
    expect(bth?.curriculum.length).toBeGreaterThan(0);
  });

  it('all programmes should have explicit admission requirements and learning outcomes', () => {
    SEED_PROGRAMMES.forEach((p) => {
      expect(p.admissionRequirements.length).toBeGreaterThan(0);
      expect(p.outcomes.length).toBeGreaterThan(0);
      expect(p.studyModes.length).toBeGreaterThan(0);
      expect(p.leadFaculty).toBeTruthy();
    });
  });
});

describe('Digital Theological Library Repository', () => {
  it('should categorize volumes across orthodox theological categories', () => {
    const categories = new Set(SEED_LIBRARY_BOOKS.map((b) => b.category));
    expect(categories.has('Systematic Theology')).toBe(true);
    expect(categories.has('Biblical Exegesis')).toBe(true);
    expect(categories.has('Biblical Languages')).toBe(true);
    expect(categories.has('Pastoral Ministry')).toBe(true);
    expect(categories.has('Church History')).toBe(true);
    expect(categories.has('CRBEM Archives')).toBe(true);
  });

  it('every catalogued volume should have authentic shelf location and valid copies count', () => {
    SEED_LIBRARY_BOOKS.forEach((book) => {
      expect(book.shelfLocation).toMatch(/^[A-Z]{2,3}-[0-9]{3}/);
      expect(book.availableCopies).toBeLessThanOrEqual(book.totalCopies);
      expect(book.availableCopies).toBeGreaterThanOrEqual(0);
      expect(book.excerpt.length).toBeGreaterThan(50);
    });
  });
});

describe('Student & Candidate Admission Workflow', () => {
  it('applicant should hold valid reference and intake session', () => {
    const applicant = SEED_APPLICANTS[0];
    expect(applicant.applicationReference).toMatch(/^CRBEM-APP-/);
    expect(applicant.personalInfo.pastorName).toBeTruthy();
    expect(applicant.documents.length).toBeGreaterThan(0);
  });

  it('admitted applicant should have provisional matriculation credentials', () => {
    const admitted = SEED_APPLICANTS.find((a) => a.status === 'Offer Issued');
    expect(admitted).toBeDefined();
    expect(admitted?.admissionDecision?.matriculationNumber).toMatch(/^CRBEM\//);
    expect(admitted?.admissionDecision?.decision).toBe('Admitted');
  });

  it('enrolled student record should have standard matriculation number and credit tracking', () => {
    expect(SEED_STUDENT.matriculationNumber).toBe('CRBEM/BTH/2024/018');
    expect(SEED_STUDENT.cumulativeGpa).toBeGreaterThanOrEqual(3.0);
    expect(SEED_STUDENT.totalCreditsRequired).toBe(120);
    expect(SEED_STUDENT.registrationStatus).toBe('Registered');
  });
});

describe('Theological Faculty Chairs & Accreditation', () => {
  it('all faculty members should hold authentic theological credentials and designations', () => {
    SEED_FACULTY.forEach((member) => {
      expect(member.staffId).toMatch(/^CRBEM\/FAC\//);
      expect(member.qualification).toBeTruthy();
      expect(member.specialization).toBeTruthy();
      expect(member.assignedCourses.length).toBeGreaterThan(0);
    });
  });
});

describe('Public Homepage Navigation & Formation Architecture', () => {
  it('verified 5 core programmes map to minimal copy specifications', () => {
    const bth = SEED_PROGRAMMES.find((p) => p.code === 'B.Th.');
    expect(bth?.title).toBe('Bachelor of Theology');
    expect(bth?.creditsRequired).toBe(120);

    const cth = SEED_PROGRAMMES.find((p) => p.code === 'C.Th.');
    expect(cth?.title).toBe('Certificate in Theology');

    const dipth = SEED_PROGRAMMES.find((p) => p.code === 'Dip.Th.');
    expect(dipth?.title).toBe('Diploma in Theology');

    const pgdth = SEED_PROGRAMMES.find((p) => p.code === 'PGD.Th.');
    expect(pgdth?.title).toBe('Postgraduate Diploma in Theology');

    const mth = SEED_PROGRAMMES.find((p) => p.code === 'M.Th.');
    expect(mth?.title).toBe('Master of Theology');
  });
});

