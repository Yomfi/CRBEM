/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Christ Redemption Bible Evangelical Mission Theological Seminary (CRBEM Seminary)
 * Production Academic Management Platform
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { AppHeader } from './components/common/AppHeader';
import { AppFooter } from './components/common/AppFooter';
import { ToastContainer } from './components/common/Toast';

// Public views
import { HeroSection } from './components/public/HeroSection';
import { PillarsSection } from './components/public/PillarsSection';
import { SeminaryAccordionSection } from './components/public/SeminaryAccordionSection';
import { ProgrammesSection } from './components/public/ProgrammesSection';
import { AdmissionsSection } from './components/public/AdmissionsSection';
import { FormationOutcomesSection } from './components/public/FormationOutcomesSection';
import { LibraryPreviewSection } from './components/public/LibraryPreviewSection';
import { FaqSection } from './components/public/FaqSection';
import { ContactSection } from './components/public/ContactSection';
import { CallToActionSection } from './components/public/CallToActionSection';
import { ProgrammeDetailPage } from './components/public/ProgrammeDetailPage';
import { StatementOfFaithSection } from './components/public/StatementOfFaithSection';
import { FacultySection } from './components/public/FacultySection';
import { AcademicHomeView } from './components/public/AcademicHomeView';
import { AcademicBulletinView } from './components/public/AcademicBulletinView';
import { SeminaryLifeView } from './components/public/SeminaryLifeView';

// Candidate views
import { CandidateLoginForm } from './components/applicant/CandidateLoginForm';
import { CandidateRegisterForm } from './components/applicant/CandidateRegisterForm';
import { ApplicantDashboard } from './components/applicant/ApplicantDashboard';

// Student views
import { StudentDashboard } from './components/student/StudentDashboard';
import { MyProgrammeView, ResultsTranscriptView } from './components/student/MyProgrammeView';
import { StudentAssignmentsView, AcademicCalendarView, StudentProfileView } from './components/student/StudentAssignmentsView';

// Library views
import { DigitalLibraryView } from './components/library/DigitalLibraryView';

// Courses views
import { CourseDetailView } from './components/courses/CourseDetailView';

// Admin views
import { AdminDashboard } from './components/admin/AdminDashboard';

const AppRouter: React.FC = () => {
  const { currentView } = useApp();
  const isAuthRegister = currentView === 'auth-register';

  return (
    <main className={`min-h-screen flex flex-col justify-between ${isAuthRegister ? 'bg-white' : 'bg-white text-[#0D0D0E]'}`}>
      <div className="flex-1">
        {/* Public Homepage with Learnora Typography & Eductix Composition */}
        {currentView === 'public-home' && (
          <>
            <HeroSection />
            <PillarsSection />
            <SeminaryAccordionSection />
            <ProgrammesSection />
            <AdmissionsSection />
            <FormationOutcomesSection />
            <LibraryPreviewSection />
            <FaqSection />
            <ContactSection />
            <CallToActionSection />
          </>
        )}

        {currentView === 'academic-home' && <AcademicHomeView />}

        {currentView === 'about' && (
          <>
            <PillarsSection />
            <StatementOfFaithSection />
            <FacultySection />
          </>
        )}

        {/* Dedicated standalone routes preserved */}
        {currentView === 'statement-of-faith' && <StatementOfFaithSection />}

        {currentView === 'faculty' && <FacultySection />}

        {currentView === 'programmes' && <ProgrammesSection />}

        {currentView === 'programme-detail' && <ProgrammeDetailPage />}

        {currentView === 'admissions' && <AdmissionsSection />}

        {currentView === 'tuition-fees' && <AdmissionsSection />}

        {currentView === 'seminary-life' && <SeminaryLifeView />}

        {currentView === 'library' && <DigitalLibraryView />}

        {currentView === 'news' && <AcademicBulletinView />}

        {currentView === 'contact' && <ContactSection />}

        {currentView === 'auth-login' && <CandidateLoginForm />}

        {currentView === 'auth-register' && <CandidateRegisterForm />}

        {currentView === 'applicant-portal' && <ApplicantDashboard />}

        {currentView === 'student-portal' && <StudentDashboard />}

        {currentView === 'student-programme' && <MyProgrammeView />}

        {currentView === 'student-results' && <ResultsTranscriptView />}

        {currentView === 'student-assignments' && <StudentAssignmentsView />}

        {currentView === 'student-calendar' && <AcademicCalendarView />}

        {currentView === 'student-profile' && <StudentProfileView />}

        {currentView === 'course-detail' && <CourseDetailView />}

        {currentView === 'admin-portal' && <AdminDashboard />}
      </div>

      {!isAuthRegister && <AppFooter />}
      <ToastContainer />
    </main>
  );
};

const AppContent: React.FC = () => {
  const { currentView } = useApp();
  const isAuthRegister = currentView === 'auth-register';

  return (
    <>
      {!isAuthRegister && <AppHeader />}
      <AppRouter />
    </>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
